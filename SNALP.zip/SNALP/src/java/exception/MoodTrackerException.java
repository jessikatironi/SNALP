package exception;

public class MoodTrackerException extends AppException {
    
    public MoodTrackerException() {
    }
    
    public MoodTrackerException(String string) {
        super(string);
    }
    
    public MoodTrackerException(String string, Throwable thrwbl) {
        super(string, thrwbl);
    }
    
}
