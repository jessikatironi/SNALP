package exception;

public class AtividadeException extends AppException {
    
    public AtividadeException() {
    }
    
    public AtividadeException(String string) {
        super(string);
    }
    
    public AtividadeException(String string, Throwable thrwbl) {
        super(string, thrwbl);
    }
    
}
