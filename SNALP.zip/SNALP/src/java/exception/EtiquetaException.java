package exception;

public class EtiquetaException extends AppException{

    public EtiquetaException() {
    }

    public EtiquetaException(String message) {
        super(message);
    }

    public EtiquetaException(String message, Throwable cause) {
        super(message, cause);
    }
    
}
