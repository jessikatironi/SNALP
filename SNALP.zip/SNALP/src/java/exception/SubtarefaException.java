package exception;

public class SubtarefaException extends AppException {

    public SubtarefaException() {
    }

    public SubtarefaException(String message) {
        super(message);
    }

    public SubtarefaException(String message, Throwable cause) {
        super(message, cause);
    }
    
}
