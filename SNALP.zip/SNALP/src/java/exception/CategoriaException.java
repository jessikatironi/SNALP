package exception;

public class CategoriaException extends AppException {
    
    public CategoriaException() {
    }
    
    public CategoriaException(String string) {
        super(string);
    }
    
    public CategoriaException(String string, Throwable thrwbl) {
        super(string, thrwbl);
    }
    
}
