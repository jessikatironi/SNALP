package exception;

public class WorkspaceException extends AppException {

    public WorkspaceException() {
    }

    public WorkspaceException(String message) {
        super(message);
    }

    public WorkspaceException(String message, Throwable cause) {
        super(message, cause);
    }
    
}
