package exception;

public class HumorException extends AppException {
    
    public HumorException() {
    }
    
    public HumorException(String string) {
        super(string);
    }
    
    public HumorException(String string, Throwable thrwbl) {
        super(string, thrwbl);
    }
    
}
