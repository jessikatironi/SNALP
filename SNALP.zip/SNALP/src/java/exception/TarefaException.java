package exception;

public class TarefaException extends AppException{

    public TarefaException() {
    }

    public TarefaException(String message) {
        super(message);
    }

    public TarefaException(String message, Throwable cause) {
        super(message, cause);
    }
    
}
