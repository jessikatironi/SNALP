package exception;

public class ObjetivoException extends AppException {
    
    public ObjetivoException() {
    }
    
    public ObjetivoException(String string) {
        super(string);
    }
    
    public ObjetivoException(String string, Throwable thrwbl) {
        super(string, thrwbl);
    }
    
}
