############ TABELAS BASE DE DADOS snalp ############

CREATE DATABASE snalp;

### USUARIO ###

CREATE TABLE usuario (
id_usuario bigint NOT NULL AUTO_INCREMENT,
nome varchar(50),
senha varchar(50),
email varchar(50),
data_cadastro date,
constraint pkusuario primary key (id_usuario),
constraint ukemail unique (email)
);

### WORKSPACE ###

CREATE TABLE workspace (
id_workspace bigint not null auto_increment,
titulo varchar(50),
descricao varchar(255),
data_criacao date,
id_usuario bigint,
constraint pkworkspace primary key (id_workspace),
constraint fkusuario foreign key (id_usuario) references usuario (id_usuario) ON DELETE CASCADE
);

### STATUS ###

CREATE TABLE status (
id_status bigint not null auto_increment,
titulo varchar(50),
cor varchar(7),
ordem int,
id_workspace bigint,
constraint pkstatus primary key (id_status),
constraint fkworkspacestatus foreign key (id_workspace) references workspace (id_workspace) ON DELETE CASCADE
);

### ETIQUETA ###

CREATE TABLE etiqueta (
id_etiqueta bigint not null auto_increment,
titulo varchar(30),
cor varchar(7),
id_workspace bigint,
constraint pketiqueta primary key (id_etiqueta),
constraint fkworkspaceetiqueta foreign key (id_workspace) references workspace (id_workspace) ON DELETE CASCADE
);

### TAREFA ###

CREATE TABLE tarefa (
id_tarefa bigint not null auto_increment,
titulo varchar(200),
descricao varchar(500),
data_inicio date,
data_conclusao date,
data_entrega date,
ordem int,
concluido tinyint,
id_status bigint,
constraint pktarefa primary key (id_tarefa),
constraint fkstatus foreign key (id_status) references status (id_status) ON DELETE CASCADE
);

### SUBTAREFA ###

CREATE TABLE subtarefa (
id_subtarefa bigint not null auto_increment,
descricao varchar(100),
concluido tinyint,
id_tarefa bigint,
constraint pksubtarefa primary key (id_subtarefa),
constraint fktarefa foreign key (id_tarefa) references tarefa (id_tarefa) ON DELETE CASCADE
);

### TAREFA_ETIQUETA ###

CREATE TABLE tarefa_etiqueta (
id_tarefa bigint,
id_etiqueta bigint,
constraint fktarefaetiqueta foreign key (id_tarefa) references tarefa (id_tarefa) ON DELETE CASCADE,
constraint fketiqueta foreign key (id_etiqueta) references etiqueta (id_etiqueta) ON DELETE CASCADE
);

### POMODORO ###

CREATE TABLE pomodoro (
id_pomodoro bigint not null auto_increment,
titulo varchar(50),
tempo int,
pausa int,
serie int,
id_usuario bigint,
constraint pkpomodoro primary key (id_pomodoro),
constraint fkpomodorousuario foreign key (id_usuario) references usuario (id_usuario) ON DELETE CASCADE
);

### OBJETIVO ###

CREATE TABLE objetivo (
id_objetivo bigint not null auto_increment,
titulo varchar(100),
descricao varchar(255),
data_criacao date,
data_fim date,
ativo tinyint,
id_usuario bigint,
constraint pkobjetivo primary key (id_objetivo),
constraint fkobjetivousuario foreign key (id_usuario) references usuario (id_usuario) ON DELETE CASCADE
);

### HUMOR ###

CREATE TABLE humor (
id_humor bigint not null auto_increment,
descricao varchar(10),
emoji varchar(1),
cor varchar(7),
ativo tinyint,
id_usuario bigint,
constraint pkhumor primary key (id_humor),
constraint fkhumorusuario foreign key (id_usuario) references usuario (id_usuario) ON DELETE CASCADE
);

### CATEGORIA ###

CREATE TABLE categoria (
id_categoria bigint not null auto_increment,
titulo varchar(50),
ativo tinyint,
id_usuario bigint,
constraint pkcategoria primary key (id_categoria),
constraint fkcategoriausuario foreign key (id_usuario) references usuario (id_usuario) ON DELETE CASCADE
);

### ATIVIDADE ###

CREATE TABLE atividade (
id_atividade bigint not null auto_increment,
descricao varchar(100),
ativo tinyint,
id_categoria bigint,
constraint pkatividade primary key (id_atividade),
constraint fkcategoria foreign key (id_categoria) references categoria (id_categoria) ON DELETE CASCADE
);

### MOODTRACKER ###

CREATE TABLE moodtracker (
id_moodtracker bigint not null auto_increment,
data date,
descricao varchar(255),
cumpriu_objetivo tinyint,
id_usuario bigint,
id_humor bigint,
constraint pkmoodtracker primary key (id_moodtracker),
constraint fkmoodtrackerusuario foreign key (id_usuario) references usuario (id_usuario) ON DELETE CASCADE,
constraint fkhumor foreign key (id_humor) references humor (id_humor) ON DELETE CASCADE
);

### MOODTRACKER_ATIVIDADE ###

CREATE TABLE moodtracker_atividade (
id_moodtracker bigint,
id_atividade bigint,
constraint fkmoodtracker foreign key (id_moodtracker) references moodtracker (id_moodtracker) ON DELETE CASCADE,
constraint fkatividade foreign key (id_atividade) references atividade (id_atividade) ON DELETE CASCADE
);

### HISTORICO POMODORO ###

CREATE TABLE pomodoro_historico (
id_historico bigint not null auto_increment, 
titulo varchar(50), 
tempo int, pausa int, 
serie int, 
data date, 
id_usuario bigint, 
constraint pkhistorico primary key (id_historico), 
constraint fkhistoricousuario foreign key (id_usuario) references usuario (id_usuario) ON DELETE CASCADE
);

### CORES WORKSPACE ###

CREATE TABLE picker_workspace (
id int not null auto_increment, 
cor varchar(7), 
constraint pkpickerworkspace primary key(id)
);

### CORES HUMOR ###

CREATE TABLE picker_humor (
id int not null auto_increment, 
cor varchar(7), 
constraint pkpickerhumor primary key (id)
);

### EMOJI HUMOR ###

CREATE TABLE emoji_humor (
id int not null auto_increment, 
emoji varchar(1), 
constraint pkemojihumor primary key (id)
);