package dao;

import beans.Usuario;
import beans.Workspace;
import exception.DAOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class WorkspaceDAO {
    
    private ConnectionFactory connectionFactory;
    
    //queries
    private final String insert = "INSERT INTO workspace (titulo, descricao, data_criacao, id_usuario) VALUES (?,?,CURRENT_DATE,?)";
    private final String update = "UPDATE workspace SET titulo = ?, descricao = ? WHERE id_workspace = ?";
    private final String delete = "DELETE FROM workspace WHERE id_workspace = ?";
    private final String select = "SELECT * FROM workspace WHERE id_usuario = ?";
    private final String search = "SELECT * FROM workspace WHERE id_workspace = ?";
    
    //queries para as estatísticas de produtividade: quantidade de tarefas concluídas por período
    private final String selectTarefaCountDia =      "SELECT count(t.id_tarefa) AS 'qtde' FROM tarefa T, status S WHERE T.data_conclusao = CURDATE() AND T.id_status = S.id_status AND S.id_workspace = ?";
    private final String selectTarefaCountSemana =   "SELECT count(T.id_tarefa) AS 'qtde' FROM tarefa T, status S WHERE T.data_conclusao BETWEEN (CURDATE() - INTERVAL 1 WEEK) AND CURDATE() AND T.id_status = S.id_status AND S.id_workspace = ?";
    private final String selectTarefaCountMes =      "SELECT count(t.id_tarefa) AS 'qtde' FROM tarefa T, status S WHERE T.data_conclusao BETWEEN (CURDATE() - INTERVAL 1 MONTH) AND CURDATE() AND T.id_status = S.id_status AND S.id_workspace = ?";
    private final String selectTarefaCountSemestre = "SELECT count(t.id_tarefa) AS 'qtde' FROM tarefa T, status S WHERE T.data_conclusao BETWEEN (CURDATE() - INTERVAL 6 MONTH) AND CURDATE() AND T.id_status = S.id_status AND S.id_workspace = ?";
    private final String selectTarefaCountAno =      "SELECT count(t.id_tarefa) AS 'qtde' FROM tarefa T, status S WHERE T.data_conclusao BETWEEN (CURDATE() - INTERVAL 1 YEAR) AND CURDATE() AND T.id_status = S.id_status AND S.id_workspace = ?";
    private final String selectTarefaCountTotal =    "SELECT count(t.id_tarefa) AS 'qtde' FROM tarefa T, status S WHERE T.concluido = 1 AND T.id_status = S.id_status AND S.id_workspace = ?";
    
    //queries para os gráficos de produtividade
    private final String selectTarefaCount = "SELECT count(t.id_tarefa) AS 'qtde' FROM tarefa T, status S WHERE T.data_conclusao = DATE(NOW() - INTERVAL ? DAY) AND T.id_status = S.id_status AND S.id_workspace = ?";
    
    private final String selectAvgSemana =   "SELECT AVG( DATEDIFF(IFNULL((T.data_conclusao), CURDATE()), T.data_inicio) ) AS 'diasAteConclusao' FROM tarefa T, status S WHERE T.data_inicio > (CURDATE() - INTERVAL 1 WEEK) AND T.id_status = S.id_status AND S.id_workspace = ?;";
    private final String selectAvgMes =      "SELECT AVG( DATEDIFF(IFNULL((T.data_conclusao), CURDATE()), T.data_inicio) ) AS 'diasAteConclusao' FROM tarefa T, status S WHERE T.data_inicio > (CURDATE() - INTERVAL 1 MONTH) AND T.id_status = S.id_status AND S.id_workspace = ?;";
    private final String selectAvgSemestre = "SELECT AVG( DATEDIFF(IFNULL((T.data_conclusao), CURDATE()), T.data_inicio) ) AS 'diasAteConclusao' FROM tarefa T, status S WHERE T.data_inicio > (CURDATE() - INTERVAL 6 MONTH) AND T.id_status = S.id_status AND S.id_workspace = ?;";
    private final String selectAvgAno =      "SELECT AVG( DATEDIFF(IFNULL((T.data_conclusao), CURDATE()), T.data_inicio) ) AS 'diasAteConclusao' FROM tarefa T, status S WHERE T.data_inicio > (CURDATE() - INTERVAL 1 YEAR) AND T.id_status = S.id_status AND S.id_workspace = ?;";
    private final String selectAvgTotal =    "SELECT AVG( DATEDIFF(IFNULL((T.data_conclusao), CURDATE()), T.data_inicio) ) AS 'diasAteConclusao' FROM tarefa T, status S WHERE T.data_inicio > '2000-01-01' AND T.id_status = S.id_status AND S.id_workspace = ?;";
    
    private final String selectRelacaoTarefaCount = "SELECT count(t.id_tarefa) AS 'qtde' FROM tarefa T, status S WHERE T.concluido = ? AND T.id_status = S.id_status AND S.id_workspace = ?";
    
    private final String selectTarefaAbertaCountStatus = "SELECT S.titulo AS 'status', COUNT(*) AS 'qtde' FROM tarefa T, status S WHERE T.concluido = 0 AND T.id_status = S.id_status AND S.id_workspace = ? GROUP BY S.id_status ORDER BY S.ordem";
    
    //queries para as estatísticas gerais: quantidade de tarefas concluídas por período em todas as workspaces do usuário
    private final String selectGeralTerefaCountDia =    "SELECT count(T.id_tarefa) AS 'qtde' FROM tarefa T, status S, workspace W WHERE T.data_conclusao = CURDATE() AND T.id_status = S.id_status AND S.id_workspace = W.id_workspace AND W.id_usuario = ?";
    private final String selectGeralTerefaCountSemana = "SELECT count(T.id_tarefa) AS 'qtde' FROM tarefa T, status S, workspace W WHERE T.data_conclusao BETWEEN (CURDATE() - INTERVAL 1 WEEK) AND CURDATE() AND T.id_status = S.id_status AND S.id_workspace = W.id_workspace AND W.id_usuario = ?";
    private final String selectGeralTerefaCountMes =    "SELECT count(T.id_tarefa) AS 'qtde' FROM tarefa T, status S, workspace W WHERE T.data_conclusao BETWEEN (CURDATE() - INTERVAL 1 MONTH) AND CURDATE() AND T.id_status = S.id_status AND S.id_workspace = W.id_workspace AND W.id_usuario = ?";
    
    public WorkspaceDAO(ConnectionFactory conFactory) {
        this.connectionFactory = conFactory;
    }
    
    //Insere uma nova workspace na base de dados
    public void inserir(Workspace w, Usuario u) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtAdiciona = connection.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
        try{
            // seta os valores
            stmtAdiciona.setString(1, w.getTitulo());
            stmtAdiciona.setString(2, w.getDescricao());
            stmtAdiciona.setLong(3, u.getIdUsuario());
            // executa
            stmtAdiciona.execute();
            //Seta id da subtarefa
            rs = stmtAdiciona.getGeneratedKeys();
            rs.next();
            long id = rs.getLong(1);
            w.setIdWorkspace(id);
        } finally{
            stmtAdiciona.close();
            if(rs != null) rs.close();
        }
    }
    
    //Atualiza titulo e descricao da workspace na base de dados
    public void atualizar(Workspace w) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(update);
        try{
            //seta informações da workpace
            stmtAtualiza.setString(1, w.getTitulo());
            stmtAtualiza.setString(2, w.getDescricao());
            stmtAtualiza.setLong(3, w.getIdWorkspace());
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }

    //Exclui uma workspace da base de dados
    public void remover(long idWorkspace) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtExcluir;
        stmtExcluir = connection.prepareStatement(delete);
        try {
            //seta id da workspace
            stmtExcluir.setLong(1, idWorkspace);
            //executa query
            stmtExcluir.executeUpdate();
        } finally{
            stmtExcluir.close();
        }
    }
    
    //Busca e retorna lista de workspaces de um usuario passado como parametro
    public List<Workspace> listar(Usuario u) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtListar = connection.prepareStatement(select);
        List<Workspace> lista = new ArrayList<>();
        try {
            //seta parametro de busca
            stmtListar.setLong(1, u.getIdUsuario());
            //executa query
            rs = stmtListar.executeQuery();
            //enquanto houver resultados da query
            while(rs.next()){
                //resgata cada atributo da workspace
                long idWorkspace = rs.getLong("id_workspace");
                String titulo = rs.getString("titulo");
                String descricao = rs.getString("descricao");
                LocalDate data = rs.getDate("data_criacao").toLocalDate();
                //insere na lista uma instancia da workspace com atributos retornados do banco de dados
                lista.add(new Workspace(idWorkspace,titulo,descricao,data));
            }
            //retorna a lista de workspaces para a facade
            return lista;
        } finally{
            stmtListar.close();
        }
    }
    
    //Busca uma workspace com base no parametro de id
    public Workspace buscar(long idWorkspace) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtBuscar = connection.prepareStatement(search);
        try{
            //seta parametro de busca
            stmtBuscar.setLong(1, idWorkspace);
            //executa query
            rs = stmtBuscar.executeQuery();
            //se encontrou workspace, retorna instancia da workspace com os atributos da query para a facade
            if(rs.next()) return new Workspace(rs.getLong("id_workspace"),rs.getString("titulo"),rs.getString("descricao"),rs.getDate("data_criacao").toLocalDate());
            //se nao encontrou workspace, retorna exceção para a facade
            else throw new SQLException();
        } finally {
            stmtBuscar.close();
        }
    }
    
    //Retorna uma lista contendo as estatísticas de produtividade da workspace selecionada pelo usuario
    public List<Integer> listarEstatisticas(Workspace workspace) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
            
            List<Integer> listaEstatisticas = new ArrayList<>();
            
            PreparedStatement stmt = con.prepareStatement(selectTarefaCountDia);
            stmt.setLong(1, workspace.getIdWorkspace());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) listaEstatisticas.add(rs.getInt("qtde"));

            stmt = con.prepareStatement(selectTarefaCountSemana);
            stmt.setLong(1, workspace.getIdWorkspace());
            rs = stmt.executeQuery();
            if (rs.next()) listaEstatisticas.add(rs.getInt("qtde"));
            
            stmt = con.prepareStatement(selectTarefaCountMes);
            stmt.setLong(1, workspace.getIdWorkspace());
            rs = stmt.executeQuery();
            if (rs.next()) listaEstatisticas.add(rs.getInt("qtde"));
            
            stmt = con.prepareStatement(selectTarefaCountSemestre);
            stmt.setLong(1, workspace.getIdWorkspace());
            rs = stmt.executeQuery();
            if (rs.next()) listaEstatisticas.add(rs.getInt("qtde"));
            
            stmt = con.prepareStatement(selectTarefaCountAno);
            stmt.setLong(1, workspace.getIdWorkspace());
            rs = stmt.executeQuery();
            if (rs.next()) listaEstatisticas.add(rs.getInt("qtde"));
            
            stmt = con.prepareStatement(selectTarefaCountTotal);
            stmt.setLong(1, workspace.getIdWorkspace());
            rs = stmt.executeQuery();
            if (rs.next()) listaEstatisticas.add(rs.getInt("qtde"));

            stmt.close();

            return listaEstatisticas;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
    //Retorna uma lista contendo a qtde de tarefas concluidas diariamente nos últimos sete dias
    public List<Integer> gerarGraficoProdutividadeSemanal(Workspace workspace) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
            
            List<Integer> listaProdutividadeSemanal = new ArrayList<>();
            
            for (int i = 0; i < 7; i++){
                PreparedStatement stmt = con.prepareStatement(selectTarefaCount);
                stmt.setInt(1, i);
                stmt.setLong(2, workspace.getIdWorkspace());
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) listaProdutividadeSemanal.add(rs.getInt("qtde"));
                stmt.close();
            }

            return listaProdutividadeSemanal;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
    //Retorna uma lista contendo média de dias até a conclusão de tarefas por período
    public List<Integer> gerarGraficoMediaDiasAteConclusao(Workspace workspace) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
            
            List<Integer> listaMediaDiasAteConclusao = new ArrayList<>();
            
            PreparedStatement stmt = con.prepareStatement(selectAvgSemana);
            stmt.setLong(1, workspace.getIdWorkspace());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) listaMediaDiasAteConclusao.add(rs.getInt("diasAteConclusao"));
            
            stmt = con.prepareStatement(selectAvgMes);
            stmt.setLong(1, workspace.getIdWorkspace());
            rs = stmt.executeQuery();
            if (rs.next()) listaMediaDiasAteConclusao.add(rs.getInt("diasAteConclusao"));
            
            stmt = con.prepareStatement(selectAvgSemestre);
            stmt.setLong(1, workspace.getIdWorkspace());
            rs = stmt.executeQuery();
            if (rs.next()) listaMediaDiasAteConclusao.add(rs.getInt("diasAteConclusao"));
            
            stmt = con.prepareStatement(selectAvgAno);
            stmt.setLong(1, workspace.getIdWorkspace());
            rs = stmt.executeQuery();
            if (rs.next()) listaMediaDiasAteConclusao.add(rs.getInt("diasAteConclusao"));
            
            stmt = con.prepareStatement(selectAvgTotal);
            stmt.setLong(1, workspace.getIdWorkspace());
            rs = stmt.executeQuery();
            if (rs.next()) listaMediaDiasAteConclusao.add(rs.getInt("diasAteConclusao"));
            
            stmt.close();
            
            return listaMediaDiasAteConclusao;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
    //Retorna uma lista contendo a qtde de tarefas concluídas e tarefas não concluídas
    public List<Integer> gerarGraficoRelacaoTarefas(Workspace workspace) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
            
            List<Integer> listaRelacaoTarefas = new ArrayList<>();
            
            PreparedStatement stmt = con.prepareStatement(selectRelacaoTarefaCount);
            stmt.setInt(1, 0);
            stmt.setLong(2, workspace.getIdWorkspace());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) listaRelacaoTarefas.add(rs.getInt("qtde"));
            
            stmt = con.prepareStatement(selectRelacaoTarefaCount);
            stmt.setInt(1, 1);
            stmt.setLong(2, workspace.getIdWorkspace());
            rs = stmt.executeQuery();
            if (rs.next()) listaRelacaoTarefas.add(rs.getInt("qtde"));
                
            stmt.close();

            return listaRelacaoTarefas;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
    //Retorna um mapa contendo os status da workspace e suas respectivas qtdes de tarefas não concluídas
    public HashMap<String, Integer> gerarGraficoTarefasAbertasPorStatus(Workspace workspace) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
            
            HashMap<String, Integer> mapaTarefasAbertasPorStatus = new HashMap<String, Integer>();
            
            PreparedStatement stmt = con.prepareStatement(selectTarefaAbertaCountStatus);
            stmt.setLong(1, workspace.getIdWorkspace());
            ResultSet rs = stmt.executeQuery();
            while(rs.next()) {
                mapaTarefasAbertasPorStatus.put(rs.getString("status"), rs.getInt("qtde"));
            }
                
            stmt.close();

            return mapaTarefasAbertasPorStatus;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }

    //Retorna uma lista contendo as estatísticas de quantidade de tarefas concluídas por período
    public List<Integer> listarEstatisticasGerais(Usuario usuario) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
            
            List<Integer> listaEstatisticasGerais = new ArrayList<>();
            
            PreparedStatement stmt = con.prepareStatement(selectGeralTerefaCountDia);
            stmt.setLong(1, usuario.getIdUsuario());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) listaEstatisticasGerais.add(rs.getInt("qtde"));

            stmt = con.prepareStatement(selectGeralTerefaCountSemana);
            stmt.setLong(1, usuario.getIdUsuario());
            rs = stmt.executeQuery();
            if (rs.next()) listaEstatisticasGerais.add(rs.getInt("qtde"));
            
            stmt = con.prepareStatement(selectGeralTerefaCountMes);
            stmt.setLong(1, usuario.getIdUsuario());
            rs = stmt.executeQuery();
            if (rs.next()) listaEstatisticasGerais.add(rs.getInt("qtde"));

            stmt.close();

            return listaEstatisticasGerais;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
}