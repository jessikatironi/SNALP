package dao;

import beans.Atividade;
import beans.Categoria;
import beans.Usuario;
import exception.AtividadeException;
import exception.DAOException;
import facade.AtividadeFacade;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAO {

    private final ConnectionFactory connectionFactory;
    
    private final String select = "SELECT * FROM categoria WHERE id_usuario = ? AND ativo = 1";         // listar categorias
    private final String search = "SELECT * FROM categoria WHERE id_categoria = ?";                     // buscar categoria
    private final String insert = "INSERT INTO categoria (titulo, ativo, id_usuario) VALUES (?, 1, ?)"; // criar categoria
    private final String update = "UPDATE categoria SET titulo = ? WHERE id_categoria = ?";             // alterar categoria
    private final String delete = "UPDATE categoria SET ativo = 0 WHERE id_categoria = ?";              // remover categoria 
    
    public CategoriaDAO() {
        this.connectionFactory = new ConnectionFactory();
    }
    
    //Retorna uma lista de todas as categorias de um usuário
    public List<Categoria> listarCategorias(Usuario usuario) throws SQLException, DAOException, AtividadeException {
        try {
            Connection con = connectionFactory.getConnection();

            PreparedStatement stmt = con.prepareStatement(select);
            stmt.setLong(1, usuario.getIdUsuario());
            ResultSet rs = stmt.executeQuery();

            List<Categoria> categorias = new ArrayList<>();

            while (rs.next()) {
                Categoria categoria = new Categoria();

                categoria.setIdCategoria(rs.getLong("id_categoria"));
                categoria.setTituloCategoria(rs.getString("titulo"));
                
                List<Atividade> listaAtividades = AtividadeFacade.listarAtividades(categoria);
                categoria.setListaAtividadesCategoria(listaAtividades);

                categorias.add(categoria);
            }

            stmt.close();

            return categorias;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }

    //Retorna os dados de uma categoria
    public Categoria buscarCategoria(long idCategoria) throws SQLException, DAOException, AtividadeException {
        try {
            Connection con = connectionFactory.getConnection();

            PreparedStatement stmt = con.prepareStatement(search);
            stmt.setLong(1, idCategoria);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Categoria categoria = new Categoria();

                categoria.setIdCategoria(rs.getLong("id_categoria"));
                categoria.setTituloCategoria(rs.getString("titulo"));
                
                List<Atividade> listaAtividades = AtividadeFacade.listarAtividades(categoria);
                categoria.setListaAtividadesCategoria(listaAtividades);
                
                stmt.close();
                return categoria;
            } else {
                stmt.close();
                throw new SQLException();
            }
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }

    //Insere uma nova categoria no banco de dados
    public void criarCategoria(Categoria categoria, Usuario usuario) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            PreparedStatement stmt = con.prepareStatement(insert);
            stmt.setString(1, categoria.getTituloCategoria());
            stmt.setLong(2, usuario.getIdUsuario());

            int x = stmt.executeUpdate();

            stmt.close();
        
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }

    //Atualiza os dados de uma categoria no banco de dados
    public void atualizarCategoria(Categoria categoria) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            PreparedStatement stmt = con.prepareStatement(update);
            stmt.setString(1, categoria.getTituloCategoria());
            stmt.setLong(2, categoria.getIdCategoria());
            int x = stmt.executeUpdate();

            stmt.close();
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }

    //Remove uma categoria no banco de dados: atualiza o atributo "ativo" para zero.
    public void removerCategoria(long idCategoria) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            PreparedStatement stmt = con.prepareStatement(delete);
            stmt.setLong(1, idCategoria);
            int x = stmt.executeUpdate();
        
            stmt.close();
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
}
