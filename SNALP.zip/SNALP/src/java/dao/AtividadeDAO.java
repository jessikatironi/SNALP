package dao;

import beans.Atividade;
import beans.Categoria;
import exception.AtividadeException;
import exception.CategoriaException;
import exception.DAOException;
import facade.CategoriaFacade;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AtividadeDAO {
    
    private final ConnectionFactory connectionFactory;
    
    private final String select = "SELECT * FROM atividade WHERE id_categoria = ? AND ativo = 1";                   // listar atividades por categoria
    private final String search = "SELECT * FROM atividade WHERE id_atividade = ?";                                 // buscar atividade
    private final String insert = "INSERT INTO atividade (descricao, ativo, id_categoria) VALUES (?, 1, ?);";       // criar atividade
    private final String update = "UPDATE atividade SET descricao = ?, id_categoria = ? WHERE id_atividade = ?";    // atualizar atividade
    private final String delete = "UPDATE atividade SET ativo = 0 WHERE id_atividade = ?";                          // remover atividade
            
    
    public AtividadeDAO() {
        this.connectionFactory = new ConnectionFactory();
    }
    
    //Retorna uma lista de todas as atividades de uma categoria do usuário
    public List<Atividade> listarAtividades(Categoria categoria) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();

            PreparedStatement stmt = con.prepareStatement(select);
            stmt.setLong(1, categoria.getIdCategoria());
            ResultSet rs = stmt.executeQuery();

            List<Atividade> atividades = new ArrayList<>();

            while (rs.next()) {
                Atividade atividade = new Atividade();

                atividade.setIdAtividade(rs.getLong("id_atividade"));
                atividade.setDescricaoAtividade(rs.getString("descricao"));

                atividades.add(atividade);
            }

            stmt.close();

            return atividades;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
    //Retorna os dados de uma atividade do usuário
    public Atividade buscarAtividade(long idAtividade) throws SQLException, DAOException, CategoriaException, AtividadeException {
        try {
            Connection con = connectionFactory.getConnection();

            PreparedStatement stmt = con.prepareStatement(search);
            stmt.setLong(1, idAtividade);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Atividade atividade = new Atividade();

                atividade.setIdAtividade(rs.getLong("id_atividade"));
                atividade.setDescricaoAtividade(rs.getString("descricao"));
                
                Categoria categoria = CategoriaFacade.buscarCategoria(rs.getLong("id_categoria"));
                atividade.setCategoriaAtividade(categoria);
                
                stmt.close();
                return atividade;
            } else {
                stmt.close();
                throw new SQLException();
            }
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
    //Insere uma nova atividade no banco de dados
    public void criarAtividade(Atividade atividade) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            PreparedStatement stmt = con.prepareStatement(insert);
            stmt.setString(1, atividade.getDescricaoAtividade());
            stmt.setLong(2, atividade.getCategoriaAtividade().getIdCategoria());

            int x = stmt.executeUpdate();

            stmt.close();
        
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
    //Atualiza os dados de uma atividade no banco de dados
    public void atualizarAtividade(Atividade atividade) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            PreparedStatement stmt = con.prepareStatement(update);
            stmt.setString(1, atividade.getDescricaoAtividade());
            stmt.setLong(2, atividade.getCategoriaAtividade().getIdCategoria());
            stmt.setLong(3, atividade.getIdAtividade());
            int x = stmt.executeUpdate();

            stmt.close();
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
    //Remove uma atividade no banco de dados: atualiza o atributo "ativo" para zero
    public void removerAtividade(long idAtividade) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            PreparedStatement stmt = con.prepareStatement(delete);
            stmt.setLong(1, idAtividade);
            int x = stmt.executeUpdate();
        
            stmt.close();
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
}
