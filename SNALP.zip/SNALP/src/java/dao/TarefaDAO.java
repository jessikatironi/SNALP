package dao;

import beans.Status;
import beans.Tarefa;
import exception.DAOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TarefaDAO {
    private final ConnectionFactory connectionFactory;
    
    //queries
    private final String insert = "INSERT INTO tarefa SET titulo = ?, descricao = ?, data_inicio = now(), data_entrega = ?, "
                                + "ordem = (select count(t.id_tarefa) from tarefa t where t.id_status = ?)+1, concluido = false, id_status = ?";
    private final String delete = "DELETE FROM tarefa WHERE id_tarefa = ?";
    private final String updateTitulo = "UPDATE tarefa SET titulo = ? WHERE id_tarefa = ?";
    private final String updateDesc = "UPDATE tarefa SET descricao = ? WHERE id_tarefa = ?";
    private final String updateData = "UPDATE tarefa SET data_entrega = ? WHERE id_tarefa = ?";
    private final String search = "SELECT t.id_tarefa, t.titulo, t.descricao, t.data_entrega, t.ordem, t.concluido, s.id_status, s.titulo, (SELECT count(*) FROM subtarefa WHERE id_tarefa = ?) as total,"
                                + " (SELECT count(*) FROM subtarefa WHERE concluido = true AND id_tarefa = ?) as conc FROM tarefa t INNER JOIN status s ON t.id_status = s.id_status AND id_tarefa = ?";
    //ordem da tarefa a ser inserida em um status
    private final String ordem = "SELECT count(id_tarefa)+1 from tarefa where id_status = ?";
    
    //Lista de tarefas e seus status de uma workspace ordenadas pela ordem do status e ordem da tarefa
    private final String select = "SELECT t.id_tarefa, t.titulo, t.descricao, t.data_entrega, t.ordem, t.concluido, s.id_status, s.titulo, s.cor FROM tarefa t INNER JOIN status s ON t.id_status=s.id_status "
                                + "AND t.id_status IN (SELECT st.id_status FROM status st WHERE st.id_workspace = ?) ORDER BY s.ordem ASC, t.ordem DESC";
    //lista de tarefas concluídas de uma workspace
    private final String tarefasConcluidas = "SELECT t.id_tarefa, t.titulo, t.descricao, t.data_entrega, t.ordem, t.concluido, s.id_status, s.titulo, s.cor, (SELECT count(*) FROM subtarefa "
                                            + "WHERE id_tarefa = t.id_tarefa) as total, (SELECT count(*) FROM subtarefa WHERE concluido = true AND id_tarefa = t.id_tarefa) as conc  FROM "
                                            + "tarefa t INNER JOIN status s ON t.id_status=s.id_status AND t.id_status IN (SELECT st.id_status FROM status st WHERE st.id_workspace = ?) AND "
                                            + "t.concluido = true ORDER BY t.data_conclusao DESC";
    //lista de tarefas não concluídas de uma workspace
    private final String tarefasAtivas = "SELECT t.id_tarefa, t.titulo, t.descricao, t.data_entrega, t.ordem, t.concluido, s.id_status, s.titulo, s.cor, (SELECT count(*) FROM subtarefa "
                                        + "WHERE id_tarefa = t.id_tarefa) as total, (SELECT count(*) FROM subtarefa WHERE concluido = true AND id_tarefa = t.id_tarefa) as conc  "
                                        + "FROM tarefa t INNER JOIN status s ON t.id_status=s.id_status AND t.id_status IN (SELECT st.id_status FROM status st WHERE st.id_workspace = ?) "
                                        + "AND t.concluido = false GROUP BY s.id_status, t.ordem ORDER BY s.ordem ASC, t.ordem DESC";
    //retorna lista de tarefas de um status ordenada por ordem DESC
    private final String tarefasStatus = "SELECT t.id_tarefa, t.titulo, t.descricao, t.data_entrega, t.ordem, s.id_status, s.titulo, s.ordem , (SELECT count(*) FROM subtarefa "
                                        + "WHERE id_tarefa = t.id_tarefa) as total, (SELECT count(*) FROM subtarefa WHERE concluido = true AND id_tarefa = t.id_tarefa) as conc"
                                        + " FROM tarefa t INNER JOIN status s ON t.id_status=s.id_status AND t.id_status = ? AND t.concluido = false ORDER BY t.ordem DESC";
    
    private final String tarefasCalendario = "SELECT t.id_tarefa, t.titulo, t.data_entrega FROM tarefa t WHERE t.id_status IN (SELECT st.id_status FROM status st WHERE st.id_workspace = ?)"
                                            + " AND concluido = false AND t.data_entrega IS NOT NULL order by t.data_entrega ASC";

    //atualiza ordem das tarefas ao mudar status (corrige ordem das tarefas do novo status e do status antigo)
    private final String fixOrderOldStatus = "UPDATE tarefa SET ordem = ordem - 1 WHERE id_status = ? AND ordem > ? AND id_tarefa <> ?";
    private final String fixOrderNewStatus = "UPDATE tarefa SET ordem = ordem + 1 WHERE id_status = ? AND ordem >= ?";
    
    //atualiza ordem das tarefas ao mudar ordem da tarefa no mesmo status desconsiderando a tarefa que está sendo movimentada
    private final String fixOrderUp = "UPDATE tarefa SET ordem = ordem - 1 WHERE id_status = ? AND ordem > ? AND ordem <= ? AND id_tarefa <> ?";
    private final String fixOrderDown = "UPDATE tarefa SET ordem = ordem + 1 WHERE id_status = ? AND ordem < ? AND ordem >= ? AND id_tarefa <> ?";
    //muda status de uma tarefa e sua ordem
    private final String statusChange = "UPDATE tarefa SET id_status = ?, ordem = ? WHERE id_tarefa = ?";
    //muda ordem da tarefa dentro de um mesmo status
    private final String orderChange = "UPDATE tarefa SET ordem = ? WHERE id_tarefa = ?";
    
    //completa tarefa ou retorna para estado não concluído
    private final String complete = "UPDATE tarefa SET concluido = true, id_status = (select id_status from status where ordem = 0 and id_workspace = ?), ordem = 0, data_conclusao = now() WHERE id_tarefa = ?";
    private final String uncomplete = "UPDATE tarefa SET concluido = false, data_conclusao = null, ordem = ?, id_status = ? WHERE id_tarefa = ?";

    public TarefaDAO(ConnectionFactory connectionFactory) {
        this.connectionFactory = connectionFactory;
    }
    
    //Insere uma nova tarefa na base de dados
    public void inserir(Tarefa t, long idStatus) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtAdiciona = connection.prepareStatement(insert);
        try{
            // seta os valores
            stmtAdiciona.setString(1, t.getTitulo());
            stmtAdiciona.setString(2, t.getDescricao());
            if(t.getDataEntrega() != null) stmtAdiciona.setDate(3, Date.valueOf(t.getDataEntrega()));
            else stmtAdiciona.setDate(3, null);
            stmtAdiciona.setLong(4, idStatus);
            stmtAdiciona.setLong(5, idStatus);

            // executa query
            stmtAdiciona.execute();
        } finally{
            stmtAdiciona.close();
            if(rs != null) rs.close();
        }
    }
    
   //Atualiza o titulo da tarefa
    public void atualizarTitulo(Tarefa t) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(updateTitulo);
        try{
            //seta informações da tarefa
            stmtAtualiza.setString(1, t.getTitulo());
            stmtAtualiza.setLong(2, t.getIdTarefa());
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }
    
    //Atualiza a descricao da tarefa
    public void atualizarDesc(Tarefa t) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(updateDesc);
        try{
            //seta informações da tarefa
            stmtAtualiza.setString(1, t.getDescricao());
            stmtAtualiza.setLong(2, t.getIdTarefa());
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }
    
    //Atualiza a data de entrega da tarefa
    public void atualizarData(Tarefa t) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(updateData);
        try{
            //seta informações da tarefa
            if(t.getDataEntrega() != null) stmtAtualiza.setDate(1, Date.valueOf(t.getDataEntrega()));
            else stmtAtualiza.setDate(1, null);
            stmtAtualiza.setLong(2, t.getIdTarefa());
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }

    //Exclui uma workspace da base de dados
    public void remover(long idTarefa) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtExcluir;
        stmtExcluir = connection.prepareStatement(delete);
        try {
            //seta id da workspace
            stmtExcluir.setLong(1, idTarefa);
            //executa query
            stmtExcluir.executeUpdate();
        } finally{
            stmtExcluir.close();
        }
    }
        
    //Atualiza ordem das tarefas de um status após remoção de uma tarefa
    public void atualizarOrdemDelete(Tarefa t) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(fixOrderOldStatus);
        try{
            //seta informações da tarefa
            stmtAtualiza.setLong(1, t.getStatus().getIdStatus());
            stmtAtualiza.setInt(2, t.getOrdem());
            stmtAtualiza.setLong(3, t.getIdTarefa());
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    } 
    
    //Busca uma tarefa com base no parametro de id
    public Tarefa buscar(long idTarefa) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtBuscar = connection.prepareStatement(search);
        try{
            //seta parametro de busca
            stmtBuscar.setLong(1, idTarefa);
            stmtBuscar.setLong(2, idTarefa);
            stmtBuscar.setLong(3, idTarefa);
            //executa query
            rs = stmtBuscar.executeQuery();
            //se encontrou tarefa, retorna instancia da tarefa com os atributos da query para a facade
            if(rs.next()){
                LocalDate data;
                //valida data nula
                if(rs.getDate("t.data_entrega") == null) data = null;
                else  data = rs.getDate("t.data_entrega").toLocalDate();
                Tarefa t = new Tarefa(rs.getLong("t.id_tarefa"),rs.getString("t.titulo"),rs.getString("t.descricao"),data,rs.getInt("t.ordem"),rs.getBoolean("t.concluido"),new Status(rs.getLong("s.id_status"),rs.getString("s.titulo")));
                t.setQtdeTotal(rs.getInt("total"));
                t.setQtdeConcluida(rs.getInt("conc"));
                return t;
            }
            //se nao encontrou tarefa, retorna exceção para a facade
            else throw new SQLException();
        } finally {
            stmtBuscar.close();
        }
    }
    
    //Busca e retorna lista de tarefas de uma workspace passada como parametro
    public List<Tarefa> listar(long idWorkspace) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtListar = connection.prepareStatement(select);
        List<Tarefa> lista = new ArrayList<>();
        try {
            //seta parametro de busca
            stmtListar.setLong(1, idWorkspace);
            //executa query
            rs = stmtListar.executeQuery();
            //enquanto houver resultados da query
            while(rs.next()){
                //resgata cada atributo da workspace
                long idTarefa = rs.getLong("t.id_tarefa");
                String titulo = rs.getString("t.titulo");
                String descricao = rs.getString("t.descricao");
                int ordem = rs.getInt("t.ordem");
                LocalDate data;
                //valida data nula
                if(rs.getDate("t.data_entrega") == null) data = null;
                else  data = rs.getDate("t.data_entrega").toLocalDate();
                boolean concluido = rs.getBoolean("t.concluido");
                
                long idStatus = rs.getLong("s.id_status");
                String tituloStatus = rs.getString("s.titulo");
                String corStatus = rs.getString("s.cor");
                //insere na lista uma instancia da tarefa com atributos retornados do banco de dados
                lista.add(new Tarefa(idTarefa,titulo,descricao,data,ordem,concluido,new Status(idStatus,tituloStatus,corStatus)));
            }
            //retorna a lista de tarefas para a facade
            return lista;
        } finally{
            stmtListar.close();
            rs.close();
        }
    }
    
    //Busca e retorna lista de tarefas de um status passado como parametro
    public List<Tarefa> tarefasStatus(long status) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtListar = connection.prepareStatement(tarefasStatus);
        List<Tarefa> lista = new ArrayList<>();
        try {
            //seta parametro de busca
            stmtListar.setLong(1, status);
            //executa query
            rs = stmtListar.executeQuery();
            //enquanto houver resultados da query
            while(rs.next()){
                //resgata cada atributo da workspace
                long idTarefa = rs.getLong("t.id_tarefa");
                String titulo = rs.getString("t.titulo");
                String descricao = rs.getString("t.descricao");
                int ordem = rs.getInt("t.ordem");
                LocalDate data;
                //valida data nula
                if(rs.getDate("t.data_entrega") == null) data = null;
                else  data = rs.getDate("t.data_entrega").toLocalDate();
                int total = rs.getInt("total");
                int conc = rs.getInt("conc");
                
                long idStatus = rs.getLong("s.id_status");
                String tituloStatus = rs.getString("s.titulo");
                //instancia a tarefa com atributos retornados do banco de dados
                Tarefa t = new Tarefa(idTarefa,titulo,descricao,data,ordem,new Status(idStatus,tituloStatus));
                t.setQtdeTotal(total);
                t.setQtdeConcluida(conc);
                lista.add(t);
            }
            //retorna a lista de tarefas para a facade
            return lista;
        } finally{
            stmtListar.close();
            rs.close();
        }
    }
    
    //Busca e retorna lista de tarefas concluidas de uma workspace passada como parametro
    public List<Tarefa> listarConcluidas(long idWorkspace) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtListar = connection.prepareStatement(tarefasConcluidas);
        List<Tarefa> lista = new ArrayList<>();
        try {
            //seta parametro de busca
            stmtListar.setLong(1, idWorkspace);
            //executa query
            rs = stmtListar.executeQuery();
            //enquanto houver resultados da query
            while(rs.next()){
                //resgata cada atributo da workspace
                long idTarefa = rs.getLong("t.id_tarefa");
                String titulo = rs.getString("t.titulo");
                String descricao = rs.getString("t.descricao");
                int ordem = rs.getInt("t.ordem");
                LocalDate data;
                //valida data nula
                if(rs.getDate("t.data_entrega") == null) data = null;
                else  data = rs.getDate("t.data_entrega").toLocalDate();
                boolean concluido = rs.getBoolean("t.concluido");
                int total = rs.getInt("total");
                int conc = rs.getInt("conc");
                
                long idStatus = rs.getLong("s.id_status");
                String tituloStatus = rs.getString("s.titulo");
                String corStatus = rs.getString("s.cor");
                //instancia a tarefa com atributos retornados do banco de dados
                Tarefa t = new Tarefa(idTarefa,titulo,descricao,data,ordem,concluido,new Status(idStatus,tituloStatus,corStatus));
                t.setQtdeTotal(total);
                t.setQtdeConcluida(conc);
                lista.add(t);
            }
            //retorna a lista de tarefas para a facade
            return lista;
        } finally{
            stmtListar.close();
            rs.close();
        }
    }
    
    //Busca e retorna lista de tarefas ativas de uma workspace passada como parametro
    public List<Tarefa> listarAtivas(long idWorkspace) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtListar = connection.prepareStatement(tarefasAtivas);
        List<Tarefa> lista = new ArrayList<>();
        try {
            //seta parametro de busca
            stmtListar.setLong(1, idWorkspace);
            //executa query
            rs = stmtListar.executeQuery();
            //enquanto houver resultados da query
            while(rs.next()){
                //resgata cada atributo da workspace
                long idTarefa = rs.getLong("t.id_tarefa");
                String titulo = rs.getString("t.titulo");
                String descricao = rs.getString("t.descricao");
                int ordem = rs.getInt("t.ordem");
                LocalDate data;
                //valida data nula
                if(rs.getDate("t.data_entrega") == null) data = null;
                else  data = rs.getDate("t.data_entrega").toLocalDate();
                boolean concluido = rs.getBoolean("t.concluido");
                int total = rs.getInt("total");
                int conc = rs.getInt("conc");
                
                long idStatus = rs.getLong("s.id_status");
                String tituloStatus = rs.getString("s.titulo");
                String corStatus = rs.getString("s.cor");
                //instancia a tarefa com atributos retornados do banco de dados
                Tarefa t = new Tarefa(idTarefa,titulo,descricao,data,ordem,concluido,new Status(idStatus,tituloStatus,corStatus));
                t.setQtdeTotal(total);
                t.setQtdeConcluida(conc);
                lista.add(t);
            }
            //retorna a lista de tarefas para a facade
            return lista;
        } finally{
            stmtListar.close();
            rs.close();
        }
    }

    //Busca e retorna lista de tarefas ativas de uma workspace que possuem data de entrega
    public List<Tarefa> tarefasCalendario(long idWorkspace) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtListar = connection.prepareStatement(tarefasCalendario);
        List<Tarefa> lista = new ArrayList<>();
        try {
            //seta parametro de busca
            stmtListar.setLong(1, idWorkspace);
            //executa query
            rs = stmtListar.executeQuery();
            //enquanto houver resultados da query
            while(rs.next()){
                //resgata cada atributo da workspace
                long idTarefa = rs.getLong("t.id_tarefa");
                String titulo = rs.getString("t.titulo");
                LocalDate data = rs.getDate("t.data_entrega").toLocalDate();
                
                //instancia a tarefa com atributos retornados do banco de dados
                lista.add(new Tarefa(idTarefa,titulo,data));
            }
            //retorna a lista de tarefas para a facade
            return lista;
        } finally{
            stmtListar.close();
            rs.close();
        }
    }

    //atualiza ordem das tarefas do status antigo ao mudar de status
    public void fixOrderOldStatus(long idStatus, int ordem, long idTarefa) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(fixOrderOldStatus);
        try{
            //seta informações da tarefa
            stmtAtualiza.setLong(1, idStatus);
            stmtAtualiza.setInt(2, ordem);
            stmtAtualiza.setLong(3, idTarefa);
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }
    
    //atualiza ordem das tarefas do status novo ao mudar de status
    public void fixOrderNewStatus(long idStatus, int ordem) throws DAOException, SQLException  {
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(fixOrderNewStatus);
        try{
            //seta informações da tarefa
            stmtAtualiza.setLong(1, idStatus);
            stmtAtualiza.setInt(2, ordem);
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }

    //atualiza ordem das tarefas ao subir tarefa no mesmo status
    public void fixOrderUp (long idStatus, int oldOrdem, int newOrdem, long idTarefa) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(fixOrderUp);
        try{
            //seta informações da tarefa
            stmtAtualiza.setLong(1, idStatus);
            stmtAtualiza.setInt(2, oldOrdem);
            stmtAtualiza.setInt(3, newOrdem);
            stmtAtualiza.setLong(4, idTarefa);
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }
    
    //atualiza ordem das tarefas ao descer tarefa no status
    public void fixOrderDown (long idStatus, int oldOrdem, int newOrdem, long idTarefa) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(fixOrderDown);
        try{
            //seta informações da tarefa
            stmtAtualiza.setLong(1, idStatus);
            stmtAtualiza.setInt(2, oldOrdem);
            stmtAtualiza.setInt(3, newOrdem);
            stmtAtualiza.setLong(4, idTarefa);
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }
   
    //Muda status da tarefa
    public void statusChange(long idStatus, int ordem, long idTarefa) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(statusChange);
        try{
            //seta informações da tarefa
            stmtAtualiza.setLong(1, idStatus);
            stmtAtualiza.setInt(2, ordem);
            stmtAtualiza.setLong(3, idTarefa);
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }
    
    //Muda ordem da tarefa
    public void orderChange(int ordem, long idTarefa) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(orderChange);
        try{
            //seta informações da tarefa
            stmtAtualiza.setInt(1, ordem);
            stmtAtualiza.setLong(2, idTarefa);
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }
    
    //Muda atributo concluido para true
    public void completeTarefa(long idTarefa, long idWorkspace) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(complete);
        try{
            //seta informações da tarefa
            stmtAtualiza.setLong(1, idWorkspace);
            stmtAtualiza.setLong(2, idTarefa);
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }
    
    //Muda atribuito concluido para false
    public void uncompleteTarefa(long idTarefa, long idStatus, int ordem) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(uncomplete);
        try{
            //seta informações da tarefa
            stmtAtualiza.setInt(1, ordem);
            stmtAtualiza.setLong(2, idStatus);
            stmtAtualiza.setLong(3, idTarefa);
            
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }
    
    //Busca ordem de inserção de uma tarefa no final de um status
    public int ordem(long idStatus) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtBuscar = connection.prepareStatement(ordem);
        try{
            //seta parametro de busca
            stmtBuscar.setLong(1, idStatus);
            //executa query
            rs = stmtBuscar.executeQuery();
            //retorna ordem de inserção da tarefa ou exceção
            if(rs.next()) return rs.getInt("count(id_tarefa)+1");
            else throw new SQLException();
        } finally {
            stmtBuscar.close();
        }
    }
}
