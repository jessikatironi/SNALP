package dao;

import exception.DAOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory implements AutoCloseable {
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://localhost:3306/snalp?useSSL=false&allowPublicKeyRetrieval=true";
    private static final String LOGIN = "usuario";
    private static final String SENHA = "senha";
    
    private Connection con = null;
    
    public Connection getConnection() throws DAOException {
        if (con == null){
            try{
                Class.forName(DRIVER);
                con = DriverManager.getConnection(URL,LOGIN,SENHA);
            } catch (ClassNotFoundException e){
                throw new DAOException("Driver do banco não encontrado: "+ DRIVER, e);
            } catch (SQLException e){
                throw new DAOException("Erro conectando ao BD: "+ URL + "/" + LOGIN + "/" + SENHA, e);
            }
        }
        return con;
    }

    @Override
    public void close() throws DAOException {
        if (con != null){
            try{
                con.close();
            } catch (Exception e){
                throw new DAOException("Erro fechando a conexão. IGNORADO",e);
            } finally{
                con = null;
            }
        }
    }
}
