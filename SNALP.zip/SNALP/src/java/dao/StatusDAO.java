package dao;

import beans.Status;
import exception.DAOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StatusDAO {
    private ConnectionFactory connectionFactory;
    
    //queries
    private final String insert = "INSERT INTO status SET titulo = ?, cor = ?, ordem = (SELECT count(o.id_status) FROM status o WHERE o.id_workspace = ?), id_workspace = ?";
    private final String insertPrimeiro = "INSERT INTO status SET titulo = ?, cor = ?, ordem = ?, id_workspace = ?";
    private final String update = "UPDATE status SET titulo = ?, cor = ? WHERE id_status = ?";
    private final String delete = "DELETE FROM status WHERE id_status = ?";
    private final String select = "SELECT * FROM status WHERE id_workspace = ? and ordem > 0 ORDER BY ordem ASC";
    private final String search = "SELECT * FROM status WHERE id_status = ?";
    private final String selectOrdem = "SELECT * FROM status WHERE ordem = ? AND id_workspace = ?";
    private final String disponiveis = "SELECT * FROM status WHERE id_workspace = ? AND id_status <> ? AND ordem > 0";
    private final String selectCores = "SELECT * FROM picker_workspace";

    private final String updateOnDelete = "UPDATE status SET ordem = ordem - 1 WHERE id_workspace = ? AND ordem > ?";
    
    //Mudança de ordem do status
    private final String updateOrder = "UPDATE status SET ordem = ? WHERE id_status = ?";
    private final String updateUp = "UPDATE status SET ordem = ordem + 1 WHERE ordem >= ? and ordem < ? and id_status <> ?";
    private final String updateDown = "UPDATE status SET ordem = ordem - 1 WHERE ordem <= ? and ordem > ? and id_status <> ?";
    
    public StatusDAO(ConnectionFactory conFactory) {
        this.connectionFactory = conFactory;
    }

    //Insere um novo status na base de dados
    public void inserir(Status s, long idWorkspace) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtAdiciona = connection.prepareStatement(insert);
        try{
            // seta os valores
            stmtAdiciona.setString(1, s.getTitulo());
            stmtAdiciona.setString(2, s.getCor());
            stmtAdiciona.setLong(3, idWorkspace);
            stmtAdiciona.setLong(4, idWorkspace);
            // executa
            stmtAdiciona.execute();
        } finally{
            stmtAdiciona.close();
            if(rs != null) rs.close();
        }
    }
    
    //Insere Status de ordem 0 para tarefas concluídas
    public void inserirStatus(long idWorkspace) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtAdiciona = connection.prepareStatement(insertPrimeiro);
        try{
            // seta a id workspace
            stmtAdiciona.setString(1, "Concluídas");
            stmtAdiciona.setString(2, "#294c88");
            stmtAdiciona.setInt(3, 0);
            stmtAdiciona.setLong(4, idWorkspace);
            // executa
            stmtAdiciona.execute();
        } finally{
            stmtAdiciona.close();
            if(rs != null) rs.close();
        }
    }
    
    //Atualiza dados do status na base de dados
    public void atualizar(Status s) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(update);
        try{
            //seta informações do status
            stmtAtualiza.setString(1, s.getTitulo());
            stmtAtualiza.setString(2, s.getCor());
            stmtAtualiza.setLong(3, s.getIdStatus());
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }

    //Exclui um status da base de dados
    public void remover(long idStatus) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtExcluir;
        stmtExcluir = connection.prepareStatement(delete);
        try {
            //seta id do status
            stmtExcluir.setLong(1, idStatus);
            //executa query
            stmtExcluir.executeUpdate();
        } finally{
            stmtExcluir.close();
        }
    }
  
    //Atualiza ordem dos status após remoção de um status
    public void atualizarOrdemDelete(int ordem, long idWorkspace) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(updateOnDelete);
        try{
            //seta informações do status
            stmtAtualiza.setLong(1, idWorkspace);
            stmtAtualiza.setInt(2, ordem);
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }
    

    //Busca e retorna lista de status de uma workspace passado como parametro
    public List<Status> listar(long idWorkspace) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtListar = connection.prepareStatement(select);
        List<Status> lista = new ArrayList<>();
        try {
            //seta parametro de busca
            stmtListar.setLong(1, idWorkspace);
            //executa query
            rs = stmtListar.executeQuery();
            //enquanto houver resultados da query
            while(rs.next()){
                //resgata cada atributo do status
                long idStatus = rs.getLong("id_status");
                String titulo = rs.getString("titulo");
                String cor = rs.getString("cor");
                int ordem = rs.getInt("ordem");
                //insere na lista uma instancia do status com atributos retornados do banco de dados
                lista.add(new Status(idStatus,titulo,cor,ordem));
            }
            //retorna a lista de status para a facade
            return lista;
        } finally{
            stmtListar.close();
        }
    }
    
    //Busca e retorna lista de status disponiveis de uma workspace
    public List<Status> listarDisponiveis(long idWorkspace, long idStatus) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtListar = connection.prepareStatement(disponiveis);
        List<Status> lista = new ArrayList<>();
        try {
            //seta parametro de busca
            stmtListar.setLong(1, idWorkspace);
            stmtListar.setLong(2, idStatus);
            //executa query
            rs = stmtListar.executeQuery();
            //enquanto houver resultados da query
            while(rs.next()){
                //resgata cada atributo do status
                long id = rs.getLong("id_status");
                String titulo = rs.getString("titulo");
                String cor = rs.getString("cor");
                int ordem = rs.getInt("ordem");
                //insere na lista uma instancia do status com atributos retornados do banco de dados
                lista.add(new Status(id,titulo,cor,ordem));
            }
            //retorna a lista de status para a facade
            return lista;
        } finally{
            stmtListar.close();
        }
    }
    
    //Busca um status com base no parametro de id
    public Status buscar(long idStatus) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtBuscar = connection.prepareStatement(search);
        try{
            //seta parametro de busca
            stmtBuscar.setLong(1, idStatus);
            //executa query
            rs = stmtBuscar.executeQuery();
            //se encontrou status, retorna instancia do status com os atributos da query para a facade
            if(rs.next()) return new Status(rs.getLong("id_status"),rs.getString("titulo"),rs.getString("cor"),rs.getInt("ordem"));
            //se nao encontrou status, retorna exceção para a facade
            else throw new SQLException();
        } finally {
            stmtBuscar.close();
        }
    }
    
    //Busca o status de ordem 1 em uma workspace
    public Status buscarOrdem(long idWorkspace) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtBuscar = connection.prepareStatement(selectOrdem);
        try{
            //seta parametro de busca
            stmtBuscar.setInt(1, 1);
            stmtBuscar.setLong(2, idWorkspace);
            //executa query
            rs = stmtBuscar.executeQuery();
            //se encontrou status, retorna instancia do status com os atributos da query para a facade
            if(rs.next()) return new Status(rs.getLong("id_status"),rs.getString("titulo"),rs.getString("cor"),rs.getInt("ordem"));
            //se nao encontrou status, retorna exceção para a facade
            else throw new SQLException();
        } finally {
            stmtBuscar.close();
        }
    }
    
    //Retorna uma lista de todas as cores do color picker para status
    public List<String> listarCores() throws SQLException, DAOException {   
        try {
            Connection con = connectionFactory.getConnection();
            
            PreparedStatement stmt = con.prepareStatement(selectCores);
            ResultSet rs = stmt.executeQuery();
            
            List<String> cores = new ArrayList<>();
            
            while(rs.next()) {
                String cor = rs.getString("cor");
                
                cores.add(cor);
            }
            
            stmt.close();
            
            return cores;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...",e);
        }
    }
    
    //Altera ordem de um status
    public void updateOrdem(long idStatus, int newOrdem) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(updateOrder);
        try{
            //seta informações do status
            stmtAtualiza.setInt(1, newOrdem);
            stmtAtualiza.setLong(2, idStatus);
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }

    //Reordena status - up
    public void fixOrderUp(long idStatus, int oldOrdem, int newOrdem) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(updateUp);
        try{
            //seta informações do status
            stmtAtualiza.setInt(1, newOrdem);
            stmtAtualiza.setInt(2, oldOrdem);
            stmtAtualiza.setLong(3, idStatus);
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }
    
    //Reordena status - down
    public void fixOrderDown(long idStatus, int oldOrdem, int newOrdem) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(updateDown);
        try{
            //seta informações do status
            stmtAtualiza.setInt(1, newOrdem);
            stmtAtualiza.setInt(2, oldOrdem);
            stmtAtualiza.setLong(3, idStatus);
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }
}
