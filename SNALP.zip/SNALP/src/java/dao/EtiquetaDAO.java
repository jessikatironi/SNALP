package dao;

import beans.Etiqueta;
import exception.DAOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EtiquetaDAO {
    private ConnectionFactory connectionFactory;
    
    //queries
    private final String insert = "INSERT INTO etiqueta (titulo, cor, id_workspace) VALUES (?,?,?)";
    private final String update = "UPDATE etiqueta SET titulo = ?, cor = ? WHERE id_etiqueta = ?";
    private final String delete = "DELETE FROM etiqueta WHERE id_etiqueta = ?";
    private final String select = "SELECT * FROM etiqueta WHERE id_workspace = ?";
    private final String search = "SELECT * FROM etiqueta WHERE id_etiqueta = ?";
    private final String list = "SELECT e.id_etiqueta, e.titulo, e.cor FROM etiqueta e INNER JOIN tarefa_etiqueta t ON e.id_etiqueta = t.id_etiqueta AND t.id_tarefa = ?";
    private final String available = "SELECT * FROM etiqueta WHERE id_etiqueta NOT IN (SELECT te.id_etiqueta FROM tarefa_etiqueta te WHERE te.id_tarefa = ?) AND id_workspace = ?";
    private final String selectCores = "SELECT * FROM picker_workspace";
    
    //Atribuição de etiqueta em uma tarefa
    private final String assign = "INSERT INTO tarefa_etiqueta VALUES (?,?)";
    private final String remove = "DELETE FROM tarefa_etiqueta WHERE id_etiqueta = ? AND id_tarefa = ?";

    
    public EtiquetaDAO(ConnectionFactory connectionFactory) {
        this.connectionFactory = connectionFactory;
    }
    
    //Insere uma nova etiqueta na base de dados
    public void inserir(Etiqueta e, long idWorkspace) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtAdiciona = connection.prepareStatement(insert);
        try{
            // seta os valores
            stmtAdiciona.setString(1, e.getTitulo());
            stmtAdiciona.setString(2, e.getCor());
            stmtAdiciona.setLong(3, idWorkspace);
            // executa
            stmtAdiciona.execute();
        } finally{
            stmtAdiciona.close();
            if(rs != null) rs.close();
        }
    }
    
    //Atualiza dados da etiqueta na base de dados
    public void atualizar(Etiqueta e) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(update);
        try{
            //seta informações da workpace
            stmtAtualiza.setString(1, e.getTitulo());
            stmtAtualiza.setString(2, e.getCor());
            stmtAtualiza.setLong(3, e.getIdEtiqueta());
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }

    //Exclui uma workspace da base de dados
    public void remover(long idEtiqueta) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtExcluir;
        stmtExcluir = connection.prepareStatement(delete);
        try {
            //seta id da etiqueta
            stmtExcluir.setLong(1, idEtiqueta);
            //executa query
            stmtExcluir.executeUpdate();
        } finally{
            stmtExcluir.close();
        }
    }
    
    
    //Busca e retorna lista de etiquetas de uma workspace passada como parametro
    public List<Etiqueta> listar(long idWorkspace) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtListar = connection.prepareStatement(select);
        List<Etiqueta> lista = new ArrayList<>();
        try {
            //seta parametro de busca
            stmtListar.setLong(1, idWorkspace);
            //executa query
            rs = stmtListar.executeQuery();
            //enquanto houver resultados da query
            while(rs.next()){
                //resgata cada atributo da etiqueta
                long idEtiqueta = rs.getLong("id_etiqueta");
                String titulo = rs.getString("titulo");
                String cor = rs.getString("cor");
                //insere na lista uma instancia da etiqueta com atributos retornados do banco de dados
                lista.add(new Etiqueta(idEtiqueta,titulo,cor));
            }
            //retorna a lista de etiquetas para a facade
            return lista;
        } finally{
            stmtListar.close();
        }
    }
    
    //Busca um status com base no parametro de id
    public Etiqueta buscar(long idEtiqueta) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtBuscar = connection.prepareStatement(search);
        try{
            //seta parametro de busca
            stmtBuscar.setLong(1, idEtiqueta);
            //executa query
            rs = stmtBuscar.executeQuery();
            //se encontrou etiqueta, retorna instancia da etiqueta com os atributos da query para a facade
            if(rs.next()) return new Etiqueta(rs.getLong("id_etiqueta"),rs.getString("titulo"),rs.getString("cor"));
            //se nao encontrou etiqeuta, retorna exceção para a facade
            else throw new SQLException();
        } finally {
            stmtBuscar.close();
        }
    }
    
    //Busca todas as etiquetas de uma tarefa
    public List<Etiqueta> etiquetasTarefa(long idTarefa) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtListar = connection.prepareStatement(list);
        List<Etiqueta> lista = new ArrayList<>();
        try {
            //seta parametro de busca
            stmtListar.setLong(1, idTarefa);
            //executa query
            rs = stmtListar.executeQuery();
            //enquanto houver resultados da query
            while(rs.next()){
                long idEtiqueta = rs.getLong("e.id_etiqueta");
                String titulo = rs.getString("e.titulo");
                String cor = rs.getString("e.cor");
                lista.add(new Etiqueta(idEtiqueta,titulo,cor));
            }
            return lista;
            
        } finally {
            stmtListar.close();
        }
    }
    
    //Busca todas as etiquetas que podem ser inseridas em uma tarefa / exclui etiquetas já inseridas para evitar repetição
    public List<Etiqueta> etiquetasDisponiveis(long idTarefa, long idWorkspace) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtListar = connection.prepareStatement(available);
        List<Etiqueta> lista = new ArrayList<>();
        try {
            //seta parametro de busca
            stmtListar.setLong(1, idTarefa);
            stmtListar.setLong(2, idWorkspace);
            //executa query
            rs = stmtListar.executeQuery();
            //enquanto houver resultados da query
            while(rs.next()){
                long idEtiqueta = rs.getLong("id_etiqueta");
                String titulo = rs.getString("titulo");
                String cor = rs.getString("cor");
                lista.add(new Etiqueta(idEtiqueta,titulo,cor));
            }
            return lista;
            
        } finally {
            stmtListar.close();
        }
    }
    
    //Atribui uma etiqueta a uma tarefa
    public void atribuirEtiqueta (long idTarefa, long idEtiqueta) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtAdiciona = connection.prepareStatement(assign);
        try{
            // seta os valores
            stmtAdiciona.setLong(1, idTarefa);
            stmtAdiciona.setLong(2, idEtiqueta);
            // executa
            stmtAdiciona.execute();
        } finally{
            stmtAdiciona.close();
            if(rs != null) rs.close();
        }
    }
    
    //Atribui uma etiqueta a uma tarefa
    public void removerEtiqueta (long idTarefa, long idEtiqueta) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtExcluir  = null;
        stmtExcluir = connection.prepareStatement(remove);
        try{
            // seta os valores
            stmtExcluir.setLong(1, idEtiqueta);
            stmtExcluir.setLong(2, idTarefa);
            //executa query
            stmtExcluir.executeUpdate();
        } finally{
            stmtExcluir.close();
        }
    }
    
    //Retorna uma lista de todas as cores do color picker para etiqueta
    public List<String> listarCores() throws SQLException, DAOException {   
        try {
            Connection con = connectionFactory.getConnection();
            
            PreparedStatement stmt = con.prepareStatement(selectCores);
            ResultSet rs = stmt.executeQuery();
            
            List<String> cores = new ArrayList<>();
            
            while(rs.next()) {
                String cor = rs.getString("cor");
                
                cores.add(cor);
            }
            
            stmt.close();
            
            return cores;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...",e);
        }
    }
}
