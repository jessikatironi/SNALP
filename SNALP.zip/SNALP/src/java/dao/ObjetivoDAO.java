package dao;

import beans.Objetivo;
import beans.Usuario;
import exception.DAOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ObjetivoDAO {
    
    private final ConnectionFactory connectionFactory;
        
    private final String search = "SELECT * FROM objetivo WHERE id_usuario = ? AND ativo = 1";                          // buscar objetivo ativo
    private final String insert = "INSERT INTO objetivo (titulo, descricao, data_criacao, data_fim, id_usuario, ativo) "
                                + "VALUES (?, ?, CURRENT_DATE, ?, ?, 1)";                                               // criar objetivo
    private final String update = "UPDATE objetivo SET titulo = ?, descricao = ?, data_fim = ? WHERE id_objetivo = ?";  // atualizar objetivo
    private final String delete = "UPDATE objetivo SET ativo = 0 WHERE id_objetivo = ?";                                // remover objetivo
    
    public ObjetivoDAO() {
        this.connectionFactory = new ConnectionFactory();
    }
    
    //Retorna os dados do objetivo ativo do usuário
    public Objetivo buscarObjetivo(Usuario usuario) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();

            PreparedStatement stmt = con.prepareStatement(search);
            stmt.setLong(1, usuario.getIdUsuario());
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Objetivo o = new Objetivo();
                
                o.setIdObjetivo(rs.getLong("id_objetivo"));
                o.setTituloObjetivo(rs.getString("titulo"));
                o.setDescricaoObjetivo(rs.getString("descricao"));
                o.setDataCriacaoObjetivo(rs.getDate("data_criacao").toLocalDate());
                
               // verifica se a data final do objetivo não é nula
               if(rs.getDate("data_fim") != null) { // caso não seja nula, seta a data final normalmente
                   o.setDataFimObjetivo(rs.getDate("data_fim").toLocalDate());
               } else { // caso seja nula
                   
               }
                
                stmt.close();
                return o;
            } else {
                stmt.close();
                throw new SQLException();
            }
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
    //Insere um novo objetivo no banco de dado
    public void criarObjetivo(Objetivo objetivo, Usuario usuario) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            PreparedStatement stmt = con.prepareStatement(insert);
            stmt.setString(1, objetivo.getTituloObjetivo());
            stmt.setString(2, objetivo.getDescricaoObjetivo());
            
            // verifica se a data final do objetivo não é nula
            if(objetivo.getDataFimObjetivo() != null) { // caso não seja nula, seta data final normalmente
                stmt.setString(3, objetivo.getDataFimObjetivo().toString());
            } else {    // caso seja nula, seta data final como nula
                stmt.setString(3, null);
            }
            
            stmt.setLong(4, usuario.getIdUsuario());

            int x = stmt.executeUpdate();

            stmt.close();
        
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }

    //Atualiza os dados de um objetivo no banco de dados
    public void atualizarObjetivo(Objetivo objetivo) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            PreparedStatement stmt = con.prepareStatement(update);
            stmt.setString(1, objetivo.getTituloObjetivo());
            stmt.setString(2, objetivo.getDescricaoObjetivo());
            
            // verifica se a data final do objetivo não é nula
            if(objetivo.getDataFimObjetivo() != null) { // caso não seja nula, seta data final normalmente
                stmt.setString(3, objetivo.getDataFimObjetivo().toString());
            } else {    // caso seja nula, seta data final como nula
                stmt.setString(3, null);
            }
            
            stmt.setLong(4, objetivo.getIdObjetivo());
            int x = stmt.executeUpdate();

            stmt.close();
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }

    //Remove um objetivo no banco de dados: atualiza o atributo "ativo" para zero.
    public void removerObjetivo(long idObjetivo)throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            PreparedStatement stmt = con.prepareStatement(delete);
            stmt.setLong(1, idObjetivo);
            int x = stmt.executeUpdate();
        
            stmt.close();
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
    //Retorna true/false para verificar se o usuário já tem um objetivo ativo: false - sem objetivo ativo / true - com objetivo ativo
    public boolean verificarObjetivo(Usuario usuario) throws SQLException, DAOException {   
        try {
            Connection con = connectionFactory.getConnection();
            
            PreparedStatement stmt = con.prepareStatement(search);
            stmt.setLong(1, usuario.getIdUsuario());
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                stmt.close();
                return true;
            } else {
                stmt.close();
                return false;
            }
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...",e);
        }
    }
    
}
