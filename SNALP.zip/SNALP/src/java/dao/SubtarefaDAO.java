package dao;

import beans.Subtarefa;
import exception.DAOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SubtarefaDAO {
    private final ConnectionFactory connectionFactory;
    
    //queries
    private final String insert = "INSERT INTO subtarefa SET descricao = ?, concluido = false, id_tarefa = ?";
    private final String update = "UPDATE subtarefa SET descricao = ? WHERE id_subtarefa = ?";
    private final String delete = "DELETE FROM subtarefa WHERE id_subtarefa = ?";
    private final String select = "SELECT * FROM subtarefa WHERE id_tarefa = ?";
    private final String search = "SELECT * FROM subtarefa WHERE id_subtarefa = ?";
    
    private final String complete = "UPDATE subtarefa SET concluido = ? WHERE id_subtarefa = ?";

    public SubtarefaDAO(ConnectionFactory connectionFactory) {
        this.connectionFactory = connectionFactory;
    }

    //Insere uma subtarefa na base de dados
    public void inserir(Subtarefa s, long idTarefa) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtAdiciona = connection.prepareStatement(insert, Statement.RETURN_GENERATED_KEYS);
        try{
            // seta os valores
            stmtAdiciona.setString(1, s.getDescricao());
            stmtAdiciona.setLong(2, idTarefa);
            // executa query
            stmtAdiciona.execute();
            //Seta id da subtarefa
            rs = stmtAdiciona.getGeneratedKeys();
            rs.next();
            long idSubtarefa = rs.getLong(1);
            s.setIdSubtarefa(idSubtarefa);
        } finally{
            stmtAdiciona.close();
            if(rs != null) rs.close();
        }
    }
    
    //Atualiza dados da subtarefa na base de dados
    public void atualizar(Subtarefa s) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(update);
        try{
            //seta informações da subtarefa
            stmtAtualiza.setString(1, s.getDescricao());
            stmtAtualiza.setLong(2, s.getIdSubtarefa());
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }

    //Exclui uma subtarefa da base de dados
    public void remover(long idSubtarefa) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtExcluir;
        stmtExcluir = connection.prepareStatement(delete);
        try {
            //seta id da subtarefa
            stmtExcluir.setLong(1, idSubtarefa);
            //executa query
            stmtExcluir.executeUpdate();
        } finally{
            stmtExcluir.close();
        }
    }
    
    //Busca uma subtarefa
    public Subtarefa buscarSubtarefa(long idSubtarefa) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtBuscar = connection.prepareStatement(search);
        try{
            //seta parametro de busca
            stmtBuscar.setLong(1, idSubtarefa);
            //executa query
            rs = stmtBuscar.executeQuery();
            //se encontrou subtarefa, retorna instancia da subtarefa com os atributos da query para a facade
            if(rs.next()){
                return new Subtarefa(rs.getLong("id_subtarefa"),rs.getString("descricao"),rs.getBoolean("concluido"));
            }
            //se nao encontrou subtarefa, retorna exceção para a facade
            else throw new SQLException();
        } finally {
            stmtBuscar.close();
        }
    }
    
    //Busca e retorna lista de subtarefas de uma tarefa passada como parametro
    public List<Subtarefa> listar(long idWorkspace) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        ResultSet rs = null;
        PreparedStatement stmtListar = connection.prepareStatement(select);
        List<Subtarefa> lista = new ArrayList<>();
        try {
            //seta parametro de busca
            stmtListar.setLong(1, idWorkspace);
            //executa query
            rs = stmtListar.executeQuery();
            //enquanto houver resultados da query
            while(rs.next()){
                //resgata cada atributo do status
                long idSubtarefa = rs.getLong("id_subtarefa");
                String desc = rs.getString("descricao");
                boolean concluido = rs.getBoolean("concluido");
                //insere na lista uma instancia da subtarefa com atributos retornados do banco de dados
                lista.add(new Subtarefa(idSubtarefa,desc,concluido));
            }
            //retorna a lista de subtarefas para a facade
            return lista;
        } finally{
            stmtListar.close();
        }
    }
    
    //muda atributo concluido para true ou false
    public void completarSubtarefa(long idSubtarefa, boolean estado) throws DAOException, SQLException {
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(complete);
        try{
            //seta informações da subtarefa
            stmtAtualiza.setBoolean(1, estado);
            stmtAtualiza.setLong(2, idSubtarefa);
            //executa query
            stmtAtualiza.executeUpdate();
        } finally{
            stmtAtualiza.close();
        }
    }
}
