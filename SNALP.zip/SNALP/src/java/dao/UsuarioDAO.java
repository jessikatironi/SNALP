/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import beans.Criptografia;
import beans.Usuario;
import exception.DAOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

/**
 *
 * @author eduar
 */
public class UsuarioDAO {
    
    private final ConnectionFactory connectionFactory;
    
    public UsuarioDAO() {
        this.connectionFactory = new ConnectionFactory();
    }
    
    //querys e updates
    private final String insert = "INSERT INTO USUARIO (NOME, SENHA, EMAIL, DATA_CADASTRO) VALUES (?, ?, ?, ?)";
    private final String update = "UPDATE USUARIO SET NOME=?, EMAIL=? WHERE ID_USUARIO=?";
    private final String updateSenha = "UPDATE USUARIO SET SENHA=? WHERE ID_USUARIO=?";
    private final String select = "SELECT * FROM USUARIO WHERE ID_USUARIO=?";
    private final String selectSenha = "SELECT SENHA FROM USUARIO WHERE ID_USUARIO=?";
    private final String selectEmail = "SELECT COUNT(EMAIL) AS EMAIL FROM USUARIO WHERE EMAIL=?";
    private final String selectEmailId = "SELECT COUNT(EMAIL) AS EMAIL FROM USUARIO WHERE EMAIL=? AND ID_USUARIO!=?";
    private final String delete = "DELETE FROM USUARIO WHERE ID_USUARIO=?";
    private final String selectLogin = "SELECT ID_USUARIO, NOME FROM USUARIO WHERE EMAIL=? AND SENHA=?";
    
    //Insere o cadastro do cliente no banco de dados
    public void criarUsuario( Usuario usuario ) throws DAOException , SQLException{
        
        Connection con = connectionFactory.getConnection();//configura a conexão

       
 
        String senha=Criptografia.criptografar(usuario.getSenhaUsuario());//criptografa senha
        
        //confere se o email nao eh cadastrado
        PreparedStatement stmtEmail = con.prepareStatement(selectEmail);//prepara a sql
        PreparedStatement stmtInsere = con.prepareStatement(insert);//prepara a sql
        ResultSet rs = null;
        try{
            stmtEmail.setString(1, usuario.getEmailUsuario());     
            rs = stmtEmail.executeQuery(); 
            while (rs.next()){     
                if(rs.getInt("email")>0) {
                    throw new SQLException("Este e-mail já esta cadastrado, tente novamente."); 
                }//se ja houver algum usuario com o email, retorna falso
            }
                stmtInsere.setString(1, usuario.getNomeUsuario());//aponta o nome 
                    stmtInsere.setString(2, senha);//aponta a senha
                    stmtInsere.setString(3, usuario.getEmailUsuario());//aponta o e-mail
                    stmtInsere.setDate(4, Date.valueOf(usuario.getDataCadastroUsuario()));//aponta a data de cadastro
                    stmtInsere.executeUpdate();//Executa o insert
        }
        finally{
            stmtInsere.close(); //finaliza conexão com base de dados
            stmtEmail.close(); 
            if(rs != null) rs.close();
        }
    }
    
    //busca usuario pelo ID na base de dados
    public Usuario buscarUsuario(long idUsuario) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtSelect = connection.prepareStatement(select);
        ResultSet rs = null;
        try{
            stmtSelect.setLong(1, idUsuario);     
            rs = stmtSelect.executeQuery(); 
            if (rs.next()){     
                Usuario usuario = new Usuario(idUsuario,rs.getString("nome"),rs.getString("email"));
                return usuario;
            }
            else{   //levanta exceção se não encontrar usuario
                throw new SQLException();
            }
        }
        finally{
            stmtSelect.close();  //finaliza conexão com base de dados
            if(rs != null) rs.close();
        }
    }
    
  
    //atualiza usuario na base de dados
    public void atualizarUsuario(Usuario usuario) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(update);
        PreparedStatement stmtEmail = connection.prepareStatement(selectEmailId);
        try{
            stmtEmail.setString(1, usuario.getEmailUsuario());
            stmtEmail.setLong(2, usuario.getIdUsuario());
            ResultSet rs = stmtEmail.executeQuery(); //Procurar se o email alterado já esta no bd (fora usuario atual)
            if (rs.next()){     
                if(rs.getInt("email")>0) throw new SQLException("Este e-mail já esta cadastrado, tente novamente."); //se o email ainda não tiver cadastrado, permite alterar
                else{
                    //setta o nome e e-mail, com id para referencia do usuario
                    stmtAtualiza.setString(1, usuario.getNomeUsuario());
                    stmtAtualiza.setString(2, usuario.getEmailUsuario());
                    stmtAtualiza.setLong(3, usuario.getIdUsuario());

                    stmtAtualiza.executeUpdate();//executa o update
                }
            }
        } finally{
            stmtAtualiza.close();//fecha a conexão
        }
    }
    
    //atualiza senha do usuario na base de dados
    public void atualizarSenha(Usuario usuario, String senha) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtSelect = connection.prepareStatement(selectSenha);
        PreparedStatement stmtUpdate = connection.prepareStatement(updateSenha);
        
        //criptografa senhas para comparação
        String senhaAtual = Criptografia.criptografar(senha);
        String senhaNova = Criptografia.criptografar(usuario.getSenhaUsuario());
       
        try{
            ResultSet rs = null;
            //seleciona usuario pelo id
            stmtSelect.setLong(1, usuario.getIdUsuario());     
            rs = stmtSelect.executeQuery(); 
            if (rs.next()){     
                //se a senha passada não conferir, retorna falso
                if(!rs.getString("senha").equals(senhaAtual)) throw new DAOException();
                else{
                    //Se a senha atual conferir, atualiza no banco de dados e retorna verdadeiro
                    stmtUpdate.setString(1,senhaNova);
                    stmtUpdate.setLong(2, usuario.getIdUsuario());

                    stmtUpdate.executeUpdate();//executa o update
                }
            }
            else{//Exceção se não encontrar usuario
                throw new SQLException();
            }
        } finally{
            //fecha as conexões
            stmtSelect.close();
            stmtUpdate.close();
        }
    }
    
    //deleta usuario na base de dados
    public void deletarUsuario( long idUsuario ) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtAtualiza = connection.prepareStatement(delete);
        try{
            //Referencia o usuario pelo id
            stmtAtualiza.setLong(1, idUsuario);
            
            stmtAtualiza.executeUpdate();//executa o delete
        } finally{
            stmtAtualiza.close();//fecha a conexão
        }
    }
    
    public Usuario realizaLogin( String email, String senha) throws DAOException, SQLException{
        Connection connection=connectionFactory.getConnection();
        PreparedStatement stmtSelect = connection.prepareStatement(selectLogin);
        ResultSet rs = null;
        //criptografa senha
        if (senha==null) throw new SQLException();//Nao criptografa se for vazia
        String senhaC = Criptografia.criptografar(senha);
        
        try{
            //configura select com o email e senha
            stmtSelect.setString(1, email);     
            stmtSelect.setString(2, senhaC);     
            rs = stmtSelect.executeQuery(); 
            if (rs.next()){ //se encontrar um usuario
                Usuario user = new Usuario (rs.getString("NOME"),rs.getLong("ID_USUARIO"));//cria um bean do login
                //Bean com id em segundo para selecionar o construtor correto
                return user;//retorar o bean
            }
            else{//levanta exceção se não encontrar usuario
                throw new SQLException();
            }
        }
        finally{
            stmtSelect.close();//finaliza conexão com base de dados
            if(rs != null) rs.close();
        }
    }
}
