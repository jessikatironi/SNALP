package dao;

import beans.Pomodoro;
import beans.Usuario;
import exception.DAOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PomodoroDAO {

    private final ConnectionFactory connectionFactory;

    public PomodoroDAO() {
        this.connectionFactory = new ConnectionFactory();
    }

    private final String insert = "INSERT INTO POMODORO (TITULO, TEMPO, PAUSA, SERIE, ID_USUARIO) VALUES (?,?,?,?,?)";
    private final String update = "UPDATE POMODORO SET TITULO=?, TEMPO=?, PAUSA=?, SERIE=? WHERE ID_POMODORO=?";
    private final String delete = "DELETE FROM POMODORO WHERE ID_POMODORO=?";
    private final String selectLista = "SELECT * FROM POMODORO WHERE ID_USUARIO =?";
    private final String search = "SELECT * FROM POMODORO WHERE ID_POMODORO =?";
    private final String insertLog = "INSERT INTO pomodoro_historico (TITULO, TEMPO, PAUSA, SERIE, DATA, ID_USUARIO) VALUES (?,?,?,?,?,?)";
    private final String selectListaLog = "SELECT * FROM pomodoro_historico WHERE ID_USUARIO =? ORDER BY id_historico DESC";
    private final String selectLastLog = "SELECT * FROM pomodoro_historico WHERE ID_USUARIO =? ORDER BY id_historico DESC LIMIT 1";
    
    //queries para as estatísticas gerais: quantidade de relógios Pomodoro executados por período
    private final String selectPomodoroCountDia =    "SELECT count(id_historico) AS 'qtde' FROM pomodoro_historico WHERE data = CURDATE() AND id_usuario = ?";
    private final String selectPomodoroCountSemana = "SELECT count(id_historico) AS 'qtde' FROM pomodoro_historico WHERE data BETWEEN (CURDATE() - INTERVAL 1 WEEK) AND CURDATE() AND id_usuario = ?";
    private final String selectPomodoroCountMes =    "SELECT count(id_historico) AS 'qtde' FROM pomodoro_historico WHERE data BETWEEN (CURDATE() - INTERVAL 1 MONTH) AND CURDATE() AND id_usuario = ?";

    //Função para inserir novo pomodoro no banco de dados
    public void inserirPomodoro(Pomodoro pomodoro, Usuario u) throws DAOException, SQLException {

        Connection con = connectionFactory.getConnection();//configura a conexão
        PreparedStatement stmtInsert = con.prepareStatement(insert);//prepara a sql

        try {
            stmtInsert.setString(1, pomodoro.getTitulo());
            stmtInsert.setInt(2, pomodoro.getTempo());
            stmtInsert.setInt(3, pomodoro.getPausa());
            stmtInsert.setInt(4, pomodoro.getSerie());
            stmtInsert.setLong(5, u.getIdUsuario());
            stmtInsert.executeUpdate();//executa insert
        } finally {
            stmtInsert.close();//fecha a conexão
        }

    }

    public List<Pomodoro> listarPomodoro(Usuario u) throws DAOException, SQLException {
        Connection connection = connectionFactory.getConnection();
        PreparedStatement stmtSelect = connection.prepareStatement(selectLista);
        ResultSet rs = null;
        List<Pomodoro> lista = new ArrayList<>();
        try {
            if (u == null) {
                throw new SQLException("Erro ao procurar o usuário e seus relógios, tente novamente.");
            }
            stmtSelect.setLong(1, u.getIdUsuario());  //prepara select com o id   
            rs = stmtSelect.executeQuery(); //executa query
            while (rs.next()) {
                long id = rs.getLong("id_pomodoro");
                String nome = rs.getString("titulo");
                int tempo = rs.getInt("tempo");
                int pausa = rs.getInt("pausa");
                int serie = rs.getInt("serie");
                Pomodoro pom = new Pomodoro(id, nome, tempo, pausa, serie);//cria novo relogio com os dados
                lista.add(pom);//adiciona a lista
            }
            return lista;
        } finally {
            stmtSelect.close();  //finaliza conexão com base de dados
            if (rs != null) {
                rs.close();
            }
        }
    }

    public Pomodoro buscarPomodoro(Long id) throws DAOException, SQLException {
        Connection connection = connectionFactory.getConnection();
        PreparedStatement stmtSelect = connection.prepareStatement(search);
        ResultSet rs = null;
        try {
            stmtSelect.setLong(1, id);  //prepara select com o id   
            rs = stmtSelect.executeQuery(); //executa query
            if (rs.next()) {
                long idP = rs.getLong("id_pomodoro");
                String nome = rs.getString("titulo");
                int tempo = rs.getInt("tempo");
                int pausa = rs.getInt("pausa");
                int serie = rs.getInt("serie");
                Pomodoro pom = new Pomodoro(id, nome, tempo, pausa, serie);//cria novo relogio com os dados
                return pom;
            } else {   //levanta exceção se não encontrar usuario
                throw new SQLException("Erro ao procurar o relógio, tente novamente.");
            }
        } finally {
            stmtSelect.close();  //finaliza conexão com base de dados
            if (rs != null) {
                rs.close();
            }
        }
    }

    public void atualizarPomodoro(Pomodoro pomodoro) throws DAOException, SQLException {

        Connection con = connectionFactory.getConnection();//configura a conexão
        PreparedStatement stmtUpdate = con.prepareStatement(update);//prepara a sql

        try {
            //configura valores
            stmtUpdate.setString(1, pomodoro.getTitulo());
            stmtUpdate.setInt(2, pomodoro.getTempo());
            stmtUpdate.setInt(3, pomodoro.getPausa());
            stmtUpdate.setInt(4, pomodoro.getSerie());
            stmtUpdate.setLong(5, pomodoro.getIdPomodoro());
            stmtUpdate.executeUpdate();//executa o update
        } finally {
            stmtUpdate.close();//fecha a conexão
        }

    }

    public void deletaPomodoro(Long id) throws DAOException, SQLException {

        Connection con = connectionFactory.getConnection();//configura a conexão

        PreparedStatement stmtDelete = con.prepareStatement(delete);//prepara a sql

        try {
            //configura valores
            stmtDelete.setLong(1, id);
            stmtDelete.executeUpdate();//executa o delete
        } finally {
            stmtDelete.close();//fecha a conexão
        }

    }

    public void registarLogPomodoro(Pomodoro pomodoro, Usuario usuario) throws DAOException, SQLException {

        Connection con = connectionFactory.getConnection();//configura a conexão
        PreparedStatement stmtInsert = con.prepareStatement(insertLog);//prepara a sql

        try {
            stmtInsert.setString(1, pomodoro.getTitulo());
            stmtInsert.setInt(2, pomodoro.getTempo());
            stmtInsert.setInt(3, pomodoro.getPausa());
            stmtInsert.setInt(4, pomodoro.getSerie());
            stmtInsert.setDate(5, Date.valueOf(pomodoro.getDataLog()));
            stmtInsert.setLong(6, usuario.getIdUsuario());
            stmtInsert.executeUpdate();//executa insert
        } finally {
            stmtInsert.close();//fecha a conexão
        }

    }

    public List<Pomodoro> listarLogPomodoro(Usuario u) throws DAOException, SQLException {
        Connection connection = connectionFactory.getConnection();
        PreparedStatement stmtSelect = connection.prepareStatement(selectListaLog);
        ResultSet rs = null;
        List<Pomodoro> lista = new ArrayList<>();
        try {
            if (u == null) {
                throw new SQLException("Erro ao procurar o usuário e seus relógios, tente novamente.");
            }
            stmtSelect.setLong(1, u.getIdUsuario());  //prepara select com o id   
            rs = stmtSelect.executeQuery(); //executa query
            while (rs.next()) {
                String nome = rs.getString("titulo");
                int tempo = rs.getInt("tempo");
                int pausa = rs.getInt("pausa");
                int serie = rs.getInt("serie");
                LocalDate data = rs.getDate("data").toLocalDate();
                Pomodoro pom = new Pomodoro(nome, tempo, pausa, serie, data);//cria novo relogio com os dados
                lista.add(pom);//adiciona a lista
            }
            return lista;
        } finally {
            stmtSelect.close();  //finaliza conexão com base de dados
            if (rs != null) {
                rs.close();
            }
        }
    }

    public Pomodoro buscarUltimoLogPomodoro(Usuario u) throws DAOException, SQLException {
        Connection connection = connectionFactory.getConnection();
        PreparedStatement stmtSelect = connection.prepareStatement(selectLastLog);
        ResultSet rs = null;
        try {
            if (u == null) {
                throw new SQLException("Erro ao procurar o usuário e seus relógios, tente novamente.");
            }
            stmtSelect.setLong(1, u.getIdUsuario());  //prepara select com o id   
            rs = stmtSelect.executeQuery(); //executa query
            if (rs.next()) {
                String nome = rs.getString("titulo");
                int tempo = rs.getInt("tempo");
                int pausa = rs.getInt("pausa");
                int serie = rs.getInt("serie");
                LocalDate data = rs.getDate("data").toLocalDate();;
                Pomodoro pom = new Pomodoro(nome, tempo, pausa, serie, data);//cria novo relogio com os dados
                stmtSelect.close();
                return pom;
            } else {
                stmtSelect.close();
                return null;
            }
        } finally {
            stmtSelect.close();  //finaliza conexão com base de dados
            if (rs != null) {
                rs.close();
            }
        }
    }
    
    ///Retorna uma lista contendo as estatísticas de quantidade de relógios pomodoro executados por período
    public List<Integer> listarEstatisticasGerais(Usuario usuario) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
            
            List<Integer> listaEstatisticasGerais = new ArrayList<>();
            
            PreparedStatement stmt = con.prepareStatement(selectPomodoroCountDia);
            stmt.setLong(1, usuario.getIdUsuario());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) listaEstatisticasGerais.add(rs.getInt("qtde"));

            stmt = con.prepareStatement(selectPomodoroCountSemana);
            stmt.setLong(1, usuario.getIdUsuario());
            rs = stmt.executeQuery();
            if (rs.next()) listaEstatisticasGerais.add(rs.getInt("qtde"));
            
            stmt = con.prepareStatement(selectPomodoroCountMes);
            stmt.setLong(1, usuario.getIdUsuario());
            rs = stmt.executeQuery();
            if (rs.next()) listaEstatisticasGerais.add(rs.getInt("qtde"));

            stmt.close();

            return listaEstatisticasGerais;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
}
