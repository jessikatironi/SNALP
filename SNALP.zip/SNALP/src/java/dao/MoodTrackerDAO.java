package dao;

import beans.Atividade;
import beans.Humor;
import beans.MoodTracker;
import beans.Usuario;
import exception.AtividadeException;
import exception.CategoriaException;
import exception.DAOException;
import exception.HumorException;
import exception.MoodTrackerException;
import facade.AtividadeFacade;
import facade.HumorFacade;
import facade.MoodTrackerFacade;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

public class MoodTrackerDAO {
    
    private final ConnectionFactory connectionFactory;
    
    private final String select = "SELECT * FROM moodtracker WHERE id_usuario = ? ORDER BY data DESC";                                             // listar registros Mood Tracker           
    private final String selectAtividades = "SELECT * FROM moodtracker_atividade WHERE id_moodtracker = ?";                                         // listar atividades de um registro Mood Tracker
    
    private final String search = "SELECT * FROM moodtracker WHERE id_moodtracker = ?";                                                             // buscar registro Mood Tracker
    private final String searchId = "SELECT * FROM moodtracker ORDER BY id_moodtracker DESC LIMIT 1";
    
    private final String insert = "INSERT INTO moodtracker (data, descricao, cumpriu_objetivo, id_usuario, id_humor) VALUES (?, ?, ?, ?, ?);";      // criar registro Mood Tracker
    private final String insertAtividades = "INSERT INTO moodtracker_atividade (id_moodtracker, id_atividade) VALUES (?, ?);";                      // inserir atividades de um registro Mood Tracker
    
    private final String update = "UPDATE moodtracker SET data = ?, descricao = ?, cumpriu_objetivo = ?, id_humor = ? WHERE id_moodtracker = ?";    // atualizar registro Mood Tracker
    
    private final String delete = "DELETE FROM moodtracker WHERE id_moodtracker = ?";                                                               // remover registro Mood Tracker
    private final String deleteAtividades = "DELETE FROM moodtracker_atividade WHERE id_moodtracker = ? AND id_atividade = ?";                      // remover atividades de um registro Mood Tracker
    
    private final String selectComData = "SELECT * FROM moodtracker WHERE id_usuario = ? AND data = ?";
    
    // queries para gerar os gráficos e estatísticas do Mood Tracker
    private final String selectHumoresQtde = "SELECT M.id_humor, count(*) FROM moodtracker M, humor H " + 
                                             "WHERE M.id_humor = H.id_humor " +
                                             "AND H.ativo = 1 AND M.id_usuario = ? " +
                                             "GROUP BY M.id_humor ORDER BY M.id_humor";
    
    private final String selectAtividadesQtde = "SELECT MA.id_atividade, count(*) " +
                                                "FROM moodtracker M, moodtracker_atividade MA, atividade A " +
                                                "WHERE M.id_moodtracker = MA.id_moodtracker " +
                                                "AND MA.id_atividade = A.id_atividade " +
                                                "AND A.ativo = 1 AND M.id_usuario = ? " +
                                                "GROUP BY MA.id_atividade ORDER BY count(*) DESC LIMIT 10";
    
    private final String selectAtividadesPorHumor = "SELECT A.descricao, count(*) " +
                                                    "FROM moodtracker M, moodtracker_atividade MA, atividade A " +
                                                    "WHERE M.id_moodtracker = MA.id_moodtracker " +
                                                    "AND MA.id_atividade = A.id_atividade " +
                                                    "AND A.ativo = 1 AND M.id_usuario = ? AND M.id_humor = ? " +
                                                    "GROUP BY MA.id_atividade ORDER BY count(*) DESC LIMIT 3";
    
    private final String selectFlowHumores = "SELECT * FROM moodtracker M, humor H " +
                                             "WHERE M.id_usuario = ? " +
                                             "AND M.id_humor = H.id_humor " +
                                             "AND H.ativo = 1 " +
                                             "ORDER BY data DESC LIMIT 10";
    
    private final String selectLast = "SELECT * FROM moodtracker WHERE id_usuario = ? ORDER BY data DESC";
    
    // queries para as estatísticas gerais: humor mais registrado pelo usuário por período
    private final String selectHumorDia =    "SELECT id_humor, count(*) AS 'qtde' FROM moodtracker WHERE id_usuario = ? AND data = CURDATE() GROUP BY (id_humor) ORDER BY count(*) DESC LIMIT 1";
    private final String selectHumorSemana = "SELECT id_humor, count(*) AS 'qtde' FROM moodtracker WHERE id_usuario = ? AND data BETWEEN (CURDATE() - INTERVAL 1 WEEK) AND CURDATE() GROUP BY (id_humor) ORDER BY count(*) DESC LIMIT 1";
    private final String selectHumorMes =    "SELECT id_humor, count(*) AS 'qtde' FROM moodtracker WHERE id_usuario = ? AND data BETWEEN (CURDATE() - INTERVAL 1 MONTH) AND CURDATE() GROUP BY (id_humor) ORDER BY count(*) DESC LIMIT 1";
    
    
    public MoodTrackerDAO() {
        this.connectionFactory = new ConnectionFactory();
    }
    
    //Retorna uma lista de todos os registros Mood Tracker de um usuário (é complementada pelo método listarAtividadesRegistro)
    public List<MoodTracker> listarRegistros(Usuario usuario) throws SQLException, DAOException, HumorException, MoodTrackerException, AtividadeException, CategoriaException {   
        try {
            Connection con = connectionFactory.getConnection();
            
            PreparedStatement stmt = con.prepareStatement(select);
            stmt.setLong(1, usuario.getIdUsuario());
            ResultSet rs = stmt.executeQuery();
            
            List<MoodTracker> registros = new ArrayList<>();
            
            while(rs.next()) {
                MoodTracker registro = new MoodTracker();
                
                registro.setIdMoodTracker(rs.getLong("id_moodtracker"));
                registro.setDataMoodTracker(rs.getDate("data").toLocalDate());
                registro.setDescricaoMoodTracker(rs.getString("descricao"));
                registro.setCumpriuObjetivoMoodTracker(rs.getBoolean("cumpriu_objetivo"));
                
                Humor humor = HumorFacade.buscarHumor(rs.getLong("id_humor"));
                registro.setHumorMoodTracker(humor);
                
                //List<Atividade> listaAtividades = MoodTrackerFacade.listarAtividadesRegistro(registro);
                //registro.setListaAtividadesMoodTracker(listaAtividades);
                
                registros.add(registro);
            }
            
            stmt.close();
            
            return registros;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...1",e);
        }
    }
    
    //Retorna uma lista de todas as atividades de um registo MoodTracker do usuário
    public List<Atividade> listarAtividadesRegistro(MoodTracker moodtracker) throws SQLException, DAOException, AtividadeException, CategoriaException {
        try {
            Connection con = connectionFactory.getConnection();

            PreparedStatement stmt = con.prepareStatement(selectAtividades);
            stmt.setLong(1, moodtracker.getIdMoodTracker());
            ResultSet rs = stmt.executeQuery();

            List<Atividade> atividades = new ArrayList<>();

            while (rs.next()) {
                Atividade atividade = AtividadeFacade.buscarAtividade(rs.getLong("id_atividade"));

                atividades.add(atividade);
            }

            stmt.close();

            return atividades;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...2", e);
        }
    }

    //Retorna os dados de um registro mood tracker do usuário
    public MoodTracker buscarRegistro(long idMoodTracker) throws SQLException, DAOException, HumorException, AtividadeException, CategoriaException, MoodTrackerException {
        try {
            Connection con = connectionFactory.getConnection();

            PreparedStatement stmt = con.prepareStatement(search);
            stmt.setLong(1, idMoodTracker);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                MoodTracker registro = new MoodTracker();

                registro.setIdMoodTracker(rs.getLong("id_moodtracker"));
                registro.setDataMoodTracker(rs.getDate("data").toLocalDate());
                registro.setDescricaoMoodTracker(rs.getString("descricao"));
                registro.setCumpriuObjetivoMoodTracker(rs.getBoolean("cumpriu_objetivo"));
                
                Humor humor = HumorFacade.buscarHumor(rs.getLong("id_humor"));
                registro.setHumorMoodTracker(humor);
                
                List<Atividade> listaAtividades = MoodTrackerFacade.listarAtividadesRegistro(registro);
                registro.setListaAtividadesMoodTracker(listaAtividades);
                
                stmt.close();
                return registro;
            } else {
                stmt.close();
                throw new SQLException();
            }
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...3", e);
        }
    }
    
    //Retorna os dados do último registro mood tracker do usuário
    public MoodTracker buscarUltimoRegistro(Usuario usuario) throws SQLException, DAOException, HumorException, MoodTrackerException, AtividadeException, CategoriaException {
        try {
            Connection con = connectionFactory.getConnection();

            PreparedStatement stmt = con.prepareStatement(selectLast);
            stmt.setLong(1, usuario.getIdUsuario());
            ResultSet rs = stmt.executeQuery();

            MoodTracker registro = new MoodTracker();
            if (rs.next()) {

                registro.setIdMoodTracker(rs.getLong("id_moodtracker"));
                registro.setDataMoodTracker(rs.getDate("data").toLocalDate());
                registro.setDescricaoMoodTracker(rs.getString("descricao"));
                registro.setCumpriuObjetivoMoodTracker(rs.getBoolean("cumpriu_objetivo"));

                Humor humor = HumorFacade.buscarHumor(rs.getLong("id_humor"));
                registro.setHumorMoodTracker(humor);

                List<Atividade> listaAtividades = MoodTrackerFacade.listarAtividadesRegistro(registro);
                registro.setListaAtividadesMoodTracker(listaAtividades);
                stmt.close();
                return registro;
            } else {
                stmt.close();
                return null;
            }

        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...14", e);
        }
    }
    
    //Insere um novo registro mood tracker no banco de dados
    public void criarRegistro(MoodTracker registro, Usuario usuario) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            PreparedStatement stmt = con.prepareStatement(insert);
            stmt.setString(1, registro.getDataMoodTracker().toString());
            stmt.setString(2, registro.getDescricaoMoodTracker());
            stmt.setBoolean(3, registro.getCumpriuObjetivoMoodTracker());
            stmt.setLong(4, usuario.getIdUsuario());
            stmt.setLong(5, registro.getHumorMoodTracker().getIdHumor());

            int x = stmt.executeUpdate();
            
            stmt.close();
        
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...4", e);
        }
    }

    //Atualiza os dados de um registro mood tracker no banco de dados
    public void atualizarRegistro(MoodTracker registro) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            PreparedStatement stmt = con.prepareStatement(update);
            stmt.setString(1, registro.getDataMoodTracker().toString());
            stmt.setString(2, registro.getDescricaoMoodTracker());
            stmt.setBoolean(3, registro.getCumpriuObjetivoMoodTracker());
            stmt.setLong(4, registro.getHumorMoodTracker().getIdHumor());
            stmt.setLong(5, registro.getIdMoodTracker());
            int x = stmt.executeUpdate();

            stmt.close();
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...5", e);
        }
    }
    
    //Busca o id do novo registro mood tracker no banco de dados para possibilitar a inserção das atividades desse registro
    public long buscarIdRegistroCriado() throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();

            PreparedStatement stmt = con.prepareStatement(searchId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Long id = rs.getLong("id_moodtracker");
                
                stmt.close();
                return id;
            } else {
                stmt.close();
                throw new SQLException();
            }
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...6", e);
        }
    }
    
    //Insere as atividades de um novo registro mood tracker no banco de dados
    public void inserirAtividadesRegistro(MoodTracker registro) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            for(Atividade atividade: registro.getListaAtividadesMoodTracker()) {
                
                PreparedStatement stmt = con.prepareStatement(insertAtividades);
                stmt.setLong(1, registro.getIdMoodTracker());
                stmt.setLong(2, atividade.getIdAtividade());

                int x = stmt.executeUpdate();

                stmt.close();
                
            }
        
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...7", e);
        }
    }

    //Remove um registro mood tracker do banco de dados
    public void removerRegistro(long idMoodTracker) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            PreparedStatement stmt = con.prepareStatement(delete);
            stmt.setLong(1, idMoodTracker);
            int x = stmt.executeUpdate();
        
            stmt.close();
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...8", e);
        }
    }
    
    //Remove as atividades de um registro mood tracker do banco de dados
    public void removerAtividadesRegistro(MoodTracker registro) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            for(Atividade atividade: registro.getListaAtividadesMoodTracker()) {
                
                PreparedStatement stmt = con.prepareStatement(deleteAtividades);
                stmt.setLong(1, registro.getIdMoodTracker());
                stmt.setLong(2, atividade.getIdAtividade());

                int x = stmt.executeUpdate();

                stmt.close();
                
            }
        
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...9", e);
        }
    }

    //Retorna um tree map contendo os id dos humores do usuário e suas respectivas qtdes de aparições nos registros Mood Tracker
    public TreeMap<Long, Integer> gerarGraficoContagemHumores(Usuario usuario) throws SQLException, DAOException, HumorException {
        try {
            Connection con = connectionFactory.getConnection();

            PreparedStatement stmt = con.prepareStatement(selectHumoresQtde);
            stmt.setLong(1, usuario.getIdUsuario());
            ResultSet rs = stmt.executeQuery();
            
            TreeMap<Long, Integer> mapaHumorQtde = new TreeMap<Long, Integer>();

            while (rs.next()) {
                mapaHumorQtde.put(rs.getLong("id_humor"), rs.getInt("count(*)"));
            }

            stmt.close();

            return mapaHumorQtde;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...10", e);
        }
    }

    //Retorna um tree map contendo os id das atividades do usuário e suas respectivas qtdes de aparições nos registros Mood Tracker
    public TreeMap<Long, Integer> gerarGraficoContagemAtividades(Usuario usuario) throws SQLException, DAOException, HumorException {
        try {
            Connection con = connectionFactory.getConnection();

            PreparedStatement stmt = con.prepareStatement(selectAtividadesQtde);
            stmt.setLong(1, usuario.getIdUsuario());
            ResultSet rs = stmt.executeQuery();
            
            TreeMap<Long, Integer> mapaAtividadeQtde = new TreeMap<Long, Integer>();

            while (rs.next()) {
                mapaAtividadeQtde.put(rs.getLong("id_atividade"), rs.getInt("count(*)"));
            }

            stmt.close();

            return mapaAtividadeQtde;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...11", e);
        }
    }
    
    //Retorna um tree map contendo a descrição das atividades com maiores aparições no humor selecionado pelo usuário
    public TreeMap<String, Integer> gerarGraficoAtividadesPorHumor(Usuario usuario, Humor humor) throws SQLException, DAOException, HumorException {
        try {
            Connection con = connectionFactory.getConnection();

            PreparedStatement stmt = con.prepareStatement(selectAtividadesPorHumor);
            stmt.setLong(1, usuario.getIdUsuario());
            stmt.setLong(2, humor.getIdHumor());
            ResultSet rs = stmt.executeQuery();
            
            TreeMap<String, Integer> mapaAtividadesPorHumor = new TreeMap<String, Integer>();

            while (rs.next()) {
                mapaAtividadesPorHumor.put(rs.getString("descricao"), rs.getInt("count(*)"));
            }

            stmt.close();

            return mapaAtividadesPorHumor;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...12", e);
        }
    }

    //Retorna um tree map contendo a data e o humor dos registros Mood Tracker do usuário
    public TreeMap<LocalDate, Humor> gerarGraficoHumores(Usuario usuario) throws SQLException, DAOException, HumorException {
        try {
            // chama método da facade para listar os humores do usuario 
            List<Humor> listaHumores = HumorFacade.listarHumores(usuario);
            // recupera a qtde de humores através do tamanho da lista
            int qtdeHumores = listaHumores.size();
            
            Connection con = connectionFactory.getConnection();

            PreparedStatement stmt = con.prepareStatement(selectFlowHumores);
            stmt.setLong(1, usuario.getIdUsuario());
            ResultSet rs = stmt.executeQuery();
            
            TreeMap<LocalDate, Humor> mapaHumorPorData = new TreeMap<LocalDate, Humor>();
            
            while (rs.next()) {
                Humor humor = HumorFacade.buscarHumor(rs.getLong("id_humor"));
                
                long idAux = (qtdeHumores - 1);
                for(Humor h: listaHumores) {
                    if(humor.getIdHumor() == h.getIdHumor()) {
                        humor.setIdHumor(idAux);
                    }
                    idAux--;
                }
                
                mapaHumorPorData.put(rs.getDate("data").toLocalDate(), humor);
            }

            stmt.close();

            return mapaHumorPorData;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...13", e);
        }
    }
    
    //Retorna uma lista dos humores mais registrados pelo usuário por período
    public List<Humor> listarEstatisticasGerais(Usuario usuario) throws SQLException, DAOException, HumorException {   
        try {
            Connection con = connectionFactory.getConnection();
            
            List<Humor> listaEstatisticasGerais = new ArrayList<>();
            
            PreparedStatement stmt = con.prepareStatement(selectHumorDia);
            stmt.setLong(1, usuario.getIdUsuario());
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Humor humor = HumorFacade.buscarHumor(rs.getLong("id_Humor"));
                listaEstatisticasGerais.add(humor); 
            } else {
                listaEstatisticasGerais.add(null);
            }

            stmt = con.prepareStatement(selectHumorSemana);
            stmt.setLong(1, usuario.getIdUsuario());
            rs = stmt.executeQuery();
            if (rs.next()) {
                Humor humor = HumorFacade.buscarHumor(rs.getLong("id_Humor"));
                listaEstatisticasGerais.add(humor); 
            }  else {
                listaEstatisticasGerais.add(null);
            }
            
            stmt = con.prepareStatement(selectHumorMes);
            stmt.setLong(1, usuario.getIdUsuario());
            rs = stmt.executeQuery();
            if (rs.next()) {
                Humor humor = HumorFacade.buscarHumor(rs.getLong("id_Humor"));
                listaEstatisticasGerais.add(humor); 
            }  else {
                listaEstatisticasGerais.add(null);
            }
            
            stmt.close();
            
            return listaEstatisticasGerais;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...15", e);
        }
    }
    
    //Retora a qtde de dias consecutivos que o usuário cumpriu o objetivo
    public int gerarEstatisticasObjetivo(Usuario usuario) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
            
            boolean continua = true;
            LocalDate data = LocalDate.now();
            int qtde = 0;
            
            while(continua) {
                PreparedStatement stmt = con.prepareStatement(selectComData);
                stmt.setLong(1, usuario.getIdUsuario());
                stmt.setString(2, data.toString());
                ResultSet rs = stmt.executeQuery();
                
                if (rs.next()) {
                    int cumpriuObjetivo = rs.getInt("cumpriu_objetivo");
                    if(cumpriuObjetivo == 1) {
                        qtde++;
                        data = data.minusDays(1);
                    } else {
                        continua = false;
                    }
                } else {
                    stmt.close();
                    continua = false;
                }
            }
            
            return qtde;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...17",e);
        }
    }
    
    //Retorna true or false para verificar se o usuário já possui um registro Mood Tracker com determinada data
    public boolean validarDataRegistro(Usuario usuario, LocalDate data) throws SQLException, DAOException {   
        try {
            Connection con = connectionFactory.getConnection();
            
            PreparedStatement stmt = con.prepareStatement(selectComData);
            stmt.setLong(1, usuario.getIdUsuario());
            stmt.setString(2, data.toString());
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                stmt.close();
                return true;
            } else {
                stmt.close();
                return false;
            }
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...17",e);
        }
    }
    
}
