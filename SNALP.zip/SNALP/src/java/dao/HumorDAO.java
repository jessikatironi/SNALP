package dao;

import beans.Humor;
import beans.Usuario;
import exception.DAOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HumorDAO {
    
    private final ConnectionFactory connectionFactory;
    
    private final String select = "SELECT * FROM humor WHERE id_usuario = ? AND ativo = 1";                                 // listar humores           
    private final String search = "SELECT * FROM humor WHERE id_humor = ?";                                                 // buscar humor
    private final String insert = "INSERT INTO humor (descricao, emoji, cor, ativo, id_usuario) VALUES (?, ?, ?, 1, ?)";    // criar humor
    private final String update = "UPDATE humor SET descricao = ?, emoji = ?, cor = ? WHERE id_humor = ?";                  // atualizar humor
    private final String delete = "UPDATE humor SET ativo = 0 WHERE id_humor = ?";                                          // remover humor
    private final String selectCores = "SELECT * FROM picker_humor";                                                        // listar cores do color picker de humor
    private final String selectEmojis = "SELECT * FROM emoji_humor";                                                        // listar emojis disponíveis paa seleção
    
    
    public HumorDAO() {
        this.connectionFactory = new ConnectionFactory();
    }
    
    //Retorna uma lista de todos os humores de um usuário
    public List<Humor> listarHumores(Usuario usuario) throws SQLException, DAOException {   
        try {
            Connection con = connectionFactory.getConnection();
            
            PreparedStatement stmt = con.prepareStatement(select);
            stmt.setLong(1, usuario.getIdUsuario());
            ResultSet rs = stmt.executeQuery();
            
            List<Humor> humores = new ArrayList<>();
            
            while(rs.next()) {
                Humor humor = new Humor();
                
                humor.setIdHumor(rs.getLong("id_humor"));
                humor.setDescricaoHumor(rs.getString("descricao"));
                humor.setEmojiHumor(rs.getString("emoji"));
                humor.setCorHumor(rs.getString("cor"));
                
                humores.add(humor);
            }
            
            stmt.close();
            
            return humores;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...",e);
        }
    }
    
    //Retorna os dados de um humor do usuário
    public Humor buscarHumor(long idHumor) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();

            PreparedStatement stmt = con.prepareStatement(search);
            stmt.setLong(1, idHumor);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                Humor h = new Humor();

                h.setIdHumor(rs.getLong("id_humor"));
                h.setDescricaoHumor(rs.getString("descricao"));
                h.setEmojiHumor(rs.getString("emoji"));
                h.setCorHumor(rs.getString("cor"));
                
                stmt.close();
                return h;
            } else {
                stmt.close();
                throw new SQLException();
            }
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
    //Insere um novo humor no banco de dados
    public void criarHumor(Humor humor, Usuario usuario) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            PreparedStatement stmt = con.prepareStatement(insert);
            stmt.setString(1, humor.getDescricaoHumor());
            stmt.setString(2, humor.getEmojiHumor());
            stmt.setString(3, humor.getCorHumor());
            stmt.setLong(4, usuario.getIdUsuario());

            int x = stmt.executeUpdate();

            stmt.close();
        
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
    //Atualiza os dados de um humor no banco de dados
    public void atualizarHumor(Humor humor) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            PreparedStatement stmt = con.prepareStatement(update);
            stmt.setString(1, humor.getDescricaoHumor());
            stmt.setString(2, humor.getEmojiHumor());
            stmt.setString(3, humor.getCorHumor());
            stmt.setLong(4, humor.getIdHumor());
            int x = stmt.executeUpdate();

            stmt.close();
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }
    
    //Remove um humor no banco de dados: atualiza o atributo "ativo" para zero.
    public void removerHumor(long idHumor) throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
        
            PreparedStatement stmt = con.prepareStatement(delete);
            stmt.setLong(1, idHumor);
            int x = stmt.executeUpdate();
        
            stmt.close();
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...", e);
        }
    }

    //Retorna uma lista de todas as cores do color picker de humor
    public List<String> listarCores() throws SQLException, DAOException {   
        try {
            Connection con = connectionFactory.getConnection();
            
            PreparedStatement stmt = con.prepareStatement(selectCores);
            ResultSet rs = stmt.executeQuery();
            
            List<String> cores = new ArrayList<>();
            
            while(rs.next()) {
                String cor = rs.getString("cor");
                
                cores.add(cor);
            }
            
            stmt.close();
            
            return cores;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...",e);
        }
    }

    //Retorna uma lista de todas os emojis disponíveis para seleçã
    public List<String> listarEmojis() throws SQLException, DAOException {
        try {
            Connection con = connectionFactory.getConnection();
            
            PreparedStatement stmt = con.prepareStatement(selectEmojis);
            ResultSet rs = stmt.executeQuery();
            
            List<String> cores = new ArrayList<>();
            
            while(rs.next()) {
                String cor = rs.getString("emoji");
                
                cores.add(cor);
            }
            
            stmt.close();
            
            return cores;
            
        } catch (DAOException e) {
            throw new DAOException("Erro ao conectar com o banco de dados...",e);
        }
    }
    
}
