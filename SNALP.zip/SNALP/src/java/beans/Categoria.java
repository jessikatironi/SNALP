package beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Categoria implements Serializable{
    private long idCategoria;
    private String tituloCategoria;
    private List<Atividade> listaAtividadesCategoria = new ArrayList<Atividade>();

    public Categoria() {
    }

    public Categoria(long idCategoria, String tituloCategoria) {
        this.idCategoria = idCategoria;
        this.tituloCategoria = tituloCategoria;
    }

    public long getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(long idCategoria) {
        this.idCategoria = idCategoria;
    }

    public String getTituloCategoria() {
        return tituloCategoria;
    }

    public void setTituloCategoria(String tituloCategoria) {
        this.tituloCategoria = tituloCategoria;
    }

    public List<Atividade> getListaAtividadesCategoria() {
        return listaAtividadesCategoria;
    }

    public void setListaAtividadesCategoria(List<Atividade> listaAtividadesCategoria) {
        this.listaAtividadesCategoria = listaAtividadesCategoria;
    }
    
}
