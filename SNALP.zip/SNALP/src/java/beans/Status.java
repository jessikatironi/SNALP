package beans;

public class Status {
    private long idStatus;
    private String titulo;
    private String cor;
    private int ordem;

    public Status() {
    }

    public Status(String titulo, String cor) {
        this.titulo = titulo;
        this.cor = cor;
    }

    public Status(long idStatus, String titulo) {
        this.idStatus = idStatus;
        this.titulo = titulo;
    }

    public Status(long idStatus, String titulo, String cor) {
        this.idStatus = idStatus;
        this.titulo = titulo;
        this.cor = cor;
    }

    public Status(long idStatus, String titulo, String cor, int ordem) {
        this.idStatus = idStatus;
        this.titulo = titulo;
        this.cor = cor;
        this.ordem = ordem;
    }
    
    public long getIdStatus() {
        return idStatus;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getCor() {
        return cor;
    }

    public int getOrdem() {
        return ordem;
    }

    public void setIdStatus(long idStatus) {
        this.idStatus = idStatus;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public void setOrdem(int ordem) {
        this.ordem = ordem;
    }
}
