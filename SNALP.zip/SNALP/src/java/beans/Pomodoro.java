/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

import java.time.LocalDate;

/**
 *
 * @author eduar
 */
public class Pomodoro {
    private long idPomodoro;
    private String titulo;
    private int tempo;
    private int pausa;
    private int serie;
    private LocalDate dataLog;
    
    //Construtores
    public Pomodoro(long idPomodoro, String titulo, int tempo, int pausa, int serie) {
        this.idPomodoro = idPomodoro;
        this.titulo = titulo;
        this.tempo = tempo;
        this.pausa = pausa;
        this.serie = serie;
    }
    
    public Pomodoro(String titulo, int tempo, int pausa, int serie, LocalDate dataLog) {
        this.titulo = titulo;
        this.tempo = tempo;
        this.pausa = pausa;
        this.serie = serie;
        this.dataLog = dataLog;
    }

    public Pomodoro(String titulo, int tempo, int pausa, int serie) {
        this.titulo = titulo;
        this.tempo = tempo;
        this.pausa = pausa;
        this.serie = serie;
    }
    
    //Getters
    public long getIdPomodoro() {
        return idPomodoro;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getTempo() {
        return tempo;
    }

    public int getPausa() {
        return pausa;
    }

    public int getSerie() {
        return serie;
    }
    
    public LocalDate getDataLog() {
        return dataLog;
    }

    
    //Setters

    public void setIdPomodoro(long idPomodoro) {
        this.idPomodoro = idPomodoro;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setTempo(int tempo) {
        this.tempo = tempo;
    }

    public void setPausa(int pausa) {
        this.pausa = pausa;
    }

    public void setSerie(int serie) {
        this.serie = serie;
    }

    public void setDataLog(LocalDate dataLog) {
        this.dataLog = dataLog;
    }

    
}
