package beans;

import java.time.LocalDate;
import java.util.List;

public class Tarefa {
    private long idTarefa;
    private String titulo;
    private String descricao;
    private LocalDate dataCriacao;
    private LocalDate dataConclusao;
    private LocalDate dataEntrega;
    private int ordem;
    private boolean concluido;
    private Status status;
    private List<Subtarefa> subtarefas;
    private List<Etiqueta> etiquetas;
    private int qtdeTotal;
    private int qtdeConcluida;

    public Tarefa() {
    }
    
    //Construtor inserção
    public Tarefa(String titulo, String descricao, LocalDate dataEntrega) {
        this.titulo = titulo;
        this.descricao = descricao;
        this.dataEntrega = dataEntrega;
    }

    //Construtor lista de tarefas ativas
    public Tarefa(long idTarefa, String titulo, String descricao, LocalDate dataEntrega, int ordem, Status status) {
        this.idTarefa = idTarefa;
        this.titulo = titulo;
        this.descricao = descricao;
        this.dataEntrega = dataEntrega;
        this.ordem = ordem;
        this.status = status;
    }
    
    //Construtor calendário
    public Tarefa(long idTarefa, String titulo, LocalDate dataEntrega) {
        this.idTarefa = idTarefa;
        this.titulo = titulo;
        this.dataEntrega = dataEntrega;
    }
    
    //Construtor com todos os atributos
    public Tarefa(long idTarefa, String titulo, String descricao, LocalDate dataEntrega, int ordem, boolean concluido, Status status) {
        this.idTarefa = idTarefa;
        this.titulo = titulo;
        this.descricao = descricao;
        this.dataEntrega = dataEntrega;
        this.ordem = ordem;
        this.concluido = concluido;
        this.status = status;
    }

    public long getIdTarefa() {
        return idTarefa;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public LocalDate getDataCriacao() {
        return dataCriacao;
    }

    public LocalDate getDataConclusao() {
        return dataConclusao;
    }

    public LocalDate getDataEntrega() {
        return dataEntrega;
    }

    public int getOrdem() {
        return ordem;
    }

    public boolean isConcluido() {
        return concluido;
    }

    public Status getStatus() {
        return status;
    }

    public void setIdTarefa(long idTarefa) {
        this.idTarefa = idTarefa;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setDataCriacao(LocalDate dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public void setDataConclusao(LocalDate dataConclusao) {
        this.dataConclusao = dataConclusao;
    }

    public void setDataEntrega(LocalDate dataEntrega) {
        this.dataEntrega = dataEntrega;
    }

    public void setOrdem(int ordem) {
        this.ordem = ordem;
    }

    public void setConcluido(boolean concluido) {
        this.concluido = concluido;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public List<Subtarefa> getSubtarefas() {
        return subtarefas;
    }

    public void setSubtarefas(List<Subtarefa> subtarefas) {
        this.subtarefas = subtarefas;
    }

    public List<Etiqueta> getEtiquetas() {
        return etiquetas;
    }

    public void setEtiquetas(List<Etiqueta> etiquetas) {
        this.etiquetas = etiquetas;
    }

    public int getQtdeTotal() {
        return qtdeTotal;
    }

    public int getQtdeConcluida() {
        return qtdeConcluida;
    }

    public void setQtdeTotal(int qtdeTotal) {
        this.qtdeTotal = qtdeTotal;
    }

    public void setQtdeConcluida(int qtdeConcluida) {
        this.qtdeConcluida = qtdeConcluida;
    }
    
    public int getMonthValue() {
        return this.dataEntrega.getMonthValue();
    }
    public int getDayOfMonth() {
       return this.dataEntrega.getDayOfMonth();
    }
    public int getYearValue() {
       return this.dataEntrega.getYear();
    }
}
