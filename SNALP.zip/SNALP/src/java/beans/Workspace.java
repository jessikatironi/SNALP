package beans;

import java.time.LocalDate;

public class Workspace {
    private long idWorkspace;
    private String titulo;
    private String descricao;
    private LocalDate dataCriacao;
    //Usuario

    public Workspace() {
    }

    public Workspace(String titulo, String descricao) {
        this.titulo = titulo;
        this.descricao = descricao;
    }

    public Workspace(long idWorkspace, String titulo, String descricao) {
        this.idWorkspace = idWorkspace;
        this.titulo = titulo;
        this.descricao = descricao;
    }

    public Workspace(long idWorkspace, String titulo, String descricao, LocalDate dataCriacao) {
        this.idWorkspace = idWorkspace;
        this.titulo = titulo;
        this.descricao = descricao;
        this.dataCriacao = dataCriacao;
    }

    public long getIdWorkspace() {
        return idWorkspace;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDescricao() {
        return descricao;
    }

    public LocalDate getDataCriacao() {
        return dataCriacao;
    }

    public void setIdWorkspace(long idWorkspace) {
        this.idWorkspace = idWorkspace;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setDataCriacao(LocalDate dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

}
