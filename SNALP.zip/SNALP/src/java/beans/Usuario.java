package beans;

import java.time.LocalDate;
import java.util.List;

public class Usuario {
    private long idUsuario;
    private String nomeUsuario;
    private String emailUsuario;
    private String senhaUsuario;
    private LocalDate dataCadastroUsuario;
    private List<Workspace> workspaces;//Lista Workspace

    //Construtores
    public Usuario(String nomeUsuario, String emailUsuario, String senhaUsuario, LocalDate dataCadastroUsuario) {
        this.nomeUsuario = nomeUsuario;
        this.emailUsuario = emailUsuario;
        this.senhaUsuario = senhaUsuario;
        this.dataCadastroUsuario = dataCadastroUsuario;
    }

    public Usuario(long idUsuario, String nomeUsuario, String emailUsuario) {
        this.idUsuario = idUsuario;
        this.nomeUsuario = nomeUsuario;
        this.emailUsuario = emailUsuario;
    }
    public Usuario(String nomeUsuario, long idUsuario) {
        this.nomeUsuario = nomeUsuario;
        this.idUsuario = idUsuario;
    }

    public Usuario(long idUsuario, String senhaUsuario) {
        this.idUsuario = idUsuario;
        this.senhaUsuario = senhaUsuario;
    }

    public Usuario(long idUsuario, String nomeUsuario, List<Workspace> workspaces) {
        this.idUsuario = idUsuario;
        this.nomeUsuario = nomeUsuario;
        this.workspaces = workspaces;
    }
    
    //Getters
    public long getIdUsuario() {
        return idUsuario;
    }

    public String getNomeUsuario() {
        return nomeUsuario;
    }

    public String getEmailUsuario() {
        return emailUsuario;
    }

    public String getSenhaUsuario() {
        return senhaUsuario;
    }

    public LocalDate getDataCadastroUsuario() {
        return dataCadastroUsuario;
    }

    public List<Workspace> getWorkspaces() {
        return workspaces;
    }
    
    //Setters

    public void setIdUsuario(long idUsuario) {
        this.idUsuario = idUsuario;
    }

    public void setNomeUsuario(String nomeUsuario) {
        this.nomeUsuario = nomeUsuario;
    }

    public void setEmailUsuario(String emailUsuario) {
        this.emailUsuario = emailUsuario;
    }

    public void setSenhaUsuario(String senhaUsuario) {
        this.senhaUsuario = senhaUsuario;
    }

    public void setDataCadastroUsuario(LocalDate dataCadastroUsuario) {
        this.dataCadastroUsuario = dataCadastroUsuario;
    }

    public void setWorkspaces(List<Workspace> workspaces) {
        this.workspaces = workspaces;
    }    
}
