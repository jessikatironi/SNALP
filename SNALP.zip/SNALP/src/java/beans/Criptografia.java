/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 *
 * @author eduar
 */
public class Criptografia {
    
    private static MessageDigest md = null;
    
    static{
        try{
            md = MessageDigest.getInstance("MD5");
        } catch(NoSuchAlgorithmException e){
            e.printStackTrace();
        }
    }
    
    private static char[] hexCodes(byte[] text){
        char[] hexOutput = new char[text.length * 2];
        String hexString;
        for(int i=0; i < text.length; i++){
            hexString = "00" + Integer.toHexString(text[i]);
            hexString.toUpperCase().getChars(hexString.length() - 2, hexString.length(), hexOutput, i * 2);
        }
        return hexOutput;
    }
    
    public static String criptografar(String pass){
        if(md != null){
            return new String(hexCodes(md.digest(pass.getBytes())));
        }
        return null;
    }

    
}
