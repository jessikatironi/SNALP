package beans;

public class Subtarefa {
    private long idSubtarefa;
    private String descricao;
    private boolean concluido;

    public Subtarefa() {
    }

    public Subtarefa(String descricao) {
        this.descricao = descricao;
    }

    public Subtarefa(long idSubtarefa, String descricao) {
        this.idSubtarefa = idSubtarefa;
        this.descricao = descricao;
    }

    public Subtarefa(long idSubtarefa, String descricao, boolean concluido) {
        this.idSubtarefa = idSubtarefa;
        this.descricao = descricao;
        this.concluido = concluido;
    }

    public long getIdSubtarefa() {
        return idSubtarefa;
    }

    public String getDescricao() {
        return descricao;
    }

    public boolean isConcluido() {
        return concluido;
    }

    public void setIdSubtarefa(long idSubtarefa) {
        this.idSubtarefa = idSubtarefa;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setConcluido(boolean concluido) {
        this.concluido = concluido;
    }

}
