package beans;

import java.io.Serializable;

public class Humor implements Serializable {
    private long idHumor;
    private String descricaoHumor;
    private String emojiHumor;
    private String corHumor;

    public Humor() {
    }

    public Humor(long idHumor, String descricaoHumor, String emojiHumor, String corHumor) {
        this.idHumor = idHumor;
        this.descricaoHumor = descricaoHumor;
        this.emojiHumor = emojiHumor;
        this.corHumor = corHumor;
    }

    public long getIdHumor() {
        return idHumor;
    }

    public void setIdHumor(long idHumor) {
        this.idHumor = idHumor;
    }

    public String getDescricaoHumor() {
        return descricaoHumor;
    }

    public void setDescricaoHumor(String descricaoHumor) {
        this.descricaoHumor = descricaoHumor;
    }

    public String getEmojiHumor() {
        return emojiHumor;
    }

    public void setEmojiHumor(String emojiHumor) {
        this.emojiHumor = emojiHumor;
    }

    public String getCorHumor() {
        return corHumor;
    }

    public void setCorHumor(String corHumor) {
        this.corHumor = corHumor;
    }
    
}
