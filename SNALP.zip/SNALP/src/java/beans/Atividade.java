package beans;

import java.io.Serializable;

public class Atividade implements Serializable{
    private long idAtividade;
    private String descricaoAtividade;
    private Categoria categoriaAtividade;

    public Atividade() {
    }

    public Atividade(long idAtividade, String descricaoAtividade, Categoria categoriaAtividade) {
        this.idAtividade = idAtividade;
        this.descricaoAtividade = descricaoAtividade;
        this.categoriaAtividade = categoriaAtividade;
    }

    public long getIdAtividade() {
        return idAtividade;
    }

    public void setIdAtividade(long idAtividade) {
        this.idAtividade = idAtividade;
    }

    public String getDescricaoAtividade() {
        return descricaoAtividade;
    }

    public void setDescricaoAtividade(String descricaoAtividade) {
        this.descricaoAtividade = descricaoAtividade;
    }

    public Categoria getCategoriaAtividade() {
        return categoriaAtividade;
    }

    public void setCategoriaAtividade(Categoria categoriaAtividade) {
        this.categoriaAtividade = categoriaAtividade;
    }
    
}
