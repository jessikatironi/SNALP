package beans;

public class Etiqueta {
    private long idEtiqueta;
    private String titulo;
    private String cor;

    public Etiqueta() {
    }

    public Etiqueta(String titulo, String cor) {
        this.titulo = titulo;
        this.cor = cor;
    }

    public Etiqueta(long idEtiqueta, String titulo, String cor) {
        this.idEtiqueta = idEtiqueta;
        this.titulo = titulo;
        this.cor = cor;
    }

    public long getIdEtiqueta() {
        return idEtiqueta;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getCor() {
        return cor;
    }

    public void setIdEtiqueta(long idEtiqueta) {
        this.idEtiqueta = idEtiqueta;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }
    
}
