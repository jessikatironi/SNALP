package beans;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;

public class Objetivo implements Serializable {
    private long idObjetivo;
    private String tituloObjetivo;
    private String descricaoObjetivo;
    private LocalDate dataCriacaoObjetivo;
    private LocalDate dataFimObjetivo;

    public Objetivo() {
    }

    public long getIdObjetivo() {
        return idObjetivo;
    }

    public void setIdObjetivo(long idObjetivo) {
        this.idObjetivo = idObjetivo;
    }

    public String getTituloObjetivo() {
        return tituloObjetivo;
    }

    public void setTituloObjetivo(String tituloObjetivo) {
        this.tituloObjetivo = tituloObjetivo;
    }

    public String getDescricaoObjetivo() {
        return descricaoObjetivo;
    }

    public void setDescricaoObjetivo(String descricaoObjetivo) {
        this.descricaoObjetivo = descricaoObjetivo;
    }

    public LocalDate getDataCriacaoObjetivo() {
        return dataCriacaoObjetivo;
    }

    public void setDataCriacaoObjetivo(LocalDate dataCriacaoObjetivo) {
        this.dataCriacaoObjetivo = dataCriacaoObjetivo;
    }

    public LocalDate getDataFimObjetivo() {
        return dataFimObjetivo;
    }

    public void setDataFimObjetivo(LocalDate dataFimObjetivo) {
        this.dataFimObjetivo = dataFimObjetivo;
    }
    
}
