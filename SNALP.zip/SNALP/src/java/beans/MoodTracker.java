package beans;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MoodTracker implements Serializable{
    private long idMoodTracker;
    private LocalDate dataMoodTracker;
    private String descricaoMoodTracker;
    private boolean cumpriuObjetivoMoodTracker;
    private Humor humorMoodTracker;
    private List<Atividade> listaAtividadesMoodTracker = new ArrayList<Atividade>();

    public MoodTracker() {
    }

    public long getIdMoodTracker() {
        return idMoodTracker;
    }

    public void setIdMoodTracker(long idMoodTracker) {
        this.idMoodTracker = idMoodTracker;
    }

    public LocalDate getDataMoodTracker() {
        return dataMoodTracker;
    }

    public void setDataMoodTracker(LocalDate dataMoodTracker) {
        this.dataMoodTracker = dataMoodTracker;
    }

    public String getDescricaoMoodTracker() {
        return descricaoMoodTracker;
    }

    public void setDescricaoMoodTracker(String descricaoMoodTracker) {
        this.descricaoMoodTracker = descricaoMoodTracker;
    }

    public boolean getCumpriuObjetivoMoodTracker() {
        return cumpriuObjetivoMoodTracker;
    }

    public void setCumpriuObjetivoMoodTracker(boolean cumpriuObjetivoMoodTracker) {
        this.cumpriuObjetivoMoodTracker = cumpriuObjetivoMoodTracker;
    }

    public Humor getHumorMoodTracker() {
        return humorMoodTracker;
    }

    public void setHumorMoodTracker(Humor humorMoodTracker) {
        this.humorMoodTracker = humorMoodTracker;
    }

    public List<Atividade> getListaAtividadesMoodTracker() {
        return listaAtividadesMoodTracker;
    }

    public void setListaAtividadesMoodTracker(List<Atividade> listaAtividadesMoodTracker) {
        this.listaAtividadesMoodTracker = listaAtividadesMoodTracker;
    }
    
    public String getDayOfWeek() {
        Locale local = new Locale("pt", "BR");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE", local);
        return this.dataMoodTracker.format(formatter);
    }
    
}
