package facade;

import beans.Status;
import beans.Tarefa;
import dao.ConnectionFactory;
import dao.StatusDAO;
import dao.TarefaDAO;
import exception.DAOException;
import exception.TarefaException;
import java.sql.SQLException;
import java.util.List;

public class TarefaFacade {
    
    //Cria uma nova tarefa
    public void criarTarefa(Tarefa t, long idStatus) throws DAOException, TarefaException{
        TarefaDAO dao = new TarefaDAO(new ConnectionFactory());
        try{
            dao.inserir(t,idStatus);
        } catch (SQLException e){
            throw new TarefaException("Erro ao criar a tarefa",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Atualiza uma tarefa existente
    public void atualizarTarefa(Tarefa t, String tipo) throws TarefaException, DAOException{
        TarefaDAO dao = new TarefaDAO(new ConnectionFactory());
        try{
            if (tipo.equals("titulo")) dao.atualizarTitulo(t);
            else if(tipo.equals("desc")) dao.atualizarDesc(t);
            else if(tipo.equals("data")) dao.atualizarData(t);
        } catch (SQLException e){
            throw new TarefaException("Erro ao atualizar a tarefa",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Remove uma tarefa
    public void removerTarefa(long idTarefa) throws DAOException, TarefaException{
        TarefaDAO dao = new TarefaDAO(new ConnectionFactory());
        try{
            Tarefa t = dao.buscar(idTarefa);
            dao.remover(t.getIdTarefa());
            dao.atualizarOrdemDelete(t);
        } catch (SQLException e){
            throw new TarefaException("Erro ao remover a tarefa",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Lista todas as tarefas de uma workspace
    public List<Tarefa> listarTarefas(long idWorkspace) throws TarefaException, DAOException{
        TarefaDAO dao = new TarefaDAO(new ConnectionFactory());
        try{
            List<Tarefa> tarefas = dao.listar(idWorkspace);
            return tarefas;
        } catch (SQLException e){
            throw new TarefaException("Erro ao buscar lista de tarefas",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Lista todas as tarefas ativas de uma workspace
    public List<Tarefa> listarTarefasAtivas(long idWorkspace) throws TarefaException, DAOException{
        TarefaDAO dao = new TarefaDAO(new ConnectionFactory());
        try{
            List<Tarefa> tarefas = dao.listarAtivas(idWorkspace);
            return tarefas;
        } catch (SQLException e){
            throw new TarefaException("Erro ao buscar lista de tarefas",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Lista todas as tarefas concluidas de uma workspace
    public List<Tarefa> listarTarefasConcluidas(long idWorkspace) throws TarefaException, DAOException{
        TarefaDAO dao = new TarefaDAO(new ConnectionFactory());
        try{
            List<Tarefa> tarefas = dao.listarConcluidas(idWorkspace);
            return tarefas;
        } catch (SQLException e){
            throw new TarefaException("Erro ao buscar lista de tarefas",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }

    //Lista todas as tarefas de um status
    public List<Tarefa> tarefasStatus(long idStatus) throws TarefaException, DAOException{
        TarefaDAO dao = new TarefaDAO(new ConnectionFactory());
        try{
            List<Tarefa> tarefas = dao.tarefasStatus(idStatus);
            return tarefas;
        } catch (SQLException e){
            throw new TarefaException("Erro ao buscar lista de tarefas do status",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
        
    //Lista de tarefas para visualização calendário
    public List<Tarefa> tarefasCalendario(long idWorkspace) throws TarefaException, DAOException{
        TarefaDAO dao = new TarefaDAO(new ConnectionFactory());
        try{
            List<Tarefa> tarefas = dao.tarefasCalendario(idWorkspace);
            return tarefas;
        } catch (SQLException e){
            throw new TarefaException("Erro ao buscar lista de tarefas da workspace",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Busca uma tarefa e retorna seus dados
    public Tarefa buscarTarefa(long idTarefa) throws TarefaException, DAOException {
        TarefaDAO dao = new TarefaDAO(new ConnectionFactory());
        try{
            Tarefa t = dao.buscar(idTarefa);
            return t;
        } catch (SQLException e){
            throw new TarefaException("Erro ao buscar a tarefa",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
   
    //Muda status de uma tarefa
    public void mudarStatus(long oldStatus, long newStatus, int oldOrdem, int newOrdem, long idTarefa) throws TarefaException, DAOException{
        TarefaDAO dao = new TarefaDAO(new ConnectionFactory());
        try{
            dao.fixOrderOldStatus(oldStatus, oldOrdem, idTarefa);
            dao.fixOrderNewStatus(newStatus, newOrdem);
            dao.statusChange(newStatus, newOrdem, idTarefa);
        } catch (SQLException e){
            throw new TarefaException("Erro ao mudar status da tarefa",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Muda tarefa para o final de um status
    public void mudarStatusFinal(long oldStatus, long newStatus, int oldOrdem, int newOrdem, long idTarefa) throws TarefaException, DAOException{
        TarefaDAO dao = new TarefaDAO(new ConnectionFactory());
        try{
            dao.fixOrderOldStatus(oldStatus, oldOrdem, idTarefa);
            dao.statusChange(newStatus, newOrdem + 1, idTarefa);
        } catch (SQLException e){
            throw new TarefaException("Erro ao mudar status da tarefa",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Muda status da tarefa pelo modal da tarefa
    public void mudarStatusTarefa(long oldStatus, long newStatus, long idTarefa, int oldOrdem) throws TarefaException, DAOException{
        TarefaDAO dao = new TarefaDAO(new ConnectionFactory());
        try{
            int newOrdem = dao.ordem(newStatus);
            dao.fixOrderOldStatus(oldStatus, oldOrdem, idTarefa);
            dao.statusChange(newStatus, newOrdem, idTarefa);
        } catch (SQLException e){
            throw new TarefaException("Erro ao mudar status da tarefa",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Muda ordem de uma tarefa dentro de um status - para cima
    public void mudarOrdemUp(long idStatus, int oldOrdem, int newOrdem, long idTarefa) throws TarefaException, DAOException {
        TarefaDAO dao = new TarefaDAO(new ConnectionFactory());
        try{
            dao.fixOrderUp(idStatus, oldOrdem, newOrdem, idTarefa);
            dao.orderChange(newOrdem, idTarefa);
        } catch (SQLException e){
            throw new TarefaException("Erro ao mudar a ordem da tarefa",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Muda ordem de uma tarefa dentro de um status - para baixo
    public void mudarOrdemDown(long idStatus, int oldOrdem, int newOrdem, long idTarefa) throws TarefaException, DAOException {
        TarefaDAO dao = new TarefaDAO(new ConnectionFactory());
        try{
            dao.fixOrderDown(idStatus, oldOrdem, newOrdem, idTarefa);
            dao.orderChange(newOrdem, idTarefa);
        } catch (SQLException e){
            throw new TarefaException("Erro ao mudar a ordem da tarefa",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Completa uma tarefa
    public void completarTarefa(long idTarefa, String tipo, long idWorkspace) throws TarefaException, DAOException {
        TarefaDAO dao = new TarefaDAO(new ConnectionFactory());
        StatusDAO sdao = new StatusDAO(new ConnectionFactory());
        try{
            Tarefa t = new Tarefa();
            if(tipo.equals("complete")){
                t = dao.buscar(idTarefa);
                dao.fixOrderOldStatus(t.getStatus().getIdStatus(), t.getOrdem(), t.getIdTarefa());
                dao.completeTarefa(t.getIdTarefa(), idWorkspace);
            }
            else {
                t = dao.buscar(idTarefa);
                Status s = sdao.buscarOrdem(idWorkspace);
                int ordem = dao.ordem(s.getIdStatus());
                dao.uncompleteTarefa(t.getIdTarefa(),s.getIdStatus(), ordem);
            }
        } catch (SQLException e){
            throw new TarefaException("Erro ao alterar o estado da tarefa",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }

}