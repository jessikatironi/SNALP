package facade;

import beans.Atividade;
import beans.Humor;
import beans.MoodTracker;
import beans.Usuario;
import dao.MoodTrackerDAO;
import exception.AtividadeException;
import exception.CategoriaException;
import exception.DAOException;
import exception.HumorException;
import exception.MoodTrackerException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.TreeMap;

public class MoodTrackerFacade {

    //Retorna uma lista de todos os registros Mood Tracker de um usuário
    public static List<MoodTracker> listarRegistros(Usuario usuario) throws MoodTrackerException, HumorException, DAOException, AtividadeException, CategoriaException {
        try{
            MoodTrackerDAO dao = new MoodTrackerDAO();
            return dao.listarRegistros(usuario);
        }
        catch(SQLException e){
            throw new MoodTrackerException("Erro ao listar registros Mood Tracker...  -> " + e);
        }
    };

    //Retorna uma lista de todas as atividades de um registo MoodTracker do usuário
    public static List<Atividade> listarAtividadesRegistro(MoodTracker moodtracker) throws MoodTrackerException, AtividadeException, CategoriaException, DAOException {
        try{
            MoodTrackerDAO dao = new MoodTrackerDAO();
            return dao.listarAtividadesRegistro(moodtracker);
        }
        catch(SQLException e){
            throw new MoodTrackerException("Erro ao listar atividades do registro Mood Tracker...  -> " + e);
        }
    };
    
    //Retorna os dados de um registro mood tracker do usuário
    public static MoodTracker buscarRegistro(long idMoodTracker) throws MoodTrackerException, HumorException, DAOException, AtividadeException, CategoriaException {
        try{
            MoodTrackerDAO dao = new MoodTrackerDAO();
            return dao.buscarRegistro(idMoodTracker);
        }
        catch(SQLException e){
            throw new HumorException("Erro ao buscar dados do humor...  -> " + e);
        }
    };
    
    //Retorna os dados do último registro mood tracker do usuário
    public static MoodTracker buscarUltimoRegistro(Usuario usuario) throws MoodTrackerException, HumorException, DAOException, AtividadeException, CategoriaException {
        try{
            MoodTrackerDAO dao = new MoodTrackerDAO();
            return dao.buscarUltimoRegistro(usuario);
        }
        catch(SQLException e){
            throw new MoodTrackerException("Erro ao buscar o último registro Mood Tracker...  -> " + e);
        }
    };
    
    //Insere um novo registro mood tracker no banco de dados
    public static void criarRegistro(MoodTracker moodtracker, Usuario usuario) throws MoodTrackerException, AtividadeException, CategoriaException, DAOException {
        try{
            MoodTrackerDAO dao = new MoodTrackerDAO();
            
            // primeiro, insere o novo registro no banco de dados
            dao.criarRegistro(moodtracker, usuario);
            
            // na sequência, se o novo registro possuir atividades selecionadas
            if(!moodtracker.getListaAtividadesMoodTracker().isEmpty()){
                // recupera o id do novo registro criado e seta o id no objeto moodtracker
                long id = dao.buscarIdRegistroCriado();
                moodtracker.setIdMoodTracker(id);
                // para então, adicionar as atividades do novo registro no banco de dados (é necessário ter o id do registro criado)
                dao.inserirAtividadesRegistro(moodtracker);
            } 
            
        } catch(SQLException e){
            throw new MoodTrackerException("Erro ao criar novo registro mood tracker... -> " + e);
        }
    };
    
    //Atualiza os dados de um registro mood tracker no banco de dados
    public static void atualizarRegistro(MoodTracker moodtracker) throws MoodTrackerException, CategoriaException, AtividadeException, DAOException {
        try{
            MoodTrackerDAO dao = new MoodTrackerDAO();
           
            // primeiro, atualiza o registro no banco de dados
            dao.atualizarRegistro(moodtracker);
            // na sequência, recupera a antiga lista de atividades do registro
            List<Atividade> listaAntiga = dao.listarAtividadesRegistro(moodtracker);
            // em seguida, instancia um novo registro mood tracker para auxiliar na atualização da lista de atividades do registro
            MoodTracker aux = new MoodTracker();
            aux.setIdMoodTracker(moodtracker.getIdMoodTracker());
            aux.setListaAtividadesMoodTracker(listaAntiga);
            dao.removerAtividadesRegistro(aux);
            // para então, atualizar as atividades do registro no banco de dados
            dao.inserirAtividadesRegistro(moodtracker);
        }
        catch(SQLException  e){
            throw new MoodTrackerException("Erro ao atualizar registro mood tracker... -> " + e);
        }
    };

    //Remove um registro mood tracker do banco de dados
    public static void removerRegistro(long idMoodTracker) throws MoodTrackerException, HumorException, CategoriaException, AtividadeException, DAOException {
        try{
            MoodTrackerDAO dao = new MoodTrackerDAO();
            
            // primeiro, recupera os dados do registro mood tracker (é necessário ter a lista das atividades do registro a ser excluido)
            MoodTracker registro = MoodTrackerFacade.buscarRegistro(idMoodTracker);
            // na sequência, remove as atividades do registro do banco de dados
            dao.removerAtividadesRegistro(registro);
            // para então, remover o registro mood tracker do banco de dados
            dao.removerRegistro(idMoodTracker);
        }
        catch(SQLException e){
            throw new MoodTrackerException("Erro ao remover registro mood tracker... -> " + e);
        }
    };

    //Retorna um tree map contendo os id dos humores do usuário e suas respectivas qtdes de aparições nos registros Mood Tracker
    public static TreeMap<Long, Integer> gerarGraficoContagemHumores(Usuario usuario) throws MoodTrackerException, HumorException, DAOException {
        try{
            MoodTrackerDAO dao = new MoodTrackerDAO();
            return dao.gerarGraficoContagemHumores(usuario);
        }
        catch(SQLException e){
            throw new MoodTrackerException("Erro ao gerar gráfico de contagem de humores... -> " + e);
        }
    };
    
    //Retorna um tree map contendo os id das atividades do usuário e suas respectivas qtdes de aparições nos registros Mood Tracker
    public static TreeMap<Long, Integer> gerarGraficoContagemAtividades(Usuario usuario) throws MoodTrackerException, HumorException, DAOException {
        try{
            MoodTrackerDAO dao = new MoodTrackerDAO();
            return dao.gerarGraficoContagemAtividades(usuario);
        }
        catch(SQLException e){
            throw new MoodTrackerException("Erro ao gerar gráfico de contagem de atividades... -> " + e);
        }
    };
    
    //Retorna um tree map contendo a descrição das atividades com maiores aparições no humor selecionado pelo usuário
    public static TreeMap<String, Integer> gerarGraficoAtividadesPorHumor(Usuario usuario, Humor humor) throws MoodTrackerException, HumorException, DAOException {
        try{
            MoodTrackerDAO dao = new MoodTrackerDAO();
            return dao.gerarGraficoAtividadesPorHumor(usuario, humor);
        }
        catch(SQLException e){
            throw new MoodTrackerException("Erro ao gerar gráfico de atividades mais frequentes por humor... -> " + e);
        }
    };

    //Retorna um tree map contendo a data e o humor dos registros Mood Tracker do usuário
    public static TreeMap<LocalDate, Humor> gerarGraficoHumores(Usuario usuario) throws MoodTrackerException, HumorException, DAOException {
        try{
            MoodTrackerDAO dao = new MoodTrackerDAO();
            return dao.gerarGraficoHumores(usuario);
        }
        catch(SQLException e){
            throw new MoodTrackerException("Erro ao gerar gráfico de humores... -> " + e);
        }
    };
    
    //Retorna uma lista dos humores mais registrados pelo usuário por período
    public static List<Humor> listarEstatisticasGerais(Usuario usuario) throws MoodTrackerException, HumorException, DAOException {
        try{
            MoodTrackerDAO dao = new MoodTrackerDAO();
            return dao.listarEstatisticasGerais(usuario);
        }
        catch(SQLException e){
            throw new MoodTrackerException("Erro ao listar estatísticas gerais dos registros Mood Tracker do usuário...  -> " + e);
        }
    };
    
    //Retora a qtde de dias consecutivos que o usuário cumpriu o objetivo
    public static int gerarEstatisticasObjetivo(Usuario usuario) throws MoodTrackerException, DAOException {
        try{
            MoodTrackerDAO dao = new MoodTrackerDAO();
            return dao.gerarEstatisticasObjetivo(usuario);
        }
        catch(SQLException e){
            throw new MoodTrackerException("Erro ao gerar estatísticas do objetivo do usuário...  -> " + e);
        }
    };
    
    //Retorna true or false para verificar se o usuário já possui um registro Mood Tracker com determinada data
    // false - sem registro Mood Tracker na data
    // true - com registro Mood Tracker na data
    public static boolean validarDataRegistro(Usuario usuario, LocalDate data) throws  MoodTrackerException, DAOException {
        try{
            MoodTrackerDAO dao = new MoodTrackerDAO();
            return dao.validarDataRegistro(usuario, data);
        }
        catch(SQLException e){
            throw new MoodTrackerException("Erro ao verificar existencia de registro Mood Tracker com a data selecionada...  -> " + e);
        }
    };
    
}
