package facade;

import beans.Objetivo;
import beans.Usuario;
import dao.ObjetivoDAO;
import exception.DAOException;
import exception.ObjetivoException;
import java.sql.SQLException;

public class ObjetivoFacade {
    
    //Retorna os dados do objetivo ativo do usuário
    public static Objetivo buscarObjetivo(Usuario usuario) throws ObjetivoException, DAOException {
        try{
            ObjetivoDAO dao = new ObjetivoDAO();
            return dao.buscarObjetivo(usuario);
        }
        catch(SQLException e){
            throw new ObjetivoException("Erro ao buscar dados do objetivo...  -> " + e);
        }
    };
    
    //Insere um novo objetivo no banco de dados
    public static void criarObjetivo(Objetivo objetivo, Usuario usuario) throws ObjetivoException, DAOException {
        try{
            ObjetivoDAO dao = new ObjetivoDAO();
            dao.criarObjetivo(objetivo, usuario);
        }
        catch(SQLException e){
            throw new ObjetivoException("Erro ao criar objetivo... -> " + e);
        }
    };
    
    //Atualiza os dados de um objetivo no banco de dados
    public static void atualizarObjetivo(Objetivo objetivo) throws ObjetivoException, DAOException {
        try{
           ObjetivoDAO dao = new ObjetivoDAO();
            dao.atualizarObjetivo(objetivo);
        }
        catch(SQLException  e){
            throw new ObjetivoException("Erro ao atualizar objetivo... -> " + e);
        }
    };
    
    //Remove um objetivo no banco de dados
    public static void removerObjetivo(long idObjetivo) throws ObjetivoException, DAOException {
        try{
            ObjetivoDAO dao = new ObjetivoDAO();
            dao.removerObjetivo(idObjetivo);
        }
        catch(SQLException e){
            throw new ObjetivoException("Erro ao remover objetivo... -> " + e);
        }
    };
    
    //Retorna true or false para verificar se o usuário já tem um objetivo ativo: false - sem objetivo ativo / true - com objetivo ativo
    public static boolean verificarObjetivo(Usuario usuario) throws ObjetivoException, DAOException {
        try{
            ObjetivoDAO dao = new ObjetivoDAO();
            return dao.verificarObjetivo(usuario);
        }
        catch(SQLException e){
            throw new ObjetivoException("Erro ao verificar objetivo...  -> " + e);
        }
    };
    
}
