package facade;

import beans.Usuario;
import beans.Workspace;
import dao.ConnectionFactory;
import dao.StatusDAO;
import dao.WorkspaceDAO;
import exception.DAOException;
import exception.WorkspaceException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

public class WorkspaceFacade {
    
    //Cria uma nova workspace
    public void criarWorkspace(Workspace w, Usuario u) throws DAOException, WorkspaceException{
        WorkspaceDAO dao = new WorkspaceDAO(new ConnectionFactory());
        StatusDAO stDao = new StatusDAO(new ConnectionFactory());
        try{
            dao.inserir(w,u);
            stDao.inserirStatus(w.getIdWorkspace());
        } catch (SQLException e){
            throw new WorkspaceException("Erro ao criar a workspace",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Atualiza uma workspace existente
    public void atualizarWorkspace(Workspace w) throws WorkspaceException, DAOException{
        WorkspaceDAO dao = new WorkspaceDAO(new ConnectionFactory());
        try{
            dao.atualizar(w);
        } catch (SQLException e){
            throw new WorkspaceException("Erro ao atualizar a workspace",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Remove uma workspace
    public void removerWorkspace(long idWorkspace) throws DAOException, WorkspaceException{
        WorkspaceDAO dao = new WorkspaceDAO(new ConnectionFactory());
        try{
            dao.remover(idWorkspace);
        } catch (SQLException e){
            throw new WorkspaceException("Erro ao remover a workspace",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Lista todas as workspaces de um usuario
    public List<Workspace> listarWorkspaces(Usuario u) throws WorkspaceException, DAOException{
        WorkspaceDAO dao = new WorkspaceDAO(new ConnectionFactory());
        try{
            List<Workspace> workspaces = dao.listar(u);
            return workspaces;
        } catch (SQLException e){
            throw new WorkspaceException("Erro ao buscar lista de workspaces",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Busca uma workspace e retorna seus dados
    public Workspace buscarWorkspace(long idWorkspace) throws WorkspaceException, DAOException {
        WorkspaceDAO dao = new WorkspaceDAO(new ConnectionFactory());
        try{
            Workspace w = dao.buscar(idWorkspace);
            return w;
        } catch (SQLException e){
            throw new WorkspaceException("Erro ao buscar a workspace",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Retorna uma lista contendo as estatísticas de produtividade da workspace selecionada pelo usuario
    public static List<Integer> listarEstatisticas(Workspace workspace) throws WorkspaceException, DAOException {
        try{
            WorkspaceDAO dao = new WorkspaceDAO(new ConnectionFactory());
            return dao.listarEstatisticas(workspace);
        }
        catch(SQLException e){
            throw new WorkspaceException("Erro ao listar estatísticas da workspace... -> " + e);
        }
    }

    //Retorna uma lista contendo a qtde de tarefas concluidas diariamente nos últimos sete dias
    public static List<Integer> gerarGraficoProdutividadeSemanal(Workspace workspace) throws WorkspaceException, DAOException {
        try{
            WorkspaceDAO dao = new WorkspaceDAO(new ConnectionFactory());
            return dao.gerarGraficoProdutividadeSemanal(workspace);
        }
        catch(SQLException e){
            throw new WorkspaceException("Erro ao gerar gráfico de produtividade semanal... -> " + e);
        }   
    }
    
    //Retorna uma lista contendo média de dias até a conclusão de tarefas por período
    public static List<Integer> gerarGraficoMediaDiasAteConclusao(Workspace workspace) throws WorkspaceException, DAOException {
        try{
            WorkspaceDAO dao = new WorkspaceDAO(new ConnectionFactory());
            return dao.gerarGraficoMediaDiasAteConclusao(workspace);
        }
        catch(SQLException e){
            throw new WorkspaceException("Erro ao gerar gráfico de média de dias até a conclusão de tarefas por período... -> " + e);
        }   
    }
    
    //Retorna uma lista contendo a qtde de tarefas concluídas e tarefas não concluídas
    public static List<Integer> gerarGraficoRelacaoTarefas(Workspace workspace) throws WorkspaceException, DAOException {
        try{
            WorkspaceDAO dao = new WorkspaceDAO(new ConnectionFactory());
            return dao.gerarGraficoRelacaoTarefas(workspace);
        }
        catch(SQLException e){
            throw new WorkspaceException("Erro ao gerar gráfico de relação entre tarefas concluídas e não concluídas... -> " + e);
        }   
    }
    
    //Retorna um mapa contendo os status da workspace e suas respectivas qtdes de tarefas não concluídas
    public static HashMap<String, Integer> gerarGraficoTarefasAbertasPorStatus(Workspace workspace) throws WorkspaceException, DAOException {
        try{
            WorkspaceDAO dao = new WorkspaceDAO(new ConnectionFactory());
            return dao.gerarGraficoTarefasAbertasPorStatus(workspace);
        }
        catch(SQLException e){
            throw new WorkspaceException("Erro ao gerar gráfico de tarefas não concluídas por status... -> " + e);
        }   
    }
    
    //Retorna uma lista contendo as estatísticas de quantidade de tarefas concluídas por período
    public static List<Integer> listarEstatisticasGerais(Usuario usuario) throws WorkspaceException, DAOException {
        try{
            WorkspaceDAO dao = new WorkspaceDAO(new ConnectionFactory());
            return dao.listarEstatisticasGerais(usuario);
        }
        catch(SQLException e){
            throw new WorkspaceException("Erro ao listar estatísticas gerais das workspaces do usuário... -> " + e);
        }
    }
}
