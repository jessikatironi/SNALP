package facade;

import beans.Categoria;
import beans.Usuario;
import dao.CategoriaDAO;
import exception.AtividadeException;
import exception.CategoriaException;
import exception.DAOException;
import java.sql.SQLException;
import java.util.List;

public class CategoriaFacade {
    
    //Retorna uma lista de todas as categorias de um usuário
    public static List<Categoria> listarCategorias(Usuario usuario) throws CategoriaException, AtividadeException, DAOException {
        try{
            CategoriaDAO dao = new CategoriaDAO();
            return dao.listarCategorias(usuario);
        }
        catch(SQLException e){
            throw new CategoriaException("Erro ao listar categorias...  -> " + e);
        }
    };
    
    //Retorna os dados de uma categoria
    public static Categoria buscarCategoria(long idCategoria) throws CategoriaException, AtividadeException, DAOException {
        try{
            CategoriaDAO dao = new CategoriaDAO();
            return dao.buscarCategoria(idCategoria);
        }
        catch(SQLException e){
            throw new CategoriaException("Erro ao buscar dados da categoria...  -> " + e);
        }
    };
    
    //Insere uma nova categoria no banco de dados
    public static void criarCategoria(Categoria categoria, Usuario usuario) throws CategoriaException, DAOException {
        try{
            CategoriaDAO dao = new CategoriaDAO();
            dao.criarCategoria(categoria, usuario);
        }
        catch(SQLException e){
            throw new CategoriaException("Erro ao criar categoria... -> " + e);
        }
    };
    
    //Atualiza os dados de uma categoria no banco de dados
    public static void atualizarCategoria(Categoria categoria) throws CategoriaException, DAOException {
        try{
            CategoriaDAO dao = new CategoriaDAO();
            dao.atualizarCategoria(categoria);
        }
        catch(SQLException  e){
            throw new CategoriaException("Erro ao atualizar categoria... -> " + e);
        }
    };
    
    //Remove uma categoria no banco de dados
    public static void removerCategoria(long idCategoria) throws CategoriaException, DAOException {
        try{
            CategoriaDAO dao = new CategoriaDAO();
            dao.removerCategoria(idCategoria);
        }
        catch(SQLException e){
            throw new CategoriaException("Erro ao remover categoria... -> " + e);
        }
    };
    
}
