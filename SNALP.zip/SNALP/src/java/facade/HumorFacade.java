package facade;

import beans.Humor;
import beans.Usuario;
import dao.HumorDAO;
import exception.DAOException;
import exception.HumorException;
import java.sql.SQLException;
import java.util.List;

public class HumorFacade {
    
    //Retorna uma lista de todos os humores de um usuário
    public static List<Humor> listarHumores(Usuario usuario) throws HumorException, DAOException {
        try{
            HumorDAO dao = new HumorDAO();
            return dao.listarHumores(usuario);
        }
        catch(SQLException e){
            throw new HumorException("Erro ao listar humores...  -> " + e);
        }
    };

    //Retorna os dados de um humor do usuário
    public static Humor buscarHumor(long idHumor) throws HumorException, DAOException {
        try{
            HumorDAO dao = new HumorDAO();
            return dao.buscarHumor(idHumor);
        }
        catch(SQLException e){
            throw new HumorException("Erro ao buscar dados do humor...  -> " + e);
        }
    };
      
    //Insere um novo humor no banco de dados
    public static void criarHumor(Humor humor, Usuario usuario) throws HumorException, DAOException {
        try{
            HumorDAO dao = new HumorDAO();
            dao.criarHumor(humor, usuario);
        }
        catch(SQLException e){
            throw new HumorException("Erro ao criar humor... -> " + e);
        }
    };
    
    //Atualiza os dados de um humor no banco de dados
    public static void atualizarHumor(Humor humor) throws HumorException, DAOException {
        try{
           HumorDAO dao = new HumorDAO();
            dao.atualizarHumor(humor);
        }
        catch(SQLException  e){
            throw new HumorException("Erro ao atualizar humor... -> " + e);
        }
    };
    
    //Remove um humor no banco do dados
    public static void removerHumor(long idHumor) throws HumorException, DAOException {
        try{
            HumorDAO dao = new HumorDAO();
            dao.removerHumor(idHumor);
        }
        catch(SQLException e){
            throw new HumorException("Erro ao remover humor... -> " + e);
        }
    };
    
    //Retorna uma lista de todas as cores do color picker de humor
    public static List<String> listarCores() throws HumorException, DAOException {
        try{
            HumorDAO dao = new HumorDAO();
            return dao.listarCores();
        }
        catch(SQLException e){
            throw new HumorException("Erro ao listar cores do color picker de humor...  -> " + e);
        }
    };

    //Retorna uma lista de todas os emojis disponíveis para seleção
    public static List<String> listarEmojis() throws HumorException, DAOException {
        try{
            HumorDAO dao = new HumorDAO();
            return dao.listarEmojis();
        }
        catch(SQLException e){
            throw new HumorException("Erro ao listar emojis para a seleção do usuário...  -> " + e);
        }
    };
    
}
