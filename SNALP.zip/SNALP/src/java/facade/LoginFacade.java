/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package facade;

import beans.Usuario;
import dao.UsuarioDAO;
import exception.DAOException;
import exception.UsuarioException;
import java.sql.SQLException;

/**
 *
 * @author eduar
 */
public class LoginFacade {
    public static Usuario realizarLogin( String email, String senha) throws SQLException, UsuarioException{
        try {
            UsuarioDAO dao = new UsuarioDAO();//Referencia Dao do usuario
            return dao.realizaLogin(email,senha);//retorna um Bean de login criado pelo função do dao
        } catch (DAOException e) {//se for alguma expection do dao
            throw new UsuarioException("Erro ao realizar o login, tente novamente.", e);
        }
        catch ( SQLException e) {//se for alguma exception do sql significa que não encontrou o usuario com a senha passada
            throw new UsuarioException("Email ou senha incorretos, tente novamente.",e);
        }
    }
}
