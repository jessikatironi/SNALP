package facade;

import beans.Subtarefa;
import dao.ConnectionFactory;
import dao.SubtarefaDAO;
import exception.DAOException;
import exception.SubtarefaException;
import java.sql.SQLException;
import java.util.List;

public class SubtarefaFacade {
    
    //Cria uma nova subtarefa
    public Subtarefa criarSubtarefa(Subtarefa s, long idTarefa) throws DAOException, SubtarefaException{
        SubtarefaDAO dao = new SubtarefaDAO(new ConnectionFactory());
        try{
            //grava nova subtarefa e seta id
            dao.inserir(s,idTarefa);
            //retorna busca pela subtarefa
            return dao.buscarSubtarefa(s.getIdSubtarefa());
        } catch (SQLException e){
            throw new SubtarefaException("Erro ao criar a subtarefa",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Atualiza uma subtarefa existente
    public void atualizarSubtarefa(Subtarefa s) throws SubtarefaException, DAOException{
        SubtarefaDAO dao = new SubtarefaDAO(new ConnectionFactory());
        try{
            dao.atualizar(s);
        } catch (SQLException e){
            throw new SubtarefaException("Erro ao atualizar a subtarefa",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Remove uma subtarefa
    public void removerSubtarefa(long idSubtarefa) throws DAOException, SubtarefaException{
        SubtarefaDAO dao = new SubtarefaDAO(new ConnectionFactory());
        try{
            dao.remover(idSubtarefa);
        } catch (SQLException e){
            throw new SubtarefaException("Erro ao remover a subtarefa",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Lista todas as tarefas de uma workspace
    public List<Subtarefa> listarSubtarefas(long idTarefa) throws SubtarefaException, DAOException{
        SubtarefaDAO dao = new SubtarefaDAO(new ConnectionFactory());
        try{
            List<Subtarefa> subtarefas = dao.listar(idTarefa);
            return subtarefas;
        } catch (SQLException e){
            throw new SubtarefaException("Erro ao buscar lista de subtarefas",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Muda situação da subtarefa para concluído ou não
    public void completarSubtarefa(long idSubtarefa, boolean estado) throws SubtarefaException, DAOException{
        SubtarefaDAO dao = new SubtarefaDAO(new ConnectionFactory());
        try{
            dao.completarSubtarefa(idSubtarefa, estado);
        } catch (SQLException e){
            throw new SubtarefaException("Erro ao atualizar estado da subtarefa",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
}
