package facade;

import beans.Status;
import dao.ConnectionFactory;
import dao.StatusDAO;
import exception.DAOException;
import exception.StatusException;
import java.sql.SQLException;
import java.util.List;

public class StatusFacade {
    
    //Cria um novo status
    public void criarStatus(Status s, long idWorkspace) throws DAOException, StatusException{
        StatusDAO dao = new StatusDAO(new ConnectionFactory());
        try{
            //s.setOrdem(dao.getOrdem(2));
            dao.inserir(s,idWorkspace);
        } catch (SQLException e){
            throw new StatusException("Erro ao criar o status",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Atualiza um status existente
    public void atualizarStatus(Status s) throws StatusException, DAOException{
        StatusDAO dao = new StatusDAO(new ConnectionFactory());
        try{
            dao.atualizar(s);
        } catch (SQLException e){
            throw new StatusException("Erro ao atualizar o status",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Atualiza ordem do status
    public void atualizarOrdem (long idStatus, int oldOrdem, int newOrdem) throws DAOException, StatusException{
      StatusDAO dao = new StatusDAO(new ConnectionFactory());
        try{
            //Se status subiu na lista
            if (newOrdem < oldOrdem){
                dao.fixOrderUp(idStatus, oldOrdem, newOrdem);
                dao.updateOrdem(idStatus, newOrdem);
            //Se status desceu na lista
            } else if (newOrdem > oldOrdem){
                dao.fixOrderDown(idStatus, oldOrdem, newOrdem);
                dao.updateOrdem(idStatus, newOrdem);
            }
        } catch (SQLException e){
            throw new StatusException("Erro ao atualizar a ordem do status",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }  
    }
    
    //Remove um status
    public void removerStatus(long idStatus, int ordem, long idWorkspace) throws DAOException, StatusException{
        StatusDAO dao = new StatusDAO(new ConnectionFactory());
        try{
            dao.remover(idStatus);
            dao.atualizarOrdemDelete(ordem, idWorkspace);
        } catch (SQLException e){
            throw new StatusException("Erro ao remover o status",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Lista todos os status de uma workspace
    public List<Status> listarStatus(long idWorkspace) throws StatusException, DAOException{
        StatusDAO dao = new StatusDAO(new ConnectionFactory());
        try{
            List<Status> status = dao.listar(idWorkspace);
            return status;
        } catch (SQLException e){
            throw new StatusException("Erro ao buscar lista de status",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Lista todos os status disponiveis da workspace
    public List<Status> listarDisponiveis(long idWorkspace, long idStatus) throws StatusException, DAOException{
        StatusDAO dao = new StatusDAO(new ConnectionFactory());
        try{
            List<Status> status = dao.listarDisponiveis(idWorkspace, idStatus);
            return status;
        } catch (SQLException e){
            throw new StatusException("Erro ao buscar lista de status disponiveis",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Busca um statsus e retorna seus dados
    public Status buscarStatus(long idStatus) throws StatusException, DAOException {
        StatusDAO dao = new StatusDAO(new ConnectionFactory());
        try{
            return dao.buscar(idStatus);
        } catch (SQLException e){
            throw new StatusException("Erro ao buscar o status",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Busca status de ordem 1 em uma workspace - para criação de tarefas na visualização tabela
    public Status buscarOrdem(long idWorkspace) throws StatusException, DAOException {
        StatusDAO dao = new StatusDAO(new ConnectionFactory());
        try{
            return dao.buscarOrdem(idWorkspace);
        } catch (SQLException e){
            throw new StatusException("Erro ao buscar o status",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }     
    }
    
    //Retorna uma lista de todas as cores do color picker para status
    public static List<String> listarCores() throws StatusException, DAOException {
        try{
            StatusDAO dao = new StatusDAO(new ConnectionFactory());
            return dao.listarCores();
        }
        catch(SQLException e){
            throw new StatusException("Erro ao listar cores do color picker para status...  -> " + e);
        }
    };

}
