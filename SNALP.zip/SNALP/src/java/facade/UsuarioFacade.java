package facade;

import beans.Usuario;
import dao.UsuarioDAO;
import exception.DAOException;
import exception.UsuarioException;
import java.sql.SQLException;

public class UsuarioFacade {
    
    public static void criarUsuario(Usuario usuario) throws UsuarioException {
        try {
            UsuarioDAO dao = new UsuarioDAO();
            dao.criarUsuario(usuario);
        } catch (DAOException | SQLException e) {
            throw new UsuarioException(e.getMessage());
        }
    }
    
    public static void atualizarUsuario(Usuario usuario) throws UsuarioException, SQLException {
        try {
            UsuarioDAO dao = new UsuarioDAO();
            dao.atualizarUsuario(usuario);
        }
        catch (DAOException e) {//se ocorrer algum erro ao atualizar o usuario
            throw new UsuarioException("Erro ao atualizar usuário, tente novamente.", e);
        }
        catch (SQLException e) {//se o email indicado já estiver
            throw new SQLException(e.getMessage());
        }
    }
    
    public static void removerUsuario(long idUsuario) throws UsuarioException {
        try {
            UsuarioDAO dao = new UsuarioDAO();
            dao.deletarUsuario(idUsuario);
        } catch (DAOException | SQLException e) {
            throw new UsuarioException("Erro ao deletar usuário, tente novamente.", e);
        }
    }
    
    public static Usuario buscarUsuario(long idUsuario) throws UsuarioException {
        try {
            UsuarioDAO dao = new UsuarioDAO();
            return (dao.buscarUsuario(idUsuario));
        } catch (DAOException | SQLException e) {
            throw new UsuarioException("Erro ao buscar usuário, tente novamente.", e);
        }
    }
    
    public static void atualizarSenha(Usuario usuario, String senha) throws UsuarioException, DAOException {
        try {
            UsuarioDAO dao = new UsuarioDAO();
            dao.atualizarSenha(usuario,senha);
        } catch (DAOException e) {
            throw new DAOException("Senha atual incorreta, tente novamente.", e);
        } catch ( SQLException e) {
            throw new UsuarioException("Erro ao confirmar a senha atual, tente novamente.", e);
        }
    }
    
}
