package facade;

import beans.Pomodoro;
import beans.Usuario;
import dao.PomodoroDAO;
import exception.DAOException;
import exception.PomodoroException;
import java.sql.SQLException;
import java.util.List;

public class PomodoroFacade {
    public static void criarPomodoro( Pomodoro pomodoro, Usuario usuario) throws DAOException, SQLException, PomodoroException  {
        try {
            PomodoroDAO dao = new PomodoroDAO();
            dao.inserirPomodoro(pomodoro,usuario);
        } catch (DAOException | SQLException e) {
            throw new PomodoroException("Erro ao adicionar relógio pomodoro, tente novamente.", e);
        }
    }
    
    public static void atualizarPomodoro(Pomodoro pomodoro) throws DAOException, SQLException, PomodoroException  {
        try {
            PomodoroDAO dao = new PomodoroDAO();
            dao.atualizarPomodoro(pomodoro);
        } catch (DAOException | SQLException e) {
            throw new PomodoroException("Erro ao atualizar o relógio, tente novamente."+e);
        }
    }
    
    public static void removerPomodoro(long id) throws DAOException, SQLException, PomodoroException  {
        try {
            PomodoroDAO dao = new PomodoroDAO();
            dao.deletaPomodoro(id);
        } catch (DAOException | SQLException e) {
            throw new PomodoroException("Erro ao deletar o relógio, tente novamente."+e);
        }
    }
    
    public static Pomodoro buscarPomodoro( long id) throws DAOException, SQLException, PomodoroException  {
        try {
            PomodoroDAO dao = new PomodoroDAO();
            return dao.buscarPomodoro(id);
        } catch (DAOException | SQLException e) {
            throw new PomodoroException("Erro ao buscar o relógio, tente novamente.", e);
        }
    }
    
    public static List<Pomodoro> listarPomodoro( Usuario usuario) throws DAOException, SQLException, PomodoroException  {
        try {
            PomodoroDAO dao = new PomodoroDAO();
            return dao.listarPomodoro(usuario);
        } catch (DAOException | SQLException e) {
            throw new PomodoroException("Erro ao listar os relógios, tente novamente.", e);
        }
    }
    
    public static void registrarLogPomodoro(Pomodoro pomodoro, Usuario usuario) throws PomodoroException{
         try {
            PomodoroDAO dao = new PomodoroDAO();
            dao.registarLogPomodoro(pomodoro,usuario);
        } catch (DAOException | SQLException e) {
            throw new PomodoroException("Erro ao cadastrar o histórico do relógio pomodoro, tente novamente.", e);
        }
    }
    
    public static List<Pomodoro> listarLogPomodoro( Usuario usuario) throws DAOException, SQLException, PomodoroException  {
        try {
            PomodoroDAO dao = new PomodoroDAO();
            return dao.listarLogPomodoro(usuario);
        } catch (DAOException | SQLException e) {
            throw new PomodoroException("Erro ao listar os relógios, tente novamente.", e);
        }
    }
    
    public static Pomodoro buscarUltimoLogPomodoro( Usuario usuario) throws DAOException, SQLException, PomodoroException  {
        try {
            PomodoroDAO dao = new PomodoroDAO();
            return dao.buscarUltimoLogPomodoro(usuario);
        } catch (DAOException | SQLException e) {
            throw new PomodoroException("Erro ao listar último relógio, tente novamente.", e);
        }
    }
    
    //Retorna uma lista contendo as estatísticas de quantidade de relógios pomodoro executados por período
    public static List<Integer> listarEstatisticasGerais(Usuario usuario) throws PomodoroException, DAOException {
        try{
            PomodoroDAO dao = new PomodoroDAO();
            return dao.listarEstatisticasGerais(usuario);
        }
        catch(SQLException e){
            throw new PomodoroException("Erro ao listar estatísticas gerais dos relógios Pomodoro do usuário... -> " + e);
        }
    }
}
