package facade;

import beans.Etiqueta;
import dao.ConnectionFactory;
import dao.EtiquetaDAO;
import exception.DAOException;
import exception.EtiquetaException;
import java.sql.SQLException;
import java.util.List;

public class EtiquetaFacade {
    
    //Cria uma nova etiqueta
    public void criarEtiqueta(Etiqueta e, long idWorkspace) throws DAOException, EtiquetaException{
        EtiquetaDAO dao = new EtiquetaDAO(new ConnectionFactory());
        try{
            dao.inserir(e,idWorkspace);
        } catch (SQLException err){
            throw new EtiquetaException("Erro ao criar a etiqueta",err);
        } catch (DAOException err){
            throw new DAOException("Erro conectando ao Banco de Dados",err);
        }
    }
    
    //Atualiza uma etiqueta existente
    public void atualizarEtiqueta(Etiqueta e) throws EtiquetaException, DAOException{
        EtiquetaDAO dao = new EtiquetaDAO(new ConnectionFactory());
        try{
            dao.atualizar(e);
        } catch (SQLException err){
            throw new EtiquetaException("Erro ao atualizar a etiqueta",err);
        } catch (DAOException err){
            throw new DAOException("Erro conectando ao Banco de Dados",err);
        }
    }
    
    //Remove uma etiqueta
    public void removerEtiqueta(long idEtiqueta) throws DAOException, EtiquetaException{
        EtiquetaDAO dao = new EtiquetaDAO(new ConnectionFactory());
        try{
            dao.remover(idEtiqueta);
        } catch (SQLException e){
            throw new EtiquetaException("Erro ao remover a etiqueta",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Lista todas as etiquetas de uma workspace
    public List<Etiqueta> listarEtiquetas(long idWorkspace) throws EtiquetaException, DAOException{
        EtiquetaDAO dao = new EtiquetaDAO(new ConnectionFactory());
        try{
            List<Etiqueta> etiquetas = dao.listar(idWorkspace);
            return etiquetas;
        } catch (SQLException e){
            throw new EtiquetaException("Erro ao buscar lista de etiquetas",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Busca uma etiqueta e retorna seus dados
    public Etiqueta buscarEtiqueta(long idEtiqueta) throws EtiquetaException, DAOException {
        EtiquetaDAO dao = new EtiquetaDAO(new ConnectionFactory());
        try{
            Etiqueta e = dao.buscar(idEtiqueta);
            return e;
        } catch (SQLException e){
            throw new EtiquetaException("Erro ao buscar a etiqueta",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Retorna lista de etiquetas de uma tarefa
    public List<Etiqueta> etiquetasTarefa(long idTarefa) throws EtiquetaException, DAOException {
        EtiquetaDAO dao = new EtiquetaDAO(new ConnectionFactory());
        try {
            List<Etiqueta> etiquetas = dao.etiquetasTarefa(idTarefa);
            return etiquetas;
        } catch (SQLException e){
            throw new EtiquetaException("Erro ao buscar as etiquetas da tarefa",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Retorna lista de etiquetas que ainda não foram inseridas em uma tarefa
    public List<Etiqueta> etiquetasDisponiveis(long idTarefa, long idWorkspace) throws EtiquetaException, DAOException {
        EtiquetaDAO dao = new EtiquetaDAO(new ConnectionFactory());
        try {
            List<Etiqueta> etiquetas = dao.etiquetasDisponiveis(idTarefa, idWorkspace);
            return etiquetas;
        } catch (SQLException e){
            throw new EtiquetaException("Erro ao buscar as etiquetas disponíveis",e);
        } catch (DAOException e){
            throw new DAOException("Erro conectando ao Banco de Dados",e);
        }
    }
    
    //Atribui uma etiqueta a uma tarefa
    public void atribuirEtiqueta(long idTarefa, long idEtiqueta) throws DAOException, EtiquetaException{
        EtiquetaDAO dao = new EtiquetaDAO(new ConnectionFactory());
        try{
            dao.atribuirEtiqueta(idTarefa,idEtiqueta);
        } catch (SQLException err){
            throw new EtiquetaException("Erro ao atribuir a etiqueta",err);
        } catch (DAOException err){
            throw new DAOException("Erro conectando ao Banco de Dados",err);
        }
    }
    
    //Remove uma etiqueta a uma tarefa
    public void retirarEtiqueta(long idTarefa, long idEtiqueta) throws DAOException, EtiquetaException{
        EtiquetaDAO dao = new EtiquetaDAO(new ConnectionFactory());
        try{
            dao.removerEtiqueta(idTarefa,idEtiqueta);
        } catch (SQLException err){
            throw new EtiquetaException("Erro ao remover a etiqueta",err);
        } catch (DAOException err){
            throw new DAOException("Erro conectando ao Banco de Dados",err);
        }
    }
    
    //Retorna uma lista de todas as cores do color picker para etiqueta
    public static List<String> listarCores() throws EtiquetaException, DAOException {
        try{
            EtiquetaDAO dao = new EtiquetaDAO(new ConnectionFactory());
            return dao.listarCores();
        }
        catch(SQLException e){
            throw new EtiquetaException("Erro ao listar cores do color picker para etiqueta...  -> " + e);
        }
    };
}
