package facade;

import beans.Atividade;
import beans.Categoria;
import dao.AtividadeDAO;
import exception.AtividadeException;
import exception.CategoriaException;
import exception.DAOException;
import java.sql.SQLException;
import java.util.List;

public class AtividadeFacade {
    
    //Retorna uma lista de todas as atividades de uma categorias
    public static List<Atividade> listarAtividades(Categoria categoria) throws AtividadeException, DAOException {
        try{
            AtividadeDAO dao = new AtividadeDAO();
            return dao.listarAtividades(categoria);
        }
        catch(SQLException e){
            throw new AtividadeException("Erro ao listar atividades...  -> " + e);
        }
    };
    
    //Retorna os dados de uma atividade do usuário
    public static Atividade buscarAtividade(long idAtividade) throws AtividadeException, CategoriaException, DAOException {
        try{
            AtividadeDAO dao = new AtividadeDAO();
            return dao.buscarAtividade(idAtividade);
        }
        catch(SQLException e){
            throw new AtividadeException("Erro ao buscar dados da atividade...  -> " + e);
        }
    };
    
    //Insere uma nova atividade no banco de dados
    public static void criarAtividade(Atividade atividade) throws AtividadeException, DAOException {
        try{
            AtividadeDAO dao = new AtividadeDAO();
            dao.criarAtividade(atividade);
        }
        catch(SQLException e){
            throw new AtividadeException("Erro ao criar atividade... -> " + e);
        }
    };
    
    //Atualiza os dados de uma atividade no banco de dados
    public static void atualizarAtividade(Atividade atividade) throws AtividadeException, DAOException {
        try{
            AtividadeDAO dao = new AtividadeDAO();
            dao.atualizarAtividade(atividade);
        }
        catch(SQLException  e){
            throw new AtividadeException("Erro ao atualizar atividade... -> " + e);
        }
    };
    
    //Remove uma atividade no banco de dados
    public static void removerAtividade(long idAtividade) throws AtividadeException, DAOException {
        try{
            AtividadeDAO dao = new AtividadeDAO();
            dao.removerAtividade(idAtividade);
        }
        catch(SQLException e){
            throw new AtividadeException("Erro ao remover atividade... -> " + e);
        }
    };
    
}
