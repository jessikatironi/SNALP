package servlets;

import beans.Humor;
import beans.Usuario;
import com.google.gson.Gson;
import exception.DAOException;
import exception.HumorException;
import facade.HumorFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "HumorServlet", urlPatterns = {"/HumorServlet"})
public class HumorServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("logado");
        
        String action = (String) request.getParameter("action");
        
        if (session.getAttribute("logado") == null) {
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
            request.setAttribute("mensagem", "Realize o seu login para acessar o SNALP!");
            rd.forward(request, response);
            
        } else {
            if (action == null){
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                request.setAttribute("mensagem", "Ação não encontrada, tente novamente!");
                rd.forward(request, response);
                
            } else if (action.equals("show")) {
                // buscar dados de um humor: aplicação nos gráficos
                
                // resgata o id do humor, passado por parâmetro na requisição
                String idHumor = request.getParameter("idHumor");
                if (idHumor == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                try {
                    Gson gson = new Gson();
                    response.setContentType("application/json");
                    PrintWriter out = response.getWriter();
                    out.println(gson.toJson(HumorFacade.buscarHumor(Long.parseLong(idHumor))));
                
                } catch (HumorException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if (action.equals("list")) {
                // listar humores do usuário: aplicação nos gráficos
                
                try {
                    Gson gson = new Gson();
                    response.setContentType("application/json");
                    PrintWriter out = response.getWriter();
                    out.println(gson.toJson(HumorFacade.listarHumores(usuario)));
                
                } catch (HumorException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            
            } else if (action.equals("formNew")) {
                try {
                    
                    // lista emojis disponíveis para a seleção do usuário
                    List<String> listaEmojis = HumorFacade.listarEmojis();
                    // envia a lista de emojis na resposta da requisição
                    request.setAttribute("listaEmojis", listaEmojis);
                    
                    // lista cores para o color picker do humor
                    List<String> listaCores = HumorFacade.listarCores();
                    // envia a lista de cores na resposta da requisição
                    request.setAttribute("listaCores", listaCores);

                    // redireciona o usuário para o formulário de inserção de novo humor
                    RequestDispatcher rd = request.getRequestDispatcher("/humorForm.jsp");
                    rd.forward(request, response);
                } catch (HumorException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if (action.equals("new")) {
                // inserir novo humor
                try {
                    // instancia novo humor
                    Humor humor = new Humor();
                    // reagata os dados do novo humor, passados pelos campos do formulário
                    humor.setDescricaoHumor(request.getParameter("descricaoHumor"));
                    humor.setEmojiHumor(request.getParameter("emojiHumor"));
                    humor.setCorHumor(request.getParameter("corHumor"));
                    // chama o método da facade para criar o novo humor
                    HumorFacade.criarHumor(humor, usuario);
                    // redireciona o usuário para a página de configuração do mood tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/MoodTrackerServlet?action=listConfig");
                    rd.forward(request, response);
                } catch (HumorException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if (action.equals("formUpdate")) {
                // formulário para alterar humor

                // resgata o id do humor, passado por parâmetro na requisição
                String idHumor = request.getParameter("idHumor");
                if (idHumor == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

                try {
                    // resgata os dados do humor, passando idHumor como parâmetro
                    Humor humor = HumorFacade.buscarHumor(Long.parseLong(idHumor));

                    // envia o objeto humor na resposta da requisição
                    request.setAttribute("humor", humor);
                    // define o tipo do formulario como update
                    request.setAttribute("type", "update");
                    
                    // lista emojis disponíveis para a seleção do usuário
                    List<String> listaEmojis = HumorFacade.listarEmojis();
                    // envia a lista de emojis na resposta da requisição
                    request.setAttribute("listaEmojis", listaEmojis);
                    
                    // lista cores para o color picker do humor
                    List<String> listaCores = HumorFacade.listarCores();
                    // envia a lista de cores na resposta da requisição
                    request.setAttribute("listaCores", listaCores);

                    // redireciona o usuário para o formulário de alteração de humor
                    RequestDispatcher rd = request.getRequestDispatcher("/humorForm.jsp");
                    rd.forward(request, response);
                    
                } catch(HumorException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if (action.equals("update")) {
                // alterar humor

                // resgata o id do humor, passado por parâmetro na requisição
                String idHumor = request.getParameter("idHumor");
                if (idHumor == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                try {
                    // instancia novo humor
                    Humor humor = new Humor();

                    // reagata os novos dados do humor, passados pelos campos do formulário
                    humor.setIdHumor(Long.parseLong(idHumor));
                    humor.setDescricaoHumor(request.getParameter("descricaoHumor"));
                    humor.setEmojiHumor(request.getParameter("emojiHumor"));
                    humor.setCorHumor(request.getParameter("corHumor"));

                    // chama o método da facade para atualiza o humor
                    HumorFacade.atualizarHumor(humor);

                    // redireciona o usuário para a página de configuração do mood tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/MoodTrackerServlet?action=listConfig");
                    rd.forward(request, response);
                } catch (HumorException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if (action.equals("delete")) {
                // remover humor == inativar humor

                // resgata o id do humor, passado por parâmetro na requisição
                String idHumor = request.getParameter("idHumor");
                if (idHumor == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                try {
                    HumorFacade.removerHumor(Long.parseLong(idHumor));
                    RequestDispatcher rd = request.getRequestDispatcher("/MoodTrackerServlet?action=listConfig");
                    rd.forward(request, response);
                } catch(HumorException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else {
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                request.setAttribute("mensagem", "Ação não encontrada, tente novamente!");
                rd.forward(request, response);
            }
            
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
