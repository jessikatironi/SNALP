package servlets;

import beans.Categoria;
import beans.Usuario;
import exception.AtividadeException;
import exception.CategoriaException;
import exception.DAOException;
import facade.CategoriaFacade;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "CategoriaServlet", urlPatterns = {"/CategoriaServlet"})
public class CategoriaServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("logado");
        
        String action = (String) request.getParameter("action");
        
        if (session.getAttribute("logado") == null) {
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
            request.setAttribute("mensagem", "Realize o seu login para acessar o SNALP!");
            rd.forward(request, response);
            
        } else {
        
            if (action == null){
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                request.setAttribute("mensagem", "Ação não encontrada, tente novamente!");
                rd.forward(request, response);
                
            } else if(action.equals("formNew")) {
                // redireciona o usuário para o formulário de inserção de nova categoria de atividades
                RequestDispatcher rd = request.getRequestDispatcher("/categoriaForm.jsp");
                rd.forward(request, response);

            } else if (action.equals("new")) {
                // inserir nova categoria de atividades
                try {
                    // instancia nova categoria
                    Categoria categoria = new Categoria();
                    // reagata os dados da nova categoria, passados pelos campos do formulário
                    categoria.setTituloCategoria(request.getParameter("tituloCategoria"));
                    // chama o método da facade para criar a nova categoria
                    CategoriaFacade.criarCategoria(categoria, usuario);
                    // redireciona o usuário para a página de configuração do mood tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/MoodTrackerServlet?action=listConfig");
                    rd.forward(request, response);
                } catch (CategoriaException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if (action.equals("formUpdate")) {
                // formulário para alterar categoria de atividades

                // resgata o id da categoria, passado por parâmetro na requisição
                String idCategoria = request.getParameter("idCategoria");
                if (idCategoria == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                try {
                    // resgata os dados da categoria, passando idCategoria como parâmetro
                    Categoria categoria = CategoriaFacade.buscarCategoria(Long.parseLong(idCategoria));

                    // envia o objeto categoria na resposta da requisição
                    request.setAttribute("categoria", categoria);
                    // define o tipo do formulario como update
                    request.setAttribute("type", "update");

                    // redireciona o usuário para o formulário de alteração de humor
                    RequestDispatcher rd = request.getRequestDispatcher("/categoriaForm.jsp");
                    rd.forward(request, response);
                } catch(CategoriaException | AtividadeException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if (action.equals("update")) {
                // alterar categoria de atividades

                // resgata o id da categoria, passado por parâmetro na requisição
                String idCategoria = request.getParameter("idCategoria");
                if (idCategoria == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                try {
                    // instancia nova categoria
                    Categoria categoria = new Categoria();

                    // reagata os novos dados da categoria, passados pelos campos do formulário
                    categoria.setIdCategoria(Long.parseLong(idCategoria));
                    categoria.setTituloCategoria(request.getParameter("tituloCategoria"));

                    // chama o método da facade para atualiza a categoria
                    CategoriaFacade.atualizarCategoria(categoria);

                    // redireciona o usuário para a página de configuração do mood tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/MoodTrackerServlet?action=listConfig");
                    rd.forward(request, response);
                } catch (CategoriaException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if (action.equals("delete")) {
                // remover categoria de atividades == inativar categoria de atividades
                String idCategoria = request.getParameter("idCategoria");
                if (idCategoria == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                try {
                    CategoriaFacade.removerCategoria(Long.parseLong(idCategoria));
                    RequestDispatcher rd = request.getRequestDispatcher("/MoodTrackerServlet?action=listConfig");
                    rd.forward(request, response);
                } catch(CategoriaException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else {
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                request.setAttribute("mensagem", "Ação não encontrada, tente novamente!");
                rd.forward(request, response);
            }
            
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
