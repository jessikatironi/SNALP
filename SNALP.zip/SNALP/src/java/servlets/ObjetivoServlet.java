package servlets;

import beans.Objetivo;
import beans.Usuario;
import com.google.gson.Gson;
import exception.DAOException;
import exception.ObjetivoException;
import facade.ObjetivoFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "ObjetivoServlet", urlPatterns = {"/ObjetivoServlet"})
public class ObjetivoServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("logado");
        
        String action = (String) request.getParameter("action");
        
        if (session.getAttribute("logado") == null) {
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
            request.setAttribute("mensagem", "Realize o seu login para acessar o SNALP!");
            rd.forward(request, response);
            
        } else {
        
            if (action == null){
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                request.setAttribute("mensagem", "Ação não encontrada, tente novamente!");
                rd.forward(request, response);
                
            } else if(action.equals("checkObjective")) {
                // verifica se usuário tem objetivo ativo: cada usuário só pode ter no máximo um objetivo ativo por vez
                try {
                    // chama método da facade para verificar se o usuário tem objetivo ativo
                    boolean temObjetivo = ObjetivoFacade.verificarObjetivo(usuario);
                    
                    Gson gson = new Gson();
                    response.setContentType("application/json");
                    PrintWriter out = response.getWriter();
                    out.println(gson.toJson(temObjetivo));
                
                }  catch (ObjetivoException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            
            } else if(action.equals("formNew")) {
                // formulário para inserir novo objetivo

                // resgata a data atual
                LocalDate dataAtual = LocalDate.now();
                // formata a data atual para exibir no formulário de inserção
                Locale local = new Locale("pt", "BR");
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd / MM / yyyy", local);
                String dataFormatada = dataAtual.format(formatter);
                // envia a data atual formatada na resposta da requisição
                request.setAttribute("dataFormatada", dataFormatada);
                        
                // redireciona o usuário para o formulário de inserção de novo objetivo
                RequestDispatcher rd = request.getRequestDispatcher("/objetivoForm.jsp");
                rd.forward(request, response);

            } else if(action.equals("new")) {
                // inserir novo objetivo
                try {
                    // instancia novo objetivo
                    Objetivo objetivo = new Objetivo();

                    // resgata título e descição do novo objetivo, passados por parâmetro e seta os atributos título e descrição no objetivo
                    objetivo.setTituloObjetivo(request.getParameter("tituloObjetivo"));
                    objetivo.setDescricaoObjetivo(request.getParameter("descricaoObjetivo"));

                    // resgata data final do novo objetivo, passado por parâmetro
                    String dataFimObjetivo = request.getParameter("dataFimObjetivo");
                    // verifica se o usuário marcou ou não uma data final e seta o atributo data final no objetivo
                    if(dataFimObjetivo.equals("")) {
                        // se o usuário não tiver marcado uma data, seta o atributo como nulo
                        objetivo.setDataFimObjetivo(null);
                    } else {
                        objetivo.setDataFimObjetivo(LocalDate.parse(dataFimObjetivo));
                    }

                    // chama o método da facade para criar o novo objetivo
                    ObjetivoFacade.criarObjetivo(objetivo, usuario);

                    // redireciona o usuário para a página de configuração do mood tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/MoodTrackerServlet?action=listConfig");
                    rd.forward(request, response);

                } catch(ObjetivoException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if(action.equals("formUpdate")) {
                // formulário para alterar objetivo
                try {
                    // resgata os dados do objetivo, passando idUsuario como parâmetro
                    Objetivo objetivo = ObjetivoFacade.buscarObjetivo(usuario);
                    
                    // formata a data de criação do objetivo para exibir no formulário de alteração
                    Locale local = new Locale("pt", "BR");
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd / MM / yyyy", local);
                    String dataFormatada = objetivo.getDataCriacaoObjetivo().format(formatter);
                    // envia a data do registro formatada na resposta da requisição
                    request.setAttribute("dataFormatada", dataFormatada);

                    // envia o objeto objetivo na resposta da requisição
                    request.setAttribute("objetivo", objetivo);
                    // define o tipo do formulario como update
                    request.setAttribute("type", "update");

                    // redireciona o usuário para o formulário de alteração de humor
                    RequestDispatcher rd = request.getRequestDispatcher("/objetivoForm.jsp");
                    rd.forward(request, response);
                } catch(ObjetivoException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if(action.equals("update")) {
                // alterar objetivo

                // resgata o id do objetivo, passado por parâmetro na requisição
                String idObjetivo = request.getParameter("idObjetivo");
                if (idObjetivo == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                
                try {
                    // instancia novo objetivo
                    Objetivo objetivo = new Objetivo();

                    // seta o atributo id no objetivo
                    objetivo.setIdObjetivo(Long.parseLong(idObjetivo));

                    // resgata os novos título e descição do objetivo, passados por parâmetro e seta os atributos título e descrição no objetivo
                    objetivo.setTituloObjetivo(request.getParameter("tituloObjetivo"));
                    objetivo.setDescricaoObjetivo(request.getParameter("descricaoObjetivo"));

                    // resgata a nova data final do objetivo, passado por parâmetro
                    String dataFimObjetivo = request.getParameter("dataFimObjetivo");
                    // verifica se o usuário marcou ou não uma data final e seta o atributo data final no objetivo
                    if(dataFimObjetivo.equals("")) {
                        // se o usuário não tiver marcado uma data, seta o atributo como nulo
                        objetivo.setDataFimObjetivo(null);
                    } else {
                        objetivo.setDataFimObjetivo(LocalDate.parse(dataFimObjetivo));
                    }

                    // chama o método da facade para atualizar o objetivo
                    ObjetivoFacade.atualizarObjetivo(objetivo);

                    // redireciona o usuário para a página de configuração do mood tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/MoodTrackerServlet?action=listConfig");
                    rd.forward(request, response);
                    
                } catch (ObjetivoException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if(action.equals("delete")) {
                // remover objetivo == inativar objetivo

                // resgata o id do objetivo, passado por parâmetro na requisição
                String idObjetivo = request.getParameter("idObjetivo");
                if (idObjetivo == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                try {
                    ObjetivoFacade.removerObjetivo(Long.parseLong(idObjetivo));
                    RequestDispatcher rd = request.getRequestDispatcher("/MoodTrackerServlet?action=listConfig");
                    rd.forward(request, response);
                } catch(ObjetivoException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else {
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                request.setAttribute("mensagem", "Ação não encontrada, tente novamente!");
                rd.forward(request, response);
            } 
            
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
