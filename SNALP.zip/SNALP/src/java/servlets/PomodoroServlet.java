/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import beans.Pomodoro;
import beans.Usuario;
import exception.DAOException;
import exception.PomodoroException;
import facade.PomodoroFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDate;
import static java.time.LocalDate.now;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author eduar
 */
@WebServlet(name = "PomodoroServlet", urlPatterns = {"/PomodoroServlet"})
public class PomodoroServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {

            RequestDispatcher rd;
            String action = request.getParameter("action");//recebe indicador de qual ação seguirs
            HttpSession session = request.getSession();//Cria uma sessão

            if (action == null) {
                rd = request.getRequestDispatcher("/index.jsp");
                request.setAttribute("mensagem", "Ação não encontrada, tente novamente");
                rd.forward(request, response);
                //Se não encontrar a ação, abre a página de login
            }

            switch (action) {
                case "new": {
                    //recebe dados dos parâmetros
                    String titulo = (String) request.getParameter("titulo");
                    int tempo = Integer.parseInt(request.getParameter("tempo"));
                    int pausa = Integer.parseInt(request.getParameter("pausa"));
                    int serie = Integer.parseInt(request.getParameter("serie"));

                    Pomodoro pomodoro = new Pomodoro(titulo, tempo, pausa, serie);//criando objeto

                    //Seleciona id do usuario pelo objeto Login da sessão
                    session = request.getSession();//Cria uma sessão
                    if (session.getAttribute("logado") == null) {
                        throw new PomodoroException();
                    }
                    Usuario login = (Usuario) session.getAttribute("logado"); //recebe o bean
                    PomodoroFacade.criarPomodoro(pomodoro, login);
                    request.setAttribute("atualizar", false);//Indica var auxiliar para executar ação correta
                    rd = request.getRequestDispatcher("PomodoroServlet?action=list");//indica página de redirecionamento
                    rd.forward(request, response);//redireciona
                    break;
                }
                case "list"://Caso vá lista ou carregar o formulário que edição
                case "updateForm":
                    try {
                    Usuario login = (Usuario) session.getAttribute("logado"); //recebe o bean
                    List<Pomodoro> lista = new ArrayList<>();
                    List<Pomodoro> listaLog = new ArrayList<>();
                    lista = PomodoroFacade.listarPomodoro(login);//seleciona lista de relógios do usuário
                    listaLog = PomodoroFacade.listarLogPomodoro(login);//seleciona lista de relógios do usuário
                    rd = request.getRequestDispatcher("/pomodoro.jsp");//indica página de redirecionamento
                    request.setAttribute("pomodoroLista", lista);//Indica a lista de relógios como atributo 
                    request.setAttribute("pomodoroLog", listaLog);//Indica a lista de relógios como atributo 

                    if ("updateForm".equals(action)) {//Se for para a ediçãp
                        long id = Long.parseLong(request.getParameter("id"));//recebe id do relógio
                        Pomodoro pomodoro = PomodoroFacade.buscarPomodoro(id);//Busca os dados deste relógio
                        request.setAttribute("pomodoro", pomodoro);//Coloco o relógio como atributo
                        request.setAttribute("atualizar", "sim");//Indica var auxiliar para a ação
                    } else {
                        request.setAttribute("atualizar", "n");//Indica var auxiliar para executar ação correta
                    }
                    rd.forward(request, response);//redireciona
                } catch (DAOException | SQLException | PomodoroException ex) {
                    rd = request.getRequestDispatcher("/index.jsp");//indica página de redirecionamento
                    request.setAttribute("mensagem", ex.getMessage());//Coloco o relógio como atributo
                    rd.forward(request, response);//redireciona
                }
                break;
                case "update": {
                    long id = Long.parseLong(request.getParameter("idPomodoro"));
                    String titulo = (String) request.getParameter("titulo");
                    int tempo = Integer.parseInt(request.getParameter("tempo"));
                    int pausa = Integer.parseInt(request.getParameter("pausa"));
                    int serie = Integer.parseInt(request.getParameter("serie"));

                    Pomodoro pomodoro = new Pomodoro(id, titulo, tempo, pausa, serie);//criando objeto
                    PomodoroFacade.atualizarPomodoro(pomodoro);
                    rd = request.getRequestDispatcher("PomodoroServlet?action=list");
                    request.setAttribute("mensagem", "Relogio atualizado com sucesso!");
                    rd.forward(request, response);
                    break;
                }
                case "delete": {
                    long id = Long.parseLong(request.getParameter("id"));//recebe id do relógio
                    PomodoroFacade.removerPomodoro(id);
                    rd = request.getRequestDispatcher("PomodoroServlet?action=list");
                    request.setAttribute("mensagem", "Relogio excluído com sucesso!");
                    rd.forward(request, response);
                    break;
                }
                case "registrarLog": {

                    Usuario login = (Usuario) session.getAttribute("logado"); //recebe o bean

                    String titulo;
                    if ("null".equals(request.getParameter("tituloR"))) {
                        titulo = null;
                    } else {
                        titulo = (String) request.getParameter("tituloR");
                    }
                    int tempo = (Integer.parseInt(request.getParameter("tempoR"))) / 60;
                    int pausa = (Integer.parseInt(request.getParameter("pausaR"))) / 60;
                    int serie = (Integer.parseInt(request.getParameter("serieR"))) / 2;
                    LocalDate data = now(); // recebe data atual

                    Pomodoro pomodoro = new Pomodoro(titulo, tempo, pausa, serie, data);//criando objeto

                    PomodoroFacade.registrarLogPomodoro(pomodoro, login);//registrando no bd

                    rd = request.getRequestDispatcher("PomodoroServlet?action=list");
                    rd.forward(request, response);
                    break;
                }
                default:
                    rd = request.getRequestDispatcher("PomodoroServlet?action=list");
                    request.setAttribute("mensagem", "Ação não encontrada, tente novamente");
                    rd.forward(request, response);
                    //Se não encontrar a ação, abre a página de login
                    break;
            }
        } catch (DAOException | SQLException | PomodoroException ex) {
            RequestDispatcher rd;
            rd = request.getRequestDispatcher("/index.jsp");
            request.setAttribute("mensagem", "Sessão expirada, para continuar usando o sistema é necessário realizar login.");
            rd.forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
