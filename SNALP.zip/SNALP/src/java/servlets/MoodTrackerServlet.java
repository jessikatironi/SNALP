package servlets;

import beans.Atividade;
import beans.Categoria;
import beans.Humor;
import beans.MoodTracker;
import beans.Objetivo;
import beans.Usuario;
import com.google.gson.Gson;
import exception.AtividadeException;
import exception.CategoriaException;
import exception.DAOException;
import exception.HumorException;
import exception.MoodTrackerException;
import exception.ObjetivoException;
import exception.PomodoroException;
import exception.WorkspaceException;
import facade.AtividadeFacade;
import facade.CategoriaFacade;
import facade.HumorFacade;
import facade.MoodTrackerFacade;
import facade.ObjetivoFacade;
import facade.PomodoroFacade;
import facade.WorkspaceFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "MoodTrackerServlet", urlPatterns = {"/MoodTrackerServlet"})
public class MoodTrackerServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("logado");
        
        String action = (String) request.getParameter("action");
        
        if (session.getAttribute("logado") == null) {
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
            request.setAttribute("mensagem", "Realize o seu login para acessar o SNALP!");
            rd.forward(request, response);
            
        } else {

            if (action == null || action.equals("listConfig")) {
                // listar humores, categorias, atividades e objetivo para as configurações do Mood Tracker
                try {
                    // lista humores do usuário
                    List<Humor> listaHumores = HumorFacade.listarHumores(usuario);
                    request.setAttribute("listaHumores", listaHumores);

                    // lista categorias de atividades do usuário
                    List<Categoria> listaCategorias = CategoriaFacade.listarCategorias(usuario);
                    request.setAttribute("listaCategorias", listaCategorias);

                    // verifica se o usuário tem um objetivo ativo
                    boolean temObjetivo = ObjetivoFacade.verificarObjetivo(usuario);
                    request.setAttribute("temObjetivo", temObjetivo);

                    // caso o usuário possua um objetivo ativo
                    if(temObjetivo) {
                        // lista objetivo do usuário
                        Objetivo objetivo = ObjetivoFacade.buscarObjetivo(usuario);
                        request.setAttribute("objetivo", objetivo);
                    }

                    // redireciona o usuário para a página de configuração do mood tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/moodTrackerConfig.jsp");
                    rd.forward(request, response);
                    
                } catch (HumorException | CategoriaException | AtividadeException | ObjetivoException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if (action.equals("listCharts")) {
                // listar estatísticas e dados para os gráficos mood tracker do usuário
                try { 
                    // chama método da facade para listar registros mood tracker do usuário
                    List<MoodTracker> listaRegistros = MoodTrackerFacade.listarRegistros(usuario);
                    // recupera a qtde de registros através do tamanho da lista
                    int qtdeRegistros = listaRegistros.size();
                    // envia a qtde de registros na resposta da requisição
                    request.setAttribute("qtdeRegistros", qtdeRegistros);
                    
                    // chama método da facade para verificar se o usuário possui objetivo ativo
                    boolean temObjetivo = ObjetivoFacade.verificarObjetivo(usuario);
                    // envia a verificação de objetivo na resposta da requisição
                    request.setAttribute("temObjetivo", temObjetivo);
                    
                    // chama método da facade para buscar a sequência atual de dias de objetivo cumprido
                    int sequenciaObjetivo = MoodTrackerFacade.gerarEstatisticasObjetivo(usuario);
                    // envia a sequência atual de dias de objetivo cumprido na resposta da requisição
                    request.setAttribute("sequenciaObjetivo", sequenciaObjetivo);
                    
                    // chama método da facade para listar os humores do usuario 
                    List<Humor> listaHumores = HumorFacade.listarHumores(usuario);
                    // envia a lista de humores na resposta da requisição
                    request.setAttribute("listaHumores", listaHumores);
                    // recupera a qtde de humores através do tamanho da lista
                    int qtdeHumores = listaHumores.size();
                    // envia a qtde de humores na resposta da requisição
                    request.setAttribute("qtdeHumores", qtdeHumores);
                    
                    // chama método da facade para listar categorias de atividades do usuário
                    List<Categoria> listaCategorias = CategoriaFacade.listarCategorias(usuario);
                    // recupera a qtde de categorias através do tamanho da lista
                    int qtdeCategorias = listaCategorias.size();
                    // envia a qtde de categorias na resposta da requisição
                    request.setAttribute("qtdeCategorias", qtdeCategorias);
                    
                    // inicializa lista de atividades
                    List<Atividade> listaAtividades = new ArrayList<>();
                    
                    for(Categoria categoria: listaCategorias) {
                        // chama método da facade para listar atividades da categoria
                        listaAtividades.addAll(AtividadeFacade.listarAtividades(categoria));
                    }
                    
                    // recupera a qtde de atividades através do tamanho da lista
                    int qtdeAtividades = listaAtividades.size();
                    // envia a qtde de atividades na resposta da requisição
                    request.setAttribute("qtdeAtividades", qtdeAtividades);
                    
                    // redireciona o usuário para a página de estatísticas do Mood Tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/moodTrackerDashboard.jsp");
                    rd.forward(request, response);
                    
                } catch (MoodTrackerException | HumorException | ObjetivoException | AtividadeException | CategoriaException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            
            } else if(action.equals("list")) {
                // listar registros mood tracker do usuário
                try {
                    // chama método da facade para listar os registros mood tracker do usuario 
                    List<MoodTracker> listaRegistros = MoodTrackerFacade.listarRegistros(usuario);
                    request.setAttribute("listaRegistros", listaRegistros);
                    
                    // redireciona o usuário para a página de registros do Mood Tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/moodTrackerRegistros.jsp");
                    rd.forward(request, response);
                    
                } catch (MoodTrackerException | HumorException | CategoriaException | AtividadeException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                
            } else if(action.equals("formNew")) {
                // formulário para inserir registro mood tracker
                
                // resgata o tipo do novo registro moood tracker, passado por parâmetro na requisição:
                // 1- registro do dia de hoje / 2- registro do dia de ontem / 3- registro de outro dia
                String dateType = request.getParameter("dateType");
                if (dateType == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                
                try {
                    int dateTypeInt = Integer.parseInt(dateType);
                    
                    switch (dateTypeInt) {
                        // caso a criação do novo registro seja com a data de hoje
                        case 1:
                            // resgata a data do novo registro: a data de hoje
                            LocalDate dataRegistro = LocalDate.now();
                            // envia a data do registro na resposta da requisição
                            request.setAttribute("dataRegistro", dataRegistro);
                            
                            // formata a data do registro para exibir no formulário de inserção
                            Locale local = new Locale("pt", "BR");
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM 'de' yyyy", local);
                            String dataFormatada = dataRegistro.format(formatter);
                            // envia a data do registro formatada na resposta da requisição
                            request.setAttribute("dataFormatada", dataFormatada);
                            
                            break;
                            
                        // caso a criação do novo registro seja com a data de ontem
                        case 2:
                            // resgata a data do novo registro: a data de ontem
                            dataRegistro = LocalDate.now().minusDays(1);
                            // envia a data do registro na resposta da requisição
                            request.setAttribute("dataRegistro", dataRegistro);
                            
                            // formata a data do registro para exibir no formulário de inserção
                            local = new Locale("pt", "BR");
                            formatter = DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM 'de' yyyy", local);
                            dataFormatada = dataRegistro.format(formatter);
                            // envia a data do registro formatada na resposta da requisição
                            request.setAttribute("dataFormatada", dataFormatada);
                            
                            break;
                            
                        // caso a criação do novo registro seja com outra data
                        case 3:
                            // seta data para "dd/mm/aaaa"
                            dataRegistro = LocalDate.MIN;
                            // envia a data do registro na resposta da requisição
                            request.setAttribute("dataRegistro", dataRegistro);
                            
                            request.setAttribute("dataFormatada", "Escolha uma data para o registro . . .");
                            
                            break;
                            
                        default:
                            request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                            RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                            rd.forward(request, response);
                            break;
                    }
                    
                    

                    // resgata a lista de humores do usuário
                    List<Humor> listaHumores = HumorFacade.listarHumores(usuario);
                    // envia a lista de humores na resposta da requisição
                    request.setAttribute("listaHumores", listaHumores);
                    
                    // resgata a lista de categorias de atividades do usuário
                    List<Categoria> listaCategorias = CategoriaFacade.listarCategorias(usuario);
                    // envia a lista de categorias na resposta da requisição
                    request.setAttribute("listaCategorias", listaCategorias);
                    
                    // verifica se o usuário tem um objetivo ativo
                    boolean temObjetivo = ObjetivoFacade.verificarObjetivo(usuario);
                    request.setAttribute("temObjetivo", temObjetivo);

                    // caso o usuário possua um objetivo ativo
                    if(temObjetivo) {
                        // resgata o objetivo do usuário
                        Objetivo objetivo = ObjetivoFacade.buscarObjetivo(usuario);
                        // envia o objetivo na resposta da requisição
                        request.setAttribute("objetivo", objetivo);
                    }

                    // redireciona o usuário para o formulário de inserção de novo registro mood tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/moodTrackerForm.jsp");
                    rd.forward(request, response);

                } catch (HumorException | CategoriaException | AtividadeException | ObjetivoException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                
            } else if (action.equals("new")) {
                // inserir novo registro mood tracker
                
                try {
                    // instancia novo registro mood tracker
                    MoodTracker registro = new MoodTracker();
                    
                    // resgata a data do novo registro, passada por parâmetro e seta o atributo data no registro mood tracker
                    String dataMoodTracker = request.getParameter("dataMoodTracker");
                    registro.setDataMoodTracker(LocalDate.parse(dataMoodTracker));
                    
                    // resgata a descição do novo registro, passada por parâmetro e seta o atributo descrição no registro mood tracker
                    registro.setDescricaoMoodTracker(request.getParameter("descricaoMoodTracker"));
                    
                    // resgata a situação do cumprimento do objetivo no novo registro, passado por parâmetro e seta o atributo cumpriu objetivo no registro mood tracker
                    String cumpriuObjetivo =  request.getParameter("cumpriuObjetivoMoodTracker");
                    registro.setCumpriuObjetivoMoodTracker(Boolean.parseBoolean(cumpriuObjetivo));
                    
                    // resgata o id do humor maracdo no formulário, passado por parâmetro
                    long idHumor = Long.parseLong(request.getParameter("humorMoodTracker"));
                    // chama método da facade para buscar os dados do humor e seta o atributo humor no registro mood tracker
                    registro.setHumorMoodTracker(HumorFacade.buscarHumor(idHumor));
                    
                    // resgata os id's das atividades marcadas no formulário, passados por parâmetro
                    String[] atividades = request.getParameterValues("atividadesMoodTracker");
                    
                    // instancia nova lista de atividades
                    List<Atividade> listaAtividadesMoodTracker = new ArrayList<>();
                    
                    // verifica se houve seleção de atividades (caso o usuário não tenha marcado a realização de atividades, "atividades" será null)
                    if(atividades != null){
                        
                        List<String> list = Arrays.asList(atividades);
                        
                        // para cada id, chama método da facade para buscar os dados da atividade e adiciona a atividade à lista
                        for(String idAtividade: list) {
                            listaAtividadesMoodTracker.add(AtividadeFacade.buscarAtividade(Long.parseLong(idAtividade)));
                        }
                    }   
                        
                    // seta o atributo lista de atividades no registro mood tracker
                    registro.setListaAtividadesMoodTracker(listaAtividadesMoodTracker);
                    
                    // chama o método da facade para criar o novo registro mood tracker
                    MoodTrackerFacade.criarRegistro(registro, usuario); 
                    
                    // redireciona o usuário para a página de registros do Mood Tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/MoodTrackerServlet?action=list");
                    rd.forward(request, response);
   
                } catch (MoodTrackerException | HumorException | CategoriaException | AtividadeException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                } 
                
                
            } else if (action.equals("formUpdate")) {
                // formulário para alterar registro mood tracker
                
                // resgata o id do registro moood tracker, passado por parâmetro na requisição
                String idMoodTracker = request.getParameter("idMoodTracker");
                if (idMoodTracker == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                
                try {
                    // resgata os dados do registro mood tracker, passando idMoodTracker como parâmetro
                    MoodTracker registro = MoodTrackerFacade.buscarRegistro(Long.parseLong(idMoodTracker));
                    
                    // envia o objeto registro mood tracker na resposta da requisição
                    request.setAttribute("registro", registro);
                    // define o tipo do formulario como update
                    request.setAttribute("type", "update");
                    
                    // resgata a data do registro
                    LocalDate dataRegistro = registro.getDataMoodTracker();
                    // formata a data do registro para exibir no formulário de alteração
                    Locale local = new Locale("pt", "BR");
                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM 'de' yyyy", local);
                    String dataFormatada = dataRegistro.format(formatter);
                    // envia a data do registro formatada na resposta da requisição
                    request.setAttribute("dataFormatada", dataFormatada);

                    // resgata a lista de humores do usuário
                    List<Humor> listaHumores = HumorFacade.listarHumores(usuario);
                    // envia a lista de humores na resposta da requisição
                    request.setAttribute("listaHumores", listaHumores);
                    
                    // resgata a lista de categorias de atividades do usuário
                    List<Categoria> listaCategorias = CategoriaFacade.listarCategorias(usuario);
                    // envia a lista de categorias na resposta da requisição
                    request.setAttribute("listaCategorias", listaCategorias);
                    
                    // verifica se o usuário tem um objetivo ativo
                    boolean temObjetivo = ObjetivoFacade.verificarObjetivo(usuario);
                    request.setAttribute("temObjetivo", temObjetivo);

                    // caso o usuário possua um objetivo ativo
                    if(temObjetivo) {
                        // resgata o objetivo do usuário
                        Objetivo objetivo = ObjetivoFacade.buscarObjetivo(usuario);
                        // envia o objetivo na resposta da requisição
                        request.setAttribute("objetivo", objetivo);
                    }
                    
                    // redireciona o usuário para o formulário de alteração de registro mood tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/moodTrackerForm.jsp");
                    rd.forward(request, response);
                    
                } catch(MoodTrackerException | HumorException | CategoriaException | AtividadeException | ObjetivoException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                
            } else if (action.equals("update")) {
                // alterar registro mood tracker
                
                // resgata o id do registro moood tracker, passado por parâmetro na requisição
                String idMoodTracker = request.getParameter("idMoodTracker");
                if (idMoodTracker == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                
                try {
                    // instancia novo registro mood tracker
                    MoodTracker registro = new MoodTracker();
                    
                    // seta o atributo id no registro mood tracker
                    registro.setIdMoodTracker(Long.parseLong(idMoodTracker));
                    
                    // resgata a data do registro, passada por parâmetro e seta o atributo data no registro mood tracker
                    String dataMoodTracker = request.getParameter("dataMoodTracker");
                    registro.setDataMoodTracker(LocalDate.parse(dataMoodTracker));
                    
                    // resgata a nova descição do registro, passada por parâmetro e seta o atributo descrição no registro mood tracker
                    registro.setDescricaoMoodTracker(request.getParameter("descricaoMoodTracker"));
                    
                    // resgata a nova situação do cumprimento do objetivo no novo registro, passado por parâmetro e seta o atributo cumpriu objetivo no registro mood tracker
                    String cumpriuObjetivo =  request.getParameter("cumpriuObjetivoMoodTracker");
                    registro.setCumpriuObjetivoMoodTracker(Boolean.parseBoolean(cumpriuObjetivo));
                    
                    // resgata o id do novo humor maracdo no formulário, passado por parâmetro
                    long idHumor = Long.parseLong(request.getParameter("humorMoodTracker"));
                    // chama método da facade para buscar os dados do humor e seta o atributo humor no registro mood tracker
                    registro.setHumorMoodTracker(HumorFacade.buscarHumor(idHumor));
                    
                    // resgata os id's das novas atividades marcadas no formulário, passados por parâmetro
                    String[] atividades = request.getParameterValues("atividadesMoodTracker");
                    
                    // instancia nova lista de atividades
                    List<Atividade> listaAtividadesMoodTracker = new ArrayList<>();
                    
                    // verifica se houve seleção de atividades (caso o usuário não tenha marcado a realização de atividades, "atividades" será null)
                    if(atividades != null){
                        
                        List<String> list = Arrays.asList(atividades);
                        
                        // para cada id, chama método da facade para buscar os dados da atividade e adiciona a atividade à lista
                        for(String idAtividade: list) {
                            listaAtividadesMoodTracker.add(AtividadeFacade.buscarAtividade(Long.parseLong(idAtividade)));
                        }
                    }
                    
                    // seta o atributo lista de atividades no registro mood tracker
                    registro.setListaAtividadesMoodTracker(listaAtividadesMoodTracker);
                    
                    // chama o método da facade para atualiza o registro mood tracker
                    MoodTrackerFacade.atualizarRegistro(registro);
                    
                    // redireciona o usuário para a página de registros do Mood Tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/MoodTrackerServlet?action=list");
                    rd.forward(request, response);
                    
                } catch (MoodTrackerException | HumorException | CategoriaException | AtividadeException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                
            } else if (action.equals("delete")) {
                // remover registro mood tracker
                
                // resgata o id do registro moood tracker, passado por parâmetro na requisição 
                String idMoodTracker = request.getParameter("idMoodTracker");
                // verifica se o id não é nulo
                if (idMoodTracker == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                // caso o id não seja nulo
                try {
                    // chama o método da facade para remover o registro mood tracker
                    MoodTrackerFacade.removerRegistro(Long.parseLong(idMoodTracker));
                    
                    // redireciona o usuário para a página de registros do mood tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/MoodTrackerServlet?action=list");
                    rd.forward(request, response);
                    
                } catch(MoodTrackerException | HumorException | CategoriaException | AtividadeException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                
            } else if (action.equals("drawChartContagemHumores")) {
                // gráfico de contagem de humores
                try {
                    Gson gson = new Gson();
                    response.setContentType("application/json");
                    PrintWriter out = response.getWriter();
                    out.println(gson.toJson(MoodTrackerFacade.gerarGraficoContagemHumores(usuario)));
                    
                } catch(MoodTrackerException | HumorException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            
            } else if (action.equals("drawChartContagemAtividades")) {
                // gráfico de contagem de ativiades
                try {
                    Gson gson = new Gson();
                    response.setContentType("application/json");
                    PrintWriter out = response.getWriter();
                    out.println(gson.toJson(MoodTrackerFacade.gerarGraficoContagemAtividades(usuario)));
                    
                } catch(MoodTrackerException | HumorException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            
            } else if (action.equals("drawChartAtividadesPorHumor")) {
                // gráfico de atividades mais frequentes por humor
                
                // resgata o id do humor selecuionado pelo usuario, passado por parâmetro na requisição 
                String idHumor = request.getParameter("idHumor");
                // verifica se o id não é nulo
                if (idHumor == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                // se o id não for nulo
                try {
                    // chama método da facade para buscar os dados do humor
                    Humor humor = HumorFacade.buscarHumor(Long.parseLong(idHumor));
                    
                    Gson gson = new Gson();
                    response.setContentType("application/json");
                    PrintWriter out = response.getWriter();
                    out.println(gson.toJson(MoodTrackerFacade.gerarGraficoAtividadesPorHumor(usuario, humor)));
                    
                } catch(MoodTrackerException | HumorException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            
            } else if (action.equals("drawChartHumores")) {
                // gráfico de humores por data de registro
                
                try {
                    Gson gson = new Gson();
                    response.setContentType("application/json");
                    PrintWriter out = response.getWriter();
                    out.println(gson.toJson(MoodTrackerFacade.gerarGraficoHumores(usuario)));
                    
                } catch(MoodTrackerException | HumorException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            
            } else if(action.equals("listGeneralStatistics")) {
                // listar estatísticas para o dashboard geral do usuário
                try {
                    
                    // chama método da facade para listar a quantidade de tarefas concluídas por período
                    List<Integer> listaQtdeTarefas = WorkspaceFacade.listarEstatisticasGerais(usuario);
                    // envia a qtde de tarefas na resposta da requisição
                    request.setAttribute("listaQtdeTarefas", listaQtdeTarefas);
                    
                    // chama método da facade para listar os humores mais selecionados por período
                    List<Humor> listaHumores = MoodTrackerFacade.listarEstatisticasGerais(usuario);
                    // envia a qtde de registros na resposta da requisição
                    request.setAttribute("listaHumores", listaHumores);
                    
                    // chama método da facade para listar a quantidade de relógios pomodoro executados por período
                    List<Integer> listaQtdeRelogios = PomodoroFacade.listarEstatisticasGerais(usuario);
                    // envia a qtde de relógios na resposta da requisição
                    request.setAttribute("listaQtdeRelogios", listaQtdeRelogios);
                    
                    // redireciona o usuário para a página de dashboard geral
                    RequestDispatcher rd = request.getRequestDispatcher("/dashboardGeral.jsp");
                    rd.forward(request, response);
                    
                } catch (MoodTrackerException | HumorException | WorkspaceException | PomodoroException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            
            } else if(action.equals("validateRegisterDate")) {
                // valida data do registro Mood Tracker: só pode ter um registro por dia
                
                // resgata a nova data selecionada pelo usuario, passada por parâmetro na requisição 
                LocalDate registerDate = LocalDate.parse(request.getParameter("registerDate"));
                
                // verifica se a data não é nula
                if (registerDate == null) {
                    request.setAttribute("mensagem", "Invocação inválida: data é nula...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                
                // se a data não for nula
                try {
                    // chama método da facade para validar a data selecionada
                    Boolean dataValida = MoodTrackerFacade.validarDataRegistro(usuario, registerDate);

                    Gson gson = new Gson();
                    response.setContentType("application/json");
                    PrintWriter out = response.getWriter();
                    out.println(gson.toJson(dataValida));
                    
                }  catch (MoodTrackerException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            
            } else if(action.equals("updateRegisterDate")) {
                // atualiza cabeçalho da data no Mood Tracker Form
                
                // resgata a nova data selecionada pelo usuario, passada por parâmetro na requisição 
                LocalDate registerDate = LocalDate.parse(request.getParameter("registerDate"));
                
                // verifica se a data não é nula
                if (registerDate == null) {
                    request.setAttribute("mensagem", "Invocação inválida: data é nula...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                
                // se a data não for nula

                // formata a data do registro para exibir no formulário
                Locale local = new Locale("pt", "BR");
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("EEEE, dd 'de' MMMM 'de' yyyy", local);
                String dataFormatada = registerDate.format(formatter);
                    
                Gson gson = new Gson();
                response.setContentType("application/json");
                PrintWriter out = response.getWriter();
                out.println(gson.toJson(dataFormatada));
                
            
            } else {
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                request.setAttribute("mensagem", "ERRO: invocação inválida!");
                rd.forward(request, response);
            }
            
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
