package servlets;

import beans.Etiqueta;
import beans.Status;
import beans.Subtarefa;
import beans.Tarefa;
import beans.Usuario;
import com.google.gson.Gson;
import exception.DAOException;
import exception.EtiquetaException;
import exception.StatusException;
import exception.SubtarefaException;
import exception.TarefaException;
import facade.EtiquetaFacade;
import facade.StatusFacade;
import facade.SubtarefaFacade;
import facade.TarefaFacade;
import java.io.IOException;
import java.time.LocalDate;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "TarefaServlet", urlPatterns = {"/TarefaServlet"})
public class TarefaServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        
        //resgata sessão
        HttpSession session = request.getSession();
        Usuario u = (Usuario) session.getAttribute("logado");
        
        String action = (String) request.getParameter("action");    //ação que será realizada e é passada por parametro
        
        //Verifica sessão
        if (session.getAttribute("logado") == null) {
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
            request.setAttribute("mensagem", "Realize o seu login para acessar o SNALP!");
            rd.forward(request, response);
            
        } else {
            if (action.equals("formNew")){

                try{
                    //resgata id do status
                    if (request.getParameter("idStatus") == null || request.getParameter("idStatus").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id status é nulo");
                    }

                    //Resgata id do status
                    long idStatus = Long.parseLong(request.getParameter("idStatus"));
                    String view = (String)request.getParameter("view");

                    //status
                    request.setAttribute("status", idStatus);
                    //view ativa
                    request.setAttribute("view", view);
                    //tipo do formulario como atributo da requisição
                    request.setAttribute("type", "new");
                    //Define o tipo do formulario para a tarefaForm.jsp carregar os dados
                    RequestDispatcher rd = request.getRequestDispatcher("/tarefaForm.jsp");
                    rd.forward(request, response);

                 } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para busca inválido= " + request.getParameter("idStatus"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch(NullPointerException e) {
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }

            }

            else if (action.equals("new")){
                try{
                    //Resgata valores dos campos preenchidos no formulário
                    String titulo = (String) request.getParameter("titulo");
                    String desc = (String) request.getParameter("desc");
                    LocalDate dataEntrega;

                    if(request.getParameter("dataEntrega") == null || request.getParameter("dataEntrega").isEmpty()) dataEntrega = null;
                    else dataEntrega = LocalDate.parse(request.getParameter("dataEntrega"));

                    //resgata id do status
                    if (request.getParameter("idStatus") == null || request.getParameter("idStatus").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata id do status
                    long idStatus = Long.parseLong(request.getParameter("idStatus"));
                    String view = (String)request.getParameter("view");

                    //Instanciação da nova tarefa
                    Tarefa t = new Tarefa(titulo, desc, dataEntrega);

                    //Chama facade para inserir tarefa  na base de dados
                    TarefaFacade facade =  new TarefaFacade();
                    facade.criarTarefa(t,idStatus);

                    //resgata idWorkspace do cookie para servlet carregar informações da workspace
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));

                    //Redireciona usuario para pagina da workspace
                    response.sendRedirect(request.getContextPath() + "/WorkspaceServlet?action=view&view="+view+"&idWorkspace="+idWorkspace);

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para busca inválido= " + request.getParameter("idWorkspace"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch(DAOException | TarefaException | NullPointerException e) {
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }
            }

            else if (action.equals("formUpdate")){
                try {
                    if (request.getParameter("idTarefa") == null || request.getParameter("idTarefa").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata id da tarefa passada por parametro na requisição
                    long id = Long.parseLong(request.getParameter("idTarefa"));

                    //Busca os dados da tarefa na base de dados
                    TarefaFacade facade = new TarefaFacade();
                    Tarefa t = facade.buscarTarefa(id);

                    //tipo do formulario como atributo da requisição
                    request.setAttribute("type", "update");
                    //Envia objeto Status na resposta da requisição
                    request.setAttribute("tarefa", t);
                    //Envia requisição para a tarefaForm.jsp
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/tarefaForm.jsp");
                    rd.forward(request, response);

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id da tarefa inválido= " + request.getParameter("id"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (NullPointerException | DAOException | TarefaException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }

            else if (action.equals("update")){
                try{
                    if (request.getParameter("idTarefa") == null || request.getParameter("idTarefa").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id tarefa é nulo");
                    }

                    //Resgata valores da requisição
                    long idTarefa = Long.parseLong(request.getParameter("idTarefa"));
                    String tipo = (String) request.getParameter("tipo");
                    //Instancia tarefa
                    Tarefa t = new Tarefa();
                    t.setIdTarefa(idTarefa);

                    //resgata informação a ser atualizada e seta na tarefa
                    if(tipo.equals("titulo")) t.setTitulo((String)request.getParameter("titulo"));
                    if(tipo.equals("desc")) t.setDescricao((String)request.getParameter("desc"));
                    if(tipo.equals("data")){
                        if(request.getParameter("date").isEmpty()) t.setDataEntrega(null);
                        else t.setDataEntrega(LocalDate.parse(request.getParameter("date")));
                    }

                    //Chama método da facade para atualizar registro
                    TarefaFacade facade = new TarefaFacade();
                    facade.atualizarTarefa(t,tipo);
                    
                    //cria json com tarefa
                    String json = new Gson().toJson(t);
                    //insere json na resposta da requisição
                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json);

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para atualização inválido= " + request.getParameter("id"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (NullPointerException | DAOException | TarefaException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }

            else if (action.equals("delete")){
                try{
                    if (request.getParameter("idTarefa") == null || request.getParameter("idTarefa").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id tarefa é nulo");
                    }

                    //Resgata id da tarefa a ser removida
                    long idTarefa = Long.parseLong(request.getParameter("idTarefa"));

                    //Executa método facade para chamada de remoção da tarefa
                    TarefaFacade facade = new TarefaFacade();
                    facade.removerTarefa(idTarefa);

                    //verifica id workspace da requisição
                    if (request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id workspace é nulo");
                    }

                    //Resgata id da workspace para redirecionar página
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));
                    String view = (String)request.getParameter("view");

                    //Redireciona usuário para pagina da workspace
                    response.sendRedirect(request.getContextPath() + "/WorkspaceServlet?action=view&idWorkspace="+idWorkspace+"&view="+view);

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para remoção inválido= " + request.getParameter("id"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (NullPointerException | DAOException | TarefaException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }

            else if (action.equals("show")){
                try{
                    if (request.getParameter("idTarefa") == null || request.getParameter("idTarefa").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id tarefa é nulo");
                    }
                    if (request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id workspace é nulo");
                    }

                    //Resgata id da workspace
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));

                    //Resgata id da tarefa
                    long id = Long.parseLong(request.getParameter("idTarefa"));
                    //resgata view
                    String view = (String)request.getParameter("view");

                    //Busca os dados da tarefa na base de dados
                    TarefaFacade facade = new TarefaFacade();
                    Tarefa t = facade.buscarTarefa(id);

                    //Busca lista de subtarefas da tarefa
                    SubtarefaFacade subFacade = new SubtarefaFacade();
                    List<Subtarefa> subtarefas = subFacade.listarSubtarefas(id);
                    t.setSubtarefas(subtarefas);

                    //Busca lista de etiquetas disponiveis
                    EtiquetaFacade eFacade = new EtiquetaFacade();
                    List<Etiqueta> etiquetas = eFacade.etiquetasDisponiveis(id, idWorkspace);

                    //Busca lista de etiquetas da tarefa
                    List<Etiqueta> etiquetasTarefa = eFacade.etiquetasTarefa(id);
                    t.setEtiquetas(etiquetasTarefa);
                    
                    //Lista de status disponíveis
                    StatusFacade sFacade = new StatusFacade();
                    List<Status> disponiveis = sFacade.listarDisponiveis(idWorkspace, t.getStatus().getIdStatus());

                    //Seta atributos da requisição
                    request.setAttribute("tarefa", t);
                    request.setAttribute("listaEtiquetas", etiquetas);
                    request.setAttribute("view", view);
                    request.setAttribute("status", disponiveis);
                    //Envia requisição
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/tarefaShow.jsp");
                    rd.forward(request, response);

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id de busca inválido= " + request.getParameter("id"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (NullPointerException | DAOException | TarefaException | SubtarefaException | EtiquetaException | StatusException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }

            else if (action.equals("change")) {
                try {

                    //recebe parametro de tipo de operação
                    String type = (String) request.getParameter("type");
                    //recebe e transforma parametros da operação
                    long idTarefa = Long.parseLong(request.getParameter("idTarefa"));
                    long oldStatus = Long.parseLong(request.getParameter("oldStatus"));
                    int newOrdem = Integer.parseInt(request.getParameter("newOrdem"));
                    int oldOrdem = Integer.parseInt(request.getParameter("oldOrdem"));
                    long newStatus; //inicializa var dentro das condições que recebem o valor
                    
                    TarefaFacade facade = new TarefaFacade();
                    EtiquetaFacade eFacade = new EtiquetaFacade();

                    List<Tarefa> listaStatusOriginal;
                    List<Tarefa> listaStatusNovo;
                    String json1;
                    String json2;
                    String json;
                    
                    //Muda status da tarefa
                    if(type.equals("cs")){
                        //recebe parametro do novo status
                        newStatus = Long.parseLong(request.getParameter("newStatus"));
                        //chama facade para realizar a transação
                        facade.mudarStatus(oldStatus, newStatus, oldOrdem,  newOrdem, idTarefa);
                        //retorna lista de tarefas status original
                        listaStatusOriginal = facade.tarefasStatus(oldStatus);
                        //seta etiquetas
                        for(Tarefa t: listaStatusOriginal) {
                            t.setEtiquetas(eFacade.etiquetasTarefa(t.getIdTarefa()));
                        }
                        //retorna lista de tarefas status novo
                        listaStatusNovo = facade.tarefasStatus(newStatus);
                        //seta etiquetas
                        for(Tarefa t: listaStatusNovo) {
                            t.setEtiquetas(eFacade.etiquetasTarefa(t.getIdTarefa()));
                        }
                        //cria json de retorno com listas de tarefas após mudança de status
                        json1 = new Gson().toJson(listaStatusOriginal);
                        json2 = new Gson().toJson(listaStatusNovo);
                        json = "["+json1+","+json2+"]";
                        
                    //Muda tarefa para o final do status
                    } else if (type.equals("cse")) {
                        //recebe parametro do novo status
                        newStatus = Long.parseLong(request.getParameter("newStatus"));
                        //chama facade para realizar a transação
                        facade.mudarStatusFinal(oldStatus, newStatus, oldOrdem, newOrdem, idTarefa);
                        //retorna lista de tarefas status original
                        listaStatusOriginal = facade.tarefasStatus(oldStatus);
                        //seta etiquetas
                        for(Tarefa t: listaStatusOriginal) {
                            t.setEtiquetas(eFacade.etiquetasTarefa(t.getIdTarefa()));
                        }
                        //retorna lista de tarefas status novo
                        listaStatusNovo = facade.tarefasStatus(newStatus);
                        //seta etiquetas
                        for(Tarefa t: listaStatusNovo) {
                            t.setEtiquetas(eFacade.etiquetasTarefa(t.getIdTarefa()));
                        }
                        //cria json de retorno com listas de tarefas após mudança de status
                        json1 = new Gson().toJson(listaStatusOriginal);
                        json2 = new Gson().toJson(listaStatusNovo);
                        json = "["+json1+","+json2+"]";
                    
                    //Muda ordem da tarefa em um status - para cima
                    } else if (type.equals("ou")) {
                        //chama facade para realizar a transação
                        facade.mudarOrdemUp(oldStatus, oldOrdem, newOrdem, idTarefa);
                        //retorna lista de tarefas status original
                        listaStatusOriginal = facade.tarefasStatus(oldStatus);
                        //seta etiquetas
                        for(Tarefa t: listaStatusOriginal) {
                            t.setEtiquetas(eFacade.etiquetasTarefa(t.getIdTarefa()));
                        }
                        //cria json de retorno com lista de tarefas após ordenação
                        json = new Gson().toJson(listaStatusOriginal);
                        
                    //Muda ordem da tarefa em um status - para baixo
                    } else if (type.equals("od")) {
                        //chama facade para realizar a transação
                        facade.mudarOrdemDown(oldStatus, oldOrdem, newOrdem, idTarefa);
                        //retorna lista de tarefas status original
                        listaStatusOriginal = facade.tarefasStatus(oldStatus);
                        //seta etiquetas
                        for(Tarefa t: listaStatusOriginal) {
                            t.setEtiquetas(eFacade.etiquetasTarefa(t.getIdTarefa()));
                        }
                        //cria json de retorno com lista de tarefas após ordenação
                        json = new Gson().toJson(listaStatusOriginal);
                    } else throw new NullPointerException("Invocação inválida = tipo de transação incorreta");

                    //insere json na resposta da requisição
                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json);


                } catch (NullPointerException | DAOException | TarefaException | EtiquetaException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }
            }

            else if(action.equals("complete")){
                try {
                    //Valida tipo de operação
                    if (request.getParameter("tipo") == null || request.getParameter("tipo").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = tipo é nulo " + request.getParameter("tipo") );
                    }
                    //recebe parametro de tipo de operação
                    String tipo = (String) request.getParameter("tipo");
                    //recebe e transforma parametros da operação
                    long idTarefa = Long.parseLong(request.getParameter("idTarefa"));
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));
                    
                    //Chama facade para executar a operação
                    TarefaFacade facade = new TarefaFacade();
                    facade.completarTarefa(idTarefa, tipo, idWorkspace);
                    
                    //Cria json de resposta
                    String json = new Gson().toJson(tipo);

                    //insere json na resposta da requisição
                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json);

                } catch(NullPointerException | DAOException | TarefaException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }
            }
            
            else if(action.equals("statusChange")) {
                try {
                    //Validação idTarefa
                    if (request.getParameter("idTarefa") == null || request.getParameter("idTarefa").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id tarefa é nulo");
                    }
                    
                    //Transforma parametros da requisição
                    long idTarefa = Long.parseLong(request.getParameter("idTarefa"));
                    long oldStatus = Long.parseLong(request.getParameter("oldStatus"));
                    long newStatus = Long.parseLong(request.getParameter("newStatus"));
                    int ordem = Integer.parseInt(request.getParameter("ordem"));
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));
                    
                    //Muda status da tarefa
                    TarefaFacade facade = new TarefaFacade();
                    facade.mudarStatusTarefa(oldStatus, newStatus, idTarefa, ordem);
                    
                    //Busca lista de status disponiveis
                    StatusFacade sFacade = new StatusFacade();
                    List<Status> lista = sFacade.listarDisponiveis(idWorkspace, newStatus);
                    Status status = sFacade.buscarStatus(newStatus);
                    
                    //Busca tarefa com informações atualizadas
                    Tarefa t = facade.buscarTarefa(idTarefa);
                    
                    String json1 = new Gson().toJson(status);
                    String json2 = new Gson().toJson(lista);
                    String json3 = new Gson().toJson(t);
                    
                    //Cria json de resposta
                    String json = "["+json1+","+json2+","+json3+"]";

                    //insere json na resposta da requisição
                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json);
                    
                } catch(DAOException | TarefaException | StatusException e)  {
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }

            else {
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                request.setAttribute("msg", "ERRO: Invocação inválida");
                rd.forward(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
