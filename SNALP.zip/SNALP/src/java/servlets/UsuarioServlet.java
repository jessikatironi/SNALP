/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servlets;

import beans.MoodTracker;
import beans.Pomodoro;
import beans.Usuario;
import exception.AtividadeException;
import exception.CategoriaException;
import exception.DAOException;
import exception.HumorException;
import exception.MoodTrackerException;
import exception.PomodoroException;
import exception.UsuarioException;
import facade.MoodTrackerFacade;
import facade.PomodoroFacade;
import facade.UsuarioFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDate;
import static java.time.LocalDate.now;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Franshinsca
 */
@WebServlet(name = "UsuarioServlet", urlPatterns = {"/UsuarioServlet"})
public class UsuarioServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            RequestDispatcher rd;
            String action = request.getParameter("action");//recebe indicador de qual ação seguirs
            HttpSession session = request.getSession();//Cria uma sessão

            if (action == null) {
                action = "formUpdate";
            }

            switch (action) {

                case "showHome": {
                    try {
                        Usuario login = (Usuario) session.getAttribute("logado"); //recebe o bean

                        Pomodoro lastPomodoro = PomodoroFacade.buscarUltimoLogPomodoro(login);//recebe o último pomodoro
                        request.setAttribute("lastPomodoro", lastPomodoro);//coloca na requisição

                        MoodTracker lastMoodTracker = MoodTrackerFacade.buscarUltimoRegistro(login);//recebe o último pomodoro
                        request.setAttribute("lastMoodTracker", lastMoodTracker);//coloca na requisição

                        rd = request.getRequestDispatcher("/usuarioHome.jsp");
                        rd.forward(request, response);//redireciona a páginica inicial

                    } catch (DAOException | SQLException | PomodoroException | MoodTrackerException | HumorException | AtividadeException | CategoriaException ex) {
                        request.setAttribute("javax.servlet.jsp.jspException", ex);
                        request.setAttribute("javax.servlet.error.status_code", 500);
                        rd = getServletContext().getRequestDispatcher("/erro.jsp");
                        rd.forward(request, response);
                    }
                }

                break;

                case "formNew":
                    rd = request.getRequestDispatcher("/usuarioForm.jsp");
                    rd.forward(request, response);

                    break;

                case "new":
                try {
                    //recebe dados dos parâmetros
                    String nome = (String) request.getParameter("nome");
                    String email = (String) request.getParameter("email");
                    String senha = (String) request.getParameter("senha");

                    LocalDate data = now(); // recebe data atual

                    Usuario usuario = new Usuario(nome, email, senha, data);//declara novo usuário

                    UsuarioFacade.criarUsuario(usuario);//insere novo usuario
                    
                    request.setAttribute("mensagem", "Usuário cadastrado com sucesso!");
                    request.setAttribute("mensagemTipo", "alert alert-success");
                    rd = request.getRequestDispatcher("index.jsp");//indica página de redirecionamento
                    rd.forward(request, response);//redireciona

                } catch (UsuarioException e) {
                    request.setAttribute("mensagem", e.getMessage());// Armazena a mensagem de erro na requisição
                    rd = request.getRequestDispatcher("/index.jsp");//indica página de redirecionamento
                    rd.forward(request, response);//redireciona
                }
                break;

                case "formUpdate":
                try {
                    session = request.getSession();//Cria uma sessão
                    Usuario login = (Usuario) session.getAttribute("logado"); //recebe o bean
                    long idUsuario = login.getIdUsuario(); //atribui o id do bean

                    //busca id e setta dados CASO não sejam salvos no bean
                    rd = request.getRequestDispatcher("/usuarioPerfil.jsp");//indica página de redirecionamento
                    Usuario usuario = UsuarioFacade.buscarUsuario(idUsuario);

                    request.setAttribute("id", usuario.getIdUsuario());//Indica o id do usuário como atributo 
                    request.setAttribute("nome", usuario.getNomeUsuario());//Indica o nome como atributo
                    request.setAttribute("email", usuario.getEmailUsuario());//Indica o email como atributo 

                    rd.forward(request, response);//redireciona

                } catch (UsuarioException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                break;

                case "update":
                try {
                    //recebendo os parâmetros passados
                    session = request.getSession();//Cria uma sessão
                    Usuario login = (Usuario) session.getAttribute("logado"); //recebe o bean
                    long id = login.getIdUsuario(); //atribui o id do bean
                    String nome = (String) request.getParameter("nome");
                    String email = (String) request.getParameter("email");

                    //criando um usuário com os dados
                    Usuario usuario = new Usuario(id, nome, email);

                    //atualizando o banco de dados com os dados passados
                    UsuarioFacade.atualizarUsuario(usuario);

                    login.setNomeUsuario(nome);
                    session.setAttribute("logado", login);//atualiza o bean do usuario na sessão

                    request.setAttribute("mensagem", "Dados atualizados com sucesso!");
                    request.setAttribute("falhaSucesso", "alert alert-success");

                    rd = request.getRequestDispatcher("UsuarioServlet?action=formUpdate");//indica página de redirecionamento
                    rd.forward(request, response);//redireciona

                } catch (UsuarioException e) {
                    request.setAttribute("mensagem", "Erro ao tentar atualizar os dados, tente novamente.");
                    request.setAttribute("falhaSucesso", "alert alert alert-danger");
                    rd = request.getRequestDispatcher("/UsuarioServlet?action=formUpdate");//indica página de redirecionamento
                    rd.forward(request, response);//redireciona
                } catch (SQLException ex) {
                    request.setAttribute("mensagem", ex.getMessage());
                    request.setAttribute("falhaSucesso", "alert alert alert-danger");
                    rd = request.getRequestDispatcher("/UsuarioServlet?action=formUpdate");//indica página de redirecionamento
                    rd.forward(request, response);//redireciona
                }
                break;


                case "formSenha":

                    //Seleciona id do usuario pelo objeto Login da sessão
                    session = request.getSession();//Cria uma sessão
                    Usuario login = (Usuario) session.getAttribute("logado"); //recebe o bean
                    long idUsuario = login.getIdUsuario(); //atribui o id do bean

                    rd = request.getRequestDispatcher("/usuarioForm.jsp");//indica página de redirecionamento
                    request.setAttribute("id", idUsuario);//Indica o id do usuário como atributo
                    request.setAttribute("acao", "senha");//Indica a ação para o formulário executar
                    rd.forward(request, response);//redireciona

                    break;

                case "updateSenha":
                try {
                    //recebendo os parâmetros passados
                    session = request.getSession();//Cria uma sessão
                    login = (Usuario) session.getAttribute("logado"); //recebe o bean
                    if (login==null){
                        rd = request.getRequestDispatcher("/index.jsp");//indica página de redirecionamento
                        request.setAttribute("mensagem", "Realize o seu login para acessar o sistema.");
                        rd.forward(request, response);
                    }
                    Long id = login.getIdUsuario(); //atribui o id do bean
                    String senha = (String) request.getParameter("senha");
                    String senhaAtual = (String) request.getParameter("senhaAtual");

                    //criando um usuário com os dados
                    Usuario usuario = new Usuario(id, senha);

                    //confirmando a senha atual e atualizando o banco de dados
                    UsuarioFacade.atualizarSenha(usuario, senhaAtual);

                    request.setAttribute("falhaSucesso", "alert alert-success");
                    request.setAttribute("mensagem", "Senha atualizada com sucesso!");

                    rd = request.getRequestDispatcher("UsuarioServlet?action=formUpdate");//indica página de redirecionamento
                    rd.forward(request, response);//redireciona

                } catch (UsuarioException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                } catch (DAOException e) {
                    rd = request.getRequestDispatcher("UsuarioServlet?action=formUpdate");//indica página de redirecionamento
                    request.setAttribute("falhaSucesso", "alert alert-danger");
                    request.setAttribute("mensagem", "Senha atual incorreta, tente novamente.");
                    rd.forward(request, response);
                }
                break;

                case "delete":
                try {
                    long idExcluir = Long.parseLong(request.getParameter("id"));
                    //Seleciona id do usuario pelo objeto Login da sessão
                    session = request.getSession();//Cria uma sessão
                    login = (Usuario) session.getAttribute("logado");//recebe o bean
                    idUsuario = login.getIdUsuario();//atribui o id do bean

                    //Caso o id passado pela url seja diferente do qual solicitou a exclusão
                    if (idExcluir != idUsuario) {
                        request.setAttribute("mensagem", "Erro ao tentar excluir o usuario, tente novamente.");
                        request.setAttribute("falhaSucesso", "alert alert alert-danger");
                        rd = request.getRequestDispatcher("/UsuarioServlet?action=formUpdate.jsp");//indica página de redirecionamento
                        rd.forward(request, response);//redireciona
                    } else {
                        UsuarioFacade.removerUsuario(idUsuario);
                        request.setAttribute("mensagem", "Usuário excluído com sucesso.");
                        request.setAttribute("mensagemTipo", "alert alert-success");
                        rd = request.getRequestDispatcher("/index.jsp");//indica página de redirecionamento
                        rd.forward(request, response);//redireciona
                    }
                } catch (UsuarioException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                break;

            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
