package servlets;

import beans.Status;
import beans.Usuario;
import com.google.gson.Gson;
import exception.DAOException;
import exception.StatusException;
import facade.StatusFacade;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "StatusServlet", urlPatterns = {"/StatusServlet"})
public class StatusServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        //resgata sessão
        HttpSession session = request.getSession();
        Usuario u = (Usuario) session.getAttribute("logado");
        
        String action = (String) request.getParameter("action");    //ação que será realizada e é passada por parametro
        
        if (session.getAttribute("logado") == null) {
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
            request.setAttribute("mensagem", "Realize o seu login para acessar o SNALP!");
            rd.forward(request, response);
            
        } else {
            if (action.equals("formNew")){

                try {
                    // lista cores para o color picker de status
                    List<String> listaCores = StatusFacade.listarCores();
                    // envia a lista de cores na resposta da requisição
                    request.setAttribute("listaCores", listaCores);

                    String origin = (String)request.getParameter("origin");

                    //redireciona usuário ao formulario contido na workspaceForm.jsp
                    request.setAttribute("type", "newStatus");
                    if(origin.equals("kanban")) request.setAttribute("origin", origin);
                    RequestDispatcher rd = request.getRequestDispatcher("/workspaceConfigForm.jsp");
                    rd.forward(request, response);

                } catch(DAOException | StatusException e) {
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }

            }

            else if (action.equals("new")){
                try{
                    //Resgata valores dos campos preenchidos no formulário
                    String titulo = (String) request.getParameter("titulo");
                    String cor = (String) request.getParameter("cor");
                    String origin = (String)request.getParameter("origin");

                    System.out.println(cor);
                    //resgata id da workspace
                    if (request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata id da workspace
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));

                    //Instanciação do novo status
                    Status s = new Status(titulo,cor);

                    //Chama facade para inserir status na base de dados
                    StatusFacade facade =  new StatusFacade();
                    facade.criarStatus(s,idWorkspace);

                    //Redireciona usuario para pagina de configuracoes workspace ou para quadro da workspace
                    if(origin.equals("kanban")) response.sendRedirect(request.getContextPath() + "/WorkspaceServlet?action=show&idWorkspace="+idWorkspace);
                    else response.sendRedirect(request.getContextPath() + "/WorkspaceServlet?action=config&idWorkspace="+idWorkspace);

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para busca inválido= " + request.getParameter("idWorkspace"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch(DAOException | StatusException e) {
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }
            }

            else if (action.equals("formUpdate")){
                try {
                    if (request.getParameter("idStatus") == null || request.getParameter("idStatus").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata id do status passado por parametro na requisição
                    long id = Long.parseLong(request.getParameter("idStatus"));

                    //Busca os dados do status na base de dados
                    StatusFacade facade = new StatusFacade();
                    Status s = facade.buscarStatus(id);

                    //Envia objeto Status na resposta da requisição
                    request.setAttribute("status", s);
                    //Define o tipo do formulario para a workspaceConfigForm.jsp carregar os dados
                    request.setAttribute("type", "updateStatus");

                    // lista cores para o color picker de status
                    List<String> listaCores = StatusFacade.listarCores();
                    // envia a lista de cores na resposta da requisição
                    request.setAttribute("listaCores", listaCores);

                    //Envia requisição para a workspaceConfigForm.jsp
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/workspaceConfigForm.jsp");
                    rd.forward(request, response);

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id do status inválido= " + request.getParameter("id"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (NullPointerException | DAOException | StatusException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }

            else if (action.equals("update")){
                try{
                    if (request.getParameter("idStatus") == null || request.getParameter("idStatus").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata valores dos campos do formulário e id do status
                    long id = Long.parseLong(request.getParameter("idStatus"));
                    String titulo = (String) request.getParameter("titulo");
                    String cor = (String) request.getParameter("cor");

                    //resgata id da workspace
                    if (request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata id da workspace a ser removida
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));

                    //Instancia status e chama método da facade para atualizar registro
                    StatusFacade facade = new StatusFacade();
                    Status s = new Status(id,titulo,cor);
                    facade.atualizarStatus(s);

                    //Redireciona usuario para pagina de configuracoes workspace
                    response.sendRedirect(request.getContextPath() + "/WorkspaceServlet?action=config&idWorkspace="+idWorkspace);

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para atualização inválido= " + request.getParameter("id"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (NullPointerException | DAOException | StatusException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }
            
            else if (action.equals("updateOrder")) {
                try {
                    if (request.getParameter("idStatus") == null || request.getParameter("idStatus").isEmpty() || request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }
                    
                    //Recebe parametros
                    long idStatus = Long.parseLong(request.getParameter("idStatus"));
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));
                    int oldOrdem = Integer.parseInt(request.getParameter("oldOrdem"));
                    int newOrdem = Integer.parseInt(request.getParameter("newOrdem"));
                    
                    StatusFacade facade = new StatusFacade();
                    facade.atualizarOrdem(idStatus, oldOrdem, newOrdem);
                    List<Status> lista = facade.listarStatus(idWorkspace);
                    
                    //cria json de retorno
                    String json = new Gson().toJson(lista);

                    //insere json na resposta da requisição
                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json);                   
                    
                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para remoção inválido= " + request.getParameter("id"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (NullPointerException | DAOException | StatusException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }

            else if (action.equals("delete")){
                try{
                    if (request.getParameter("idStatus") == null || request.getParameter("idStatus").isEmpty() || request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata id do status a ser removido
                    long idStatus = Long.parseLong(request.getParameter("idStatus"));
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));
                    int ordem = Integer.parseInt(request.getParameter("ordem"));

                    //Executa método facade para chamada de remoção do status
                    StatusFacade facade = new StatusFacade();
                    facade.removerStatus(idStatus, ordem, idWorkspace);
                    List<Status> status = facade.listarStatus(idWorkspace);

                    //cria json de retorno
                    String json = new Gson().toJson(status);

                    //insere json na resposta da requisição
                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json);

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para remoção inválido= " + request.getParameter("id"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (NullPointerException | DAOException | StatusException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }
            
            else if (action.equals("deleteKanban")){
                try{
                    if (request.getParameter("idStatus") == null || request.getParameter("idStatus").isEmpty() || request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata id do status a ser removido
                    long idStatus = Long.parseLong(request.getParameter("idStatus"));
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));
                    int ordem = Integer.parseInt(request.getParameter("ordem"));

                    //Executa método facade para chamada de remoção do status
                    StatusFacade facade = new StatusFacade();
                    facade.removerStatus(idStatus, ordem, idWorkspace);

                    //redireciona para a página
                    response.sendRedirect(request.getContextPath() + "/WorkspaceServlet?action=view&idWorkspace="+idWorkspace+"&view=kanban");

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para remoção inválido= " + request.getParameter("id"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (NullPointerException | DAOException | StatusException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }

            else {
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                request.setAttribute("msg", "ERRO: Invocação inválida");
                rd.forward(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
