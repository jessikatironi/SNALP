package servlets;

import beans.Etiqueta;
import beans.Status;
import beans.Tarefa;
import beans.Usuario;
import beans.Workspace;
import com.google.gson.Gson;
import exception.DAOException;
import exception.EtiquetaException;
import exception.StatusException;
import exception.TarefaException;
import exception.WorkspaceException;
import facade.EtiquetaFacade;
import facade.StatusFacade;
import facade.TarefaFacade;
import facade.WorkspaceFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "WorkspaceServlet", urlPatterns = {"/WorkspaceServlet"})
public class WorkspaceServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        
        //resgata sessão
        HttpSession session = request.getSession();
        Usuario u = (Usuario) session.getAttribute("logado");
        
        String action = (String) request.getParameter("action");    //ação que será realizada e é passada por parametro
        
        //Valida sessão
        if (session.getAttribute("logado") == null) {
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
            request.setAttribute("mensagem", "Realize o seu login para acessar o SNALP!");
            rd.forward(request, response);
            
        } else {
            if(action.equals("formNew")){
                //redireciona usuário ao formulario contido na workspaceForm.jsp
                RequestDispatcher rd = request.getRequestDispatcher("/workspaceForm.jsp");
                rd.forward(request, response);

            }

            else if (action.equals("new")){
                try{
                    //Resgata valores dos campos preenchidos no formulário
                    String titulo = (String) request.getParameter("titulo");
                    String descricao = (String) request.getParameter("descricao");

                    //Instanciação da nova workspace
                    Workspace w = new Workspace(titulo,descricao);

                    //Chama facade para inserir workspace na base de dados
                    WorkspaceFacade facade =  new WorkspaceFacade();
                    facade.criarWorkspace(w,u);
                    
                    //Insere workspace na lista da sessão
                    List<Workspace> workspaces = new ArrayList<>();
                    if (u.getWorkspaces() != null) workspaces = u.getWorkspaces();
                    workspaces.add(w);
                    u.setWorkspaces(workspaces);
                    session.setAttribute("logado", u);

                    //Redireciona usuário para lista de workspaces
                    response.sendRedirect(request.getContextPath() + "/UsuarioServlet?action=showHome");

                } catch(DAOException | WorkspaceException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }          

            }

            else if (action.equals("formUpdate")){
                try{
                    if (request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata id da workspace passado por parametro na requisição
                    long id = Long.parseLong(request.getParameter("idWorkspace"));

                    //Busca os dados da workspace na base de dados
                    WorkspaceFacade facade = new WorkspaceFacade();
                    Workspace w = facade.buscarWorkspace(id);

                    //Envia objeto Workspace na resposta da requisição
                    request.setAttribute("workspace", w);
                    //Define o tipo do formulario para a workspaceForm.jsp carregar os dados
                    request.setAttribute("type", "update");
                    //Envia requisição para a workspaceForm.jsp
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/workspaceForm.jsp");
                    rd.forward(request, response);

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para remoção inválido= " + request.getParameter("idWorkspace"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch(DAOException | WorkspaceException e) {
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            }

            else if (action.equals("update")){
                try{
                    if (request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata valores dos campos do formulário e id da workspace
                    long id = Long.parseLong(request.getParameter("idWorkspace"));
                    String titulo = (String) request.getParameter("titulo");
                    String descricao = (String) request.getParameter("descricao");

                    //Instancia workspace e chama método da facade para atualizar registro
                    WorkspaceFacade facade = new WorkspaceFacade();
                    Workspace w = new Workspace(id,titulo,descricao);
                    facade.atualizarWorkspace(w);

                    //Atualiza lista de workspaces da sessão
                    List<Workspace> workspaces = facade.listarWorkspaces(u);
                    u.setWorkspaces(workspaces);
                    session.setAttribute("logado", u);

                    //Redireciona usuário para lista de workspaces
                    response.sendRedirect(request.getContextPath() + "/UsuarioServlet?action=showHome");

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para remoção inválido= " + request.getParameter("idWorkspace"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (DAOException | WorkspaceException e) {
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }

            else if (action.equals("delete")){
                try{
                    if (request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata id da workspace a ser removida
                    long id = Long.parseLong(request.getParameter("idWorkspace"));

                    //Executa método facade para chamada de remoção da workspace
                    WorkspaceFacade facade = new WorkspaceFacade();
                    facade.removerWorkspace(id);

                    //Atualiza lista de workspaces da sessão
                    List<Workspace> workspaces = facade.listarWorkspaces(u);
                    u.setWorkspaces(workspaces);
                    session.setAttribute("logado", u);

                    //Redireciona usuário para lista de workspaces
                    response.sendRedirect(request.getContextPath() + "/UsuarioServlet?action=showHome");

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para remoção inválido= " + request.getParameter("idWorkspace"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (NullPointerException | DAOException | WorkspaceException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            }

            else if (action.equals("config")){
                try{
                    if (request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata id da workspace a ser removida
                    long id = Long.parseLong(request.getParameter("idWorkspace"));

                    //Resgata lista de etiquetas
                    EtiquetaFacade EtiquetaFacade = new EtiquetaFacade();
                    List<Etiqueta> etiquetas = EtiquetaFacade.listarEtiquetas(id);
                    StatusFacade StatusFacade = new StatusFacade();
                    List<Status> status = StatusFacade.listarStatus(id);

                    //Insere lista de status e etiquetas na requisição
                    request.setAttribute("etiquetas", etiquetas);
                    request.setAttribute("status", status);

                    //Envia requisição para workspaceConfiguracoes.jsp
                    RequestDispatcher rd = request.getRequestDispatcher("workspaceConfig.jsp");//redireciona a página
                    rd.forward(request, response);

                 } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para busca inválido= " + request.getParameter("idWorkspace"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (DAOException | StatusException | EtiquetaException | NullPointerException e) {
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            }

            //Carrega workspace quando clicada no menu
            else if (action.equals("show")) {
                try {
                    if (request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //resgata id workspace clicada
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));

                    //chama facade e retorna lista de status
                    StatusFacade sFacade = new StatusFacade();
                    List<Status> status = sFacade.listarStatus(idWorkspace);

                    //chama facade e retorna lista de tarefas ativas e suas etiquetas
                    TarefaFacade tFacade = new TarefaFacade();
                    List<Tarefa> tarefas = tFacade.listarTarefasAtivas(idWorkspace);

                    EtiquetaFacade eFacade = new EtiquetaFacade();
                    for(Tarefa t: tarefas) {
                        t.setEtiquetas(eFacade.etiquetasTarefa(t.getIdTarefa()));
                    }

                    //lista de tarefas concluidas e suas etiquetas
                    List<Tarefa> tarefasConcluidas = tFacade.listarTarefasConcluidas(idWorkspace);
                    for(Tarefa t: tarefasConcluidas) {
                        t.setEtiquetas(eFacade.etiquetasTarefa(t.getIdTarefa()));
                    }

                    //chama facade e retorna workspace
                    WorkspaceFacade wFacade = new WorkspaceFacade();
                    Workspace w = wFacade.buscarWorkspace(idWorkspace);

                    //seta cookie para controle de qual workspace está aberta
                    Cookie c = new Cookie("workspace",request.getParameter("idWorkspace"));
                    response.addCookie(c);

                    LocalDate hoje = LocalDate.now();

                    //seta atributos da requisição
                    request.setAttribute("status", status);
                    request.setAttribute("tarefas", tarefas);
                    request.setAttribute("concluidas", tarefasConcluidas);
                    request.setAttribute("workspace", w);
                    request.setAttribute("view", "kanban");
                    request.setAttribute("hoje", hoje);

                    //Envia requisição para workspace.jsp
                    RequestDispatcher rd = request.getRequestDispatcher("workspace.jsp");//redireciona a página
                    rd.forward(request, response);

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para busca inválido= " + request.getParameter("idWorkspace"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch(DAOException | StatusException | TarefaException | WorkspaceException | EtiquetaException | NullPointerException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }
            }

            //Muda visualização da workspace
            else if (action.equals("view")) {
                try {
                    if (request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //resgata id workspace clicada e tipo de visualização ativa
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));
                    String view = (String)request.getParameter("view");

                    //chama facade e retorna workspace
                    WorkspaceFacade wFacade = new WorkspaceFacade();
                    Workspace w = wFacade.buscarWorkspace(idWorkspace);

                    //visualização kanban
                    if (view.equals("kanban")) {
                        //chama facade e retorna lista de status
                        StatusFacade sFacade = new StatusFacade();
                        List<Status> status = sFacade.listarStatus(idWorkspace);

                        //chama facade e retorna lista de tarefas ativas e suas etiquetas
                        TarefaFacade tFacade = new TarefaFacade();
                        List<Tarefa> tarefas = tFacade.listarTarefasAtivas(idWorkspace);

                        EtiquetaFacade eFacade = new EtiquetaFacade();
                        for(Tarefa t: tarefas) {
                            t.setEtiquetas(eFacade.etiquetasTarefa(t.getIdTarefa()));
                        }

                        //lista de tarefas concluidas e suas etiquetas
                        List<Tarefa> tarefasConcluidas = tFacade.listarTarefasConcluidas(idWorkspace);
                        for(Tarefa t: tarefasConcluidas) {
                            t.setEtiquetas(eFacade.etiquetasTarefa(t.getIdTarefa()));
                        }

                        //seta atributos da requisição
                        request.setAttribute("status", status);
                        request.setAttribute("tarefas", tarefas);
                        request.setAttribute("concluidas", tarefasConcluidas);

                    //visualização tabela
                    } else if (view.equals("table")){
                        //chama facade e retorna lista de tarefas
                        TarefaFacade tFacade = new TarefaFacade();
                        List<Tarefa> tarefas = tFacade.listarTarefas(idWorkspace);
                        //seta etiquetas de cada tarefa
                        EtiquetaFacade eFacade = new EtiquetaFacade();
                        for(Tarefa t: tarefas) {
                            t.setEtiquetas(eFacade.etiquetasTarefa(t.getIdTarefa()));
                        }

                        StatusFacade sFacade = new StatusFacade();
                        Status s = sFacade.buscarOrdem(idWorkspace);
                        //seta atributos da requisição
                        request.setAttribute("tarefas", tarefas);
                        request.setAttribute("status", s);

                    //visualização calendário
                    } else if (view.equals("calendar")) {
                        //chama facade e retorna lista de tarefas
                        TarefaFacade tFacade = new TarefaFacade();
                        List<Tarefa> tarefas = tFacade.tarefasCalendario(idWorkspace);

                        StatusFacade sFacade = new StatusFacade();
                        Status s = sFacade.buscarOrdem(idWorkspace);//setta status
                        request.setAttribute("status", s);
                        
                        //seta etiquetas de cada tarefa
                        EtiquetaFacade eFacade = new EtiquetaFacade();
                        for (Tarefa t : tarefas) {
                            t.setEtiquetas(eFacade.etiquetasTarefa(t.getIdTarefa()));
                        }

                        //seta atributos da requisição
                        request.setAttribute("tarefas", tarefas);

                        LocalDate today;
                        LocalDate firstOfNextMonth = null;
                        today = LocalDate.now();
                        if (request.getParameter("data") == null) {
                            today = LocalDate.now();//Recebe data atual
                        } else {
                            String datastr = request.getParameter("data");//formata data do request
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("uuuu-MM-dd");
                            LocalDate dataAux = LocalDate.parse(datastr, formatter);
                            if ("prox".equals(request.getParameter("mes"))) {//se estiver avançando no mês
                                today = dataAux.with(TemporalAdjusters.firstDayOfNextMonth());//recebe primeiro dia do mês seguinte
                            }
                            if ("ante".equals(request.getParameter("mes"))) {//se estiver retrocendendo no mês
                                today = dataAux.with(TemporalAdjusters.firstDayOfMonth());//recebe primeiro dia do mês
                                today = today.minusMonths(1);//retrocede 1 mês na data passada
                            }
                            request.setAttribute("dataAtual", today);

                        }

                        int mesAtual = today.getMonthValue();// recebe o valor do mês atual
                        request.setAttribute("mesAtual", mesAtual);//seta atributos da requisição
                        
                        Month mes=today.getMonth();//recebe o mes
                        int year=today.getYear();//rece o ano
                        
                        String mesAtualNome = mes.getDisplayName( TextStyle.FULL , Locale.ROOT ) ; //recebe nome do mês
                        switch(mesAtualNome){//Atualizando nome para português
                            case "January": mesAtualNome="Janeiro"; break;
                            case "February": mesAtualNome="Fevereiro"; break;
                            case "March": mesAtualNome="Março"; break;
                            case "April": mesAtualNome="Abril"; break;
                            case "May": mesAtualNome="Maio"; break;
                            case "June": mesAtualNome="Junho"; break;
                            case "July": mesAtualNome="Julho"; break;
                            case "August": mesAtualNome="Agosto"; break;
                            case "September": mesAtualNome="Setembro"; break;
                            case "October": mesAtualNome="Outubro"; break;
                            case "November": mesAtualNome="Novembro"; break;
                            case "December": mesAtualNome="Dezembro"; break;
                        }
                        request.setAttribute("mesAtualNome", mesAtualNome);//seta atributos da requisição
                        request.setAttribute("anoAtual", year);//seta atributos da requisição

                        int ultimoDia = today.lengthOfMonth();//recebe o valor do último dia do mês
                        request.setAttribute("ultimoDia", ultimoDia);//seta atributos da requisição

                        DayOfWeek diaSemanaInicio = today.withDayOfMonth(1).getDayOfWeek();//recebe dia da semana do 1° dia do mes
                        int diaSemanaInicioV = diaSemanaInicio.getValue(); //recebe valor do dia da semana
                        request.setAttribute("diaSemanaInicio", diaSemanaInicioV);//seta atributos da requisição

                        DayOfWeek diaSemanaFim = today.withDayOfMonth(today.lengthOfMonth()).getDayOfWeek();//recebe dia da semana do último dia do mes
                        int diaSemanaFimV = diaSemanaFim.getValue(); //recebe valor do dia da semana
                        request.setAttribute("diaSemanaFim", diaSemanaFimV);//seta atributos da requisição

                        request.setAttribute("idWorkspace", idWorkspace);//seta atributos da requisição
                    } else throw new NullPointerException("Invocação inválida = tipo de transação incorreta");

                    LocalDate hoje = LocalDate.now();

                    //seta workspace e view type na requisição
                    request.setAttribute("workspace", w);
                    request.setAttribute("view", view);
                    request.setAttribute("hoje", hoje);

                    //Envia requisição para workspace.jsp
                    RequestDispatcher rd = request.getRequestDispatcher("workspace.jsp");//redireciona a página
                    rd.forward(request, response);

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para busca inválido= " + request.getParameter("idWorkspace"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (NullPointerException | DAOException | WorkspaceException | StatusException | EtiquetaException | TarefaException e) {
                    request.setAttribute("javax.servlet.jsp.jspException",e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }
            } 
            
            else if (action.equals("listWorkspaces")) {
                // listar workspaces para gerar gráficos de produtividade
                try { 
                    // chama método da facade para listar workspaces do usuario
                    WorkspaceFacade facade =  new WorkspaceFacade();
                    List<Workspace> listaWorkspaces = facade.listarWorkspaces(u);
     
                    // envia a lista de workspaces na resposta da requisição
                    request.setAttribute("listaWorkspaces", listaWorkspaces);
                    
                    // redireciona o usuário para a página de gráficos de produtividade
                    RequestDispatcher rd = request.getRequestDispatcher("/workspaceDashboard.jsp");
                    rd.forward(request, response);
                    
                } catch (WorkspaceException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            
            }
            
            else if (action.equals("listStatistics")) {
                // listar estatísticas de produtividade da workspace selecionada pelo usuario
                
                // resgata o id da workspace selecionada pelo usuario, passado por parâmetro na requisição 
                String idWorkspace = request.getParameter("idWorkspace");
                // verifica se o id não é nulo
                if (idWorkspace == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                // se o id não for nulo
                try {
                    // chama método da facade para buscar os dados da workspace
                    WorkspaceFacade facade =  new WorkspaceFacade();
                    Workspace workspace = facade.buscarWorkspace(Long.parseLong(idWorkspace));
                    
                    // chama método da facade para listar estatísticas
                    Gson gson = new Gson();
                    response.setContentType("application/json");
                    PrintWriter out = response.getWriter();
                    out.println(gson.toJson(WorkspaceFacade.listarEstatisticas(workspace)));
                    
                } catch(WorkspaceException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            
            }
            
            else if(action.equals("drawChartProdutividadeSemanal")) {
                // gráfico de tarefas concluídas diariamente nos últimos sete dias
                
                // resgata o id da workspace selecionada pelo usuario, passado por parâmetro na requisição 
                String idWorkspace = request.getParameter("idWorkspace");
                // verifica se o id não é nulo
                if (idWorkspace == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                // se o id não for nulo
                try {
                    // chama método da facade para buscar os dados da workspace
                    WorkspaceFacade facade =  new WorkspaceFacade();
                    Workspace workspace = facade.buscarWorkspace(Long.parseLong(idWorkspace));
                    
                    // chama método da facade para listar dados para o gráfico
                    Gson gson = new Gson();
                    response.setContentType("application/json");
                    PrintWriter out = response.getWriter();
                    out.println(gson.toJson(WorkspaceFacade.gerarGraficoProdutividadeSemanal(workspace)));
                    
                } catch(WorkspaceException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }
            
            else if(action.equals("drawChartMediaDiasAteConclusao")) {
                // gráfico de média de dias até a conclusão de tarefas por periodo
                
                // resgata o id da workspace selecionada pelo usuario, passado por parâmetro na requisição 
                String idWorkspace = request.getParameter("idWorkspace");
                // verifica se o id não é nulo
                if (idWorkspace == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                // se o id não for nulo
                try {
                    // chama método da facade para buscar os dados da workspace
                    WorkspaceFacade facade =  new WorkspaceFacade();
                    Workspace workspace = facade.buscarWorkspace(Long.parseLong(idWorkspace));
                    
                    // chama método da facade para listar dados para o gráfico
                    Gson gson = new Gson();
                    response.setContentType("application/json");
                    PrintWriter out = response.getWriter();
                    out.println(gson.toJson(WorkspaceFacade.gerarGraficoMediaDiasAteConclusao(workspace)));
                    
                } catch(WorkspaceException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }
            
            else if(action.equals("drawChartRelacaoTarefas")) {
                // gráfico de relação entre tarefas concluídas e não concluídas
                
                // resgata o id da workspace selecionada pelo usuario, passado por parâmetro na requisição 
                String idWorkspace = request.getParameter("idWorkspace");
                // verifica se o id não é nulo
                if (idWorkspace == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                // se o id não for nulo
                try {
                    // chama método da facade para buscar os dados da workspace
                    WorkspaceFacade facade =  new WorkspaceFacade();
                    Workspace workspace = facade.buscarWorkspace(Long.parseLong(idWorkspace));
                    
                    // chama método da facade para listar dados para o gráfico
                    Gson gson = new Gson();
                    response.setContentType("application/json");
                    PrintWriter out = response.getWriter();
                    out.println(gson.toJson(WorkspaceFacade.gerarGraficoRelacaoTarefas(workspace)));
                    
                } catch(WorkspaceException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }
            
            else if(action.equals("drawChartTarefasAbertasPorStatus")) {
                // gráfico de tarefas não concluídas por status
                
                // resgata o id da workspace selecionada pelo usuario, passado por parâmetro na requisição 
                String idWorkspace = request.getParameter("idWorkspace");
                // verifica se o id não é nulo
                if (idWorkspace == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                // se o id não for nulo
                try {
                    // chama método da facade para buscar os dados da workspace
                    WorkspaceFacade facade =  new WorkspaceFacade();
                    Workspace workspace = facade.buscarWorkspace(Long.parseLong(idWorkspace));
                    
                    // chama método da facade para listar dados para o gráfico
                    Gson gson = new Gson();
                    response.setContentType("application/json");
                    PrintWriter out = response.getWriter();
                    out.println(gson.toJson(WorkspaceFacade.gerarGraficoTarefasAbertasPorStatus(workspace)));
                    
                } catch(WorkspaceException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }

            else {
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                request.setAttribute("msg", "ERRO: Invocação inválida");
                rd.forward(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
