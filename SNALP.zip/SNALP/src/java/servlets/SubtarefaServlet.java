package servlets;

import beans.Subtarefa;
import beans.Usuario;
import com.google.gson.Gson;
import exception.DAOException;
import exception.SubtarefaException;
import facade.SubtarefaFacade;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "SubtarefaServlet", urlPatterns = {"/SubtarefaServlet"})
public class SubtarefaServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        
        //resgata sessão
        HttpSession session = request.getSession();
        Usuario u = (Usuario) session.getAttribute("logado");
        String action = (String) request.getParameter("action");    //ação que será realizada e é passada por parametro
        
        if (session.getAttribute("logado") == null) {
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
            request.setAttribute("mensagem", "Realize o seu login para acessar o SNALP!");
            rd.forward(request, response);
            
        } else {
            if (action.equals("new")){
                try{
                    String desc = request.getParameter("subtarefa");
                    long idTarefa = Long.parseLong(request.getParameter("idTarefa"));

                    SubtarefaFacade facade = new SubtarefaFacade();
                    Subtarefa s = new Subtarefa(desc);

                    Subtarefa s2 = facade.criarSubtarefa(s, idTarefa);

                    String json = new Gson().toJson(s2);

                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json);

                } catch (DAOException | SubtarefaException | NumberFormatException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }
            }

            else if (action.equals("update")){
                try{
                    String desc = request.getParameter("desc");
                    long idSubtarefa = Long.parseLong(request.getParameter("idSubtarefa"));

                    SubtarefaFacade facade = new SubtarefaFacade();
                    Subtarefa s = new Subtarefa(idSubtarefa,desc);

                    facade.atualizarSubtarefa(s);

                    String json = new Gson().toJson(s);

                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json);

                } catch (DAOException | SubtarefaException | NumberFormatException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }
            }

            else if (action.equals("delete")) {
                try {
                    long idSubtarefa = Long.parseLong(request.getParameter("idSubtarefa"));
                    long idTarefa = Long.parseLong(request.getParameter("idTarefa"));

                    SubtarefaFacade facade = new SubtarefaFacade();
                    facade.removerSubtarefa(idSubtarefa);

                    List<Subtarefa> subtarefas = facade.listarSubtarefas(idTarefa);

                    String json = new Gson().toJson(subtarefas);

                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json);

                } catch (DAOException | SubtarefaException | NumberFormatException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }
            }

            else if(action.equals("complete")){
                try {
                    long idSubtarefa = Long.parseLong(request.getParameter("idSubtarefa"));
                    boolean estado = Boolean.parseBoolean(request.getParameter("estado"));

                    SubtarefaFacade facade = new SubtarefaFacade();
                    facade.completarSubtarefa(idSubtarefa, estado);

                    String json = new Gson().toJson(estado);

                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json);

                } catch (DAOException | SubtarefaException | NumberFormatException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }
            }

            else {
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                request.setAttribute("msg", "ERRO: Invocação inválida");
                rd.forward(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
