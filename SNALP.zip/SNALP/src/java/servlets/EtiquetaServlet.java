package servlets;

import beans.Etiqueta;
import beans.Usuario;
import com.google.gson.Gson;
import exception.DAOException;
import exception.EtiquetaException;
import facade.EtiquetaFacade;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "EtiquetaServlet", urlPatterns = {"/EtiquetaServlet"})
public class EtiquetaServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
       //resgata sessão
        HttpSession session = request.getSession();
        Usuario u = (Usuario) session.getAttribute("logado");
        
        String action = (String) request.getParameter("action");    //ação que será realizada e é passada por parametro
        
        if (session.getAttribute("logado") == null) {
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
            request.setAttribute("mensagem", "Realize o seu login para acessar o SNALP!");
            rd.forward(request, response);
            
        } else {
            if (action.equals("formNew")){

                try {

                    // lista cores para o color picker de etiqueta
                    List<String> listaCores = EtiquetaFacade.listarCores();
                    // envia a lista de cores na resposta da requisição
                    request.setAttribute("listaCores", listaCores);

                    //redireciona usuário ao formulario contido no workspaceConfigForm.jsp
                    request.setAttribute("type", "newTag");
                    RequestDispatcher rd = request.getRequestDispatcher("/workspaceConfigForm.jsp");
                    rd.forward(request, response);

                } catch(DAOException | EtiquetaException e) {
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }

            }

            else if (action.equals("new")){
                try{
                    //Resgata valores dos campos preenchidos no formulário
                    String titulo = (String) request.getParameter("titulo");
                    String cor = (String) request.getParameter("cor");

                    //resgata id da workspace
                    if (request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata id da workspace a ser removida
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));

                    //Instanciação da nova etiqueta
                    Etiqueta tag = new Etiqueta(titulo,cor);

                    //Chama facade para inserir etiqueta na base de dados
                    EtiquetaFacade facade =  new EtiquetaFacade();
                    facade.criarEtiqueta(tag,idWorkspace);

                    //Redireciona usuario para pagina de configuracoes workspace
                    response.sendRedirect(request.getContextPath() + "/WorkspaceServlet?action=config&idWorkspace="+idWorkspace);

                } catch(DAOException | EtiquetaException e) {
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }
            }

            else if (action.equals("formUpdate")){
                try {
                    if (request.getParameter("idEtiqueta") == null || request.getParameter("idEtiqueta").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata id da etiqueta passado por parametro na requisição
                    long id = Long.parseLong(request.getParameter("idEtiqueta"));

                    //Busca os dados da etiqueta na base de dados
                    EtiquetaFacade facade = new EtiquetaFacade();
                    Etiqueta tag = facade.buscarEtiqueta(id);

                    //Envia objeto Etiqueta na resposta da requisição
                    request.setAttribute("etiqueta", tag);
                    //Define o tipo do formulario para a workspaceConfigForm.jsp carregar os dados
                    request.setAttribute("type", "updateTag");

                    // lista cores para o color picker de etiqueta
                    List<String> listaCores = EtiquetaFacade.listarCores();
                    // envia a lista de cores na resposta da requisição
                    request.setAttribute("listaCores", listaCores);

                    //Envia requisição para a workspaceConfigForm.jsp
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/workspaceConfigForm.jsp");
                    rd.forward(request, response);

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id da etiqueta inválido= " + request.getParameter("id"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (NullPointerException | DAOException | EtiquetaException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            }

            else if (action.equals("update")){
                try{
                    if (request.getParameter("idEtiqueta") == null || request.getParameter("idEtiqueta").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata valores dos campos do formulário e id da etiqueta
                    long id = Long.parseLong(request.getParameter("idEtiqueta"));
                    String titulo = (String) request.getParameter("titulo");
                    String cor = (String) request.getParameter("cor");

                     //resgata id da workspace
                    if (request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata id da workspace a ser removida
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));

                    //Instancia etiqueta e chama método da facade para atualizar registro
                    EtiquetaFacade facade = new EtiquetaFacade();
                    Etiqueta tag = new Etiqueta(id,titulo,cor);
                    facade.atualizarEtiqueta(tag);

                    //Redireciona usuario para pagina de configuracoes workspace
                    response.sendRedirect(request.getContextPath() + "/WorkspaceServlet?action=config&idWorkspace="+idWorkspace);

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para atualização inválido= " + request.getParameter("id"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (NullPointerException | DAOException | EtiquetaException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }

            else if (action.equals("delete")){
                try{
                    if (request.getParameter("idEtiqueta") == null || request.getParameter("idEtiqueta").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata id do status a ser removido
                    long id = Long.parseLong(request.getParameter("idEtiqueta"));

                     //resgata id da workspace
                    if (request.getParameter("idWorkspace") == null || request.getParameter("idWorkspace").isEmpty()) {
                        throw new NullPointerException("Invocação inválida = id é nulo");
                    }

                    //Resgata id da workspace a ser removida
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));

                    //Executa método facade para chamada de remoção do status
                    EtiquetaFacade facade = new EtiquetaFacade();
                    facade.removerEtiqueta(id);
                    List<Etiqueta> etiquetas = facade.listarEtiquetas(idWorkspace);

                    //cria json de retorno
                    String json = new Gson().toJson(etiquetas);

                    //insere json na resposta da requisição
                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json);

                } catch (NumberFormatException e) {
                    request.setAttribute("erro", "Id para remoção inválido= " + request.getParameter("id"));
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                } catch (NullPointerException | DAOException | EtiquetaException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = getServletContext().getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
            }

            else if (action.equals("list")){
                try {
                    //resgata idTarefa da requisição
                    long idTarefa = Long.parseLong(request.getParameter("idTarefa"));

                    //resgata lista de etiquetas da tarefa
                    EtiquetaFacade facade = new EtiquetaFacade();
                    List<Etiqueta> etiquetas = facade.etiquetasTarefa(idTarefa);

                    //cria json de retorno
                    String json = new Gson().toJson(etiquetas);

                    //insere json na resposta da requisição
                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json);

                } catch (DAOException | EtiquetaException | NumberFormatException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }
            }

            else if (action.equals("insert")) {
                try {
                    //resgata idTarefa da requisição
                    long idTarefa = Long.parseLong(request.getParameter("idTarefa"));
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));
                    long idEtiqueta = Long.parseLong(request.getParameter("idEtiqueta"));

                    //Facade Etiqueta
                    EtiquetaFacade facade = new EtiquetaFacade();
                    //atribuição da etiqueta na tarefa
                    facade.atribuirEtiqueta(idTarefa, idEtiqueta);
                    //resgata lista de etiquetas da tarefa
                    List<Etiqueta> etiquetas = facade.etiquetasTarefa(idTarefa);
                    List<Etiqueta> disponiveis = facade.etiquetasDisponiveis(idTarefa, idWorkspace);

                    //cria json de retorno
                    String json1 = new Gson().toJson(etiquetas);
                    String json2 = new Gson().toJson(disponiveis);
                    String json = "["+json1+","+json2+"]";

                    //insere json na resposta da requisição
                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json);

                } catch (DAOException | EtiquetaException | NumberFormatException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }
            }

            else if (action.equals("remove")) {
                try {
                    //resgata idTarefa da requisição
                    long idTarefa = Long.parseLong(request.getParameter("idTarefa"));
                    long idWorkspace = Long.parseLong(request.getParameter("idWorkspace"));
                    long idEtiqueta = Long.parseLong(request.getParameter("idEtiqueta"));

                    //Facade Etiqueta
                    EtiquetaFacade facade = new EtiquetaFacade();
                    //atribuição da etiqueta na tarefa
                    facade.retirarEtiqueta(idTarefa, idEtiqueta);
                    //resgata lista de etiquetas da tarefa
                    List<Etiqueta> etiquetas = facade.etiquetasTarefa(idTarefa);
                    List<Etiqueta> disponiveis = facade.etiquetasDisponiveis(idTarefa, idWorkspace);

                    //cria json de retorno
                    String json1 = new Gson().toJson(etiquetas);
                    String json2 = new Gson().toJson(disponiveis);
                    String json = "["+json1+","+json2+"]";

                    //insere json na resposta da requisição
                    response.setContentType("application/json");
                    response.setCharacterEncoding("UTF-8");
                    response.getWriter().write(json);

                } catch (DAOException | EtiquetaException | NumberFormatException e){
                    request.setAttribute("javax.servlet.jsp.jspException", e);
                    request.setAttribute("javax.servlet.error.status_code", 500);
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);

                }
            }

            else {
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                request.setAttribute("msg", "ERRO: Invocação inválida");
                rd.forward(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
