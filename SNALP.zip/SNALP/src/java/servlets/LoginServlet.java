/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import beans.Usuario;
import exception.DAOException;
import exception.UsuarioException;
import exception.WorkspaceException;
import facade.LoginFacade;
import facade.WorkspaceFacade;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author eduar
 */
@WebServlet(name = "LoginServlet", urlPatterns = {"/LoginServlet"})
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        try {

            //recebe os parametros de email e senha para login
            String email = request.getParameter("email");
            String senha = request.getParameter("senha");

            HttpSession session = request.getSession();//Cria uma sessão
            session.setMaxInactiveInterval(10800);//Indica o tempo da sessão como 3 horas  
            Usuario login = LoginFacade.realizarLogin(email, senha);//Cria um bean com o resultado da pesquisa com o email e senha
            WorkspaceFacade wf = new WorkspaceFacade();//Infica facade do workspace
            login.setWorkspaces(wf.listarWorkspaces(login));//atribui workspaces do usuario
            if (login.getWorkspaces().isEmpty())//Se a lista de workspaces é vazia, deixa nulo
            {
                login.setWorkspaces(null);
            }
            session.setAttribute("logado", login);//coloca o bean do usuario na sessão
            RequestDispatcher rd = request.getRequestDispatcher("UsuarioServlet?action=showHome");//Redireciona a workspaces
            rd.forward(request, response);

        } catch (SQLException | UsuarioException ex) {

            request.setAttribute("mensagem", ex.getMessage());// Armazena a mensagem de erro na requisição
            RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
            rd.forward(request, response);
        } catch (WorkspaceException | DAOException ex) {
            request.setAttribute("javax.servlet.jsp.jspException", ex);
            request.setAttribute("javax.servlet.error.status_code", 500);
            RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
            rd.forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
