package servlets;

import beans.Atividade;
import beans.Categoria;
import beans.Usuario;
import com.google.gson.Gson;
import exception.AtividadeException;
import exception.CategoriaException;
import exception.DAOException;
import facade.AtividadeFacade;
import facade.CategoriaFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "AtividadeServlet", urlPatterns = {"/AtividadeServlet"})
public class AtividadeServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("logado");
        String action = (String) request.getParameter("action");
        
        if (session.getAttribute("logado") == null) {
            RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
            request.setAttribute("mensagem", "Realize o seu login para acessar o SNALP!");
            rd.forward(request, response);
            
        } else {
        
            if (action == null){
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                request.setAttribute("mensagem", "Ação não encontrada, tente novamente!");
                rd.forward(request, response);
                
            } else if (action.equals("show")) {
                // buscar dados de uma atividade: aplicação nos gráficos
                
                // resgata o id da atividade, passado por parâmetro na requisição
                String idAtividade = request.getParameter("idAtividade");
                if (idAtividade == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                try {
                    Gson gson = new Gson();
                    response.setContentType("application/json");
                    PrintWriter out = response.getWriter();
                    out.println(gson.toJson(AtividadeFacade.buscarAtividade(Long.parseLong(idAtividade))));
                
                } catch (AtividadeException | CategoriaException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if(action.equals("formNew")) {
                // resgata o id da categoria cujo botão "+Atividade" foi clicado, passado por parâmetro (para pré selecionar a categoria no dropdown do formulário)
                String idCategoria = request.getParameter("idCategoria");
                if (idCategoria == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }  
                try {
                    // envia a id da categoria na resposta da requisição
                    request.setAttribute("idCategoria", idCategoria);

                    // resgata lista de categorias de atividades do usuário
                    List<Categoria> listaCategorias = CategoriaFacade.listarCategorias(usuario);
                    // envia a lista de categorias na resposta da requisição
                    request.setAttribute("listaCategorias", listaCategorias);

                    // redireciona o usuário para o formulário de inserção de nova atividade
                    RequestDispatcher rd = request.getRequestDispatcher("/atividadeForm.jsp");
                    rd.forward(request, response);

                } catch (AtividadeException | CategoriaException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if (action.equals("new")) {
                // inserir nova atividade
                try {
                    // instancia nova atividade
                    Atividade atividade = new Atividade();

                    // resgata o id da categoria selecionada no formulário, passado por parâmetro
                    long idCategoria = Long.parseLong(request.getParameter("categoriaAtividade"));
                    // chama método da facade para buscar os dados da categoria e seta o atributo categoria na atividade
                    atividade.setCategoriaAtividade(CategoriaFacade.buscarCategoria(idCategoria));

                    // reagata a descrição da nova atividade, passada por parâmetro e seta o atributo descrição na atividade 
                    atividade.setDescricaoAtividade(request.getParameter("descricaoAtividade"));

                    // chama o método da facade para criar a nova atividade
                    AtividadeFacade.criarAtividade(atividade);

                    // redireciona o usuário para a página de configuração do mood tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/MoodTrackerServlet?action=listConfig");
                    rd.forward(request, response);

                } catch (AtividadeException | CategoriaException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }  

            } else if (action.equals("formUpdate")) {
                // formulário para alterar atividade

                // resgata o id da atividade, passado por parâmetro na requisição
                String idAtividade = request.getParameter("idAtividade");
                if (idAtividade == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                } 
                try {
                    // resgata os dados da atividade, passando idAtividade como parâmetro
                    Atividade atividade = AtividadeFacade.buscarAtividade(Long.parseLong(idAtividade));

                    // envia o objeto atividade na resposta da requisição
                    request.setAttribute("atividade", atividade);
                    // envia a id da categoria na resposta da requisição, para deixar a comparação existente na seleção do dropdown mais limpa
                    request.setAttribute("idCategoria", atividade.getCategoriaAtividade().getIdCategoria());
                    // define o tipo do formulario como update
                    request.setAttribute("type", "update");

                    // resgata lista de categorias de atividades do usuário
                    List<Categoria> listaCategorias = CategoriaFacade.listarCategorias(usuario);
                    // envia a lista de categorias na resposta da requisição
                    request.setAttribute("listaCategorias", listaCategorias);

                    // redireciona o usuário para o formulário de alteração de atividade
                    RequestDispatcher rd = request.getRequestDispatcher("/atividadeForm.jsp");
                    rd.forward(request, response);

                } catch (AtividadeException | CategoriaException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if (action.equals("update")) {
                // alterar atividade

                // resgata o id da atividade, passado por parâmetro na requisição
                String idAtividade = request.getParameter("idAtividade");
                if (idAtividade == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                try {
                    // instancia nova atividade
                    Atividade atividade = new Atividade();

                    // resgata o id da categoria selecionada no formulário, passado por parâmetro
                    long idCategoria = Long.parseLong(request.getParameter("categoriaAtividade"));
                    // chama método da facade para buscar os dados da categoria e seta o atributo categoria na atividade
                    atividade.setCategoriaAtividade(CategoriaFacade.buscarCategoria(idCategoria));

                    // reagata o id e a nova descrição da atividade, passados por parâmetro e seta os atributos id e descrição na atividade
                    atividade.setIdAtividade(Long.parseLong(idAtividade));
                    atividade.setDescricaoAtividade(request.getParameter("descricaoAtividade"));

                    // chama o método da facade para atualiza a atividade
                    AtividadeFacade.atualizarAtividade(atividade);

                    // redireciona o usuário para a página de configuração do mood tracker
                    RequestDispatcher rd = request.getRequestDispatcher("/MoodTrackerServlet?action=listConfig");
                    rd.forward(request, response);
                } catch (AtividadeException | CategoriaException | DAOException e) {
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else if (action.equals("delete")) {
                // remover atividade == inativar atividade
                String idAtividade = request.getParameter("idAtividade");
                if (idAtividade == null) {
                    request.setAttribute("mensagem", "Invocação inválida: id é nulo...");
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }
                try {
                    AtividadeFacade.removerAtividade(Long.parseLong(idAtividade));
                    RequestDispatcher rd = request.getRequestDispatcher("/MoodTrackerServlet?action=listConfig");
                    rd.forward(request, response);
                } catch(AtividadeException | DAOException e){
                    request.setAttribute("mensagem", "ERRO: " + e.getMessage());
                    RequestDispatcher rd = request.getRequestDispatcher("/erro.jsp");
                    rd.forward(request, response);
                }

            } else {
                RequestDispatcher rd = getServletContext().getRequestDispatcher("/index.jsp");
                request.setAttribute("mensagem", "Ação não encontrada, tente novamente!");
                rd.forward(request, response);
            }
            
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
