$(document).on("change", ".selectPeriodo", function () {

    var idPeriodo = $(".selectPeriodo option:selected").val();
    
    if(idPeriodo === '0') {
        $('.diaria').show();    // ativa a visualização do container de estatísticas gerais diária
        $('.semanal').hide();   // desativa a visualização do container de estatísticas gerais semanal
        $('.mensal').hide();    // desativa a visualização do container de estatísticas gerais mensal
    }
    
    else if(idPeriodo === '1') {
        $('.diaria').hide();    // desativa a visualização do container de estatísticas gerais diária
        $('.semanal').show();   // ativa a visualização do container de estatísticas gerais semanal
        $('.mensal').hide() ;   // desativa a visualização do container de estatísticas gerais mensal
    }
    
    else if(idPeriodo === '2') {
        $('.diaria').hide();    // desativa a visualização do container de estatísticas gerais diária
        $('.semanal').hide();   // desativa a visualização do container de estatísticas gerais semanal
        $('.mensal').show();    // ativa a visualização do container de estatísticas gerais mensal
    }
    
});