var relogio;
var auxTitulo;

function diminuiTempo(tempo) {//função para alterar o tempo do relógio

    if (window.sessionStorage.getItem("ativo") == "1") {

        relogio = setTimeout(function () {//Função que se repete a cada 1 segundo
            tempoRelogio = "";//var auxiliar da formatação do tempo
            
            tempoRelogio = formataTempo(tempo);//recebe tempo formatado
            
            //declaração dos aúdios utilizados
            const audioSequencia = document.getElementById('audioSequencia');
            const audioFinal = document.getElementById('audioFinal');

            document.getElementById("valorRelogio").innerHTML = tempoRelogio;//atualiza o elemento html com os valores do relogio
            document.title = tempoRelogio + " - Pomodoro";//atualiza título da página

            ativo = window.sessionStorage.getItem("ativo");//recebe varíavel se está ativo para continuar ou cancelar função


            if ((tempo--) > 0 && window.sessionStorage.getItem("ativo") == "1") {//se o relógio ainda estiver rodando

                window.sessionStorage.setItem("ValorRelogio", tempo);//guarda seu valor na sessão
                document.getElementById("inputValor").value = window.sessionStorage.getItem("inputTempo") / 60;//atualiza input
                document.getElementById("inputPausa").value = window.sessionStorage.getItem("inputPausa") / 60;//atualiza input
                document.getElementById("inputSerie").value = window.sessionStorage.getItem("serieTotal") / 2;//atualiza input
                document.getElementById("iniciar").innerHTML = "Pausar";//atualiza botao
                
                if (auxTitulo != null) document.getElementById("atual").innerHTML=auxTitulo;
                else if (window.sessionStorage.getItem("titulo") != null && window.sessionStorage.getItem("titulo") != 'null') //verifica se o titulo do relógio foi registrado
                    document.getElementById("atual").innerHTML = window.sessionStorage.getItem("titulo");//atualiza html com o titulo
                else
                    document.getElementById("atual").innerHTML = "Pomodoro";

                diminuiTempo(tempo);//chama a função novamente para continuar contando

            } else {//se o relógio já houver terminado ou estiver pausado

                if (tempo <= 0) { //se terminou

                    document.getElementById("iniciar").innerHTML = "Iniciar";//atualiza botao

                    window.sessionStorage.removeItem("ValorRelogio");//remove o valor do relógio da sessão
                    var sA = parseInt(window.sessionStorage.getItem("serieAtual"));//recebe serie atual
                    var sT = parseInt(window.sessionStorage.getItem("serieTotal"));//recebe serie total
                    var pausa = parseInt(window.sessionStorage.getItem("inputPausa"));//recebe o valor da pausa
                    var tempoTotal = parseInt(window.sessionStorage.getItem("inputTempo"));//recebe o valor do tempo
                    window.sessionStorage.setItem("serieAtual", sA + 1);//atualiza serie atual

                    if (sA < sT - 1) { //Se ainda não estiver na serie final

                        var tempoRelogioPausa = "";
                        var tipo = "";
                        var cor = "";

                        if (sA % 2 == 0) { //se estiver em um relógio normal ( não pausa)

                            tempoRelogioPausa = pausa;//passa o valor da pausa para a aux
                            tipo = "Pausa";//declara o tipo do relógio
                            cor = "#69db89";//declara a cor do relógio
                        } else {  //se estiver em uma pausa (não relógio normal)
                            tempoRelogioPausa = tempoTotal;//passa o valor do relogio normal para a aux
                            tipo = "Foco";//declara o tipo do relógio
                            cor = "#69a4db";//declara a cor do relógio
                        }

                        window.sessionStorage.setItem("ValorRelogio", tempoRelogioPausa);//atualiza valor do relógio
                        var titulo = window.sessionStorage.getItem("titulo");//atualiza título 
                        document.getElementById("relogioTipo").innerHTML = tipo;//atualiza tipo no html
                        if (titulo != null && titulo != 'null')
                            document.getElementById("atual").innerHTML = titulo;//atualiza título no html
                        else
                            document.getElementById("atual").innerHTML = "Pomodoro";//atualiza título no html
                        document.getElementById("cborder").style.borderColor = cor;//atualiza cor do relógio 
                        audioSequencia.play();//toca aúdio de fim de sequência
                        diminuiTempo(tempoRelogioPausa);//chama a função para atualizar valor do relógio ou pausa
                    } else {// se for a última serie de todo o ciclo do relógio
                        audioFinal.play();//toca aúdio final
                        
                        //recebe valores para armazenar no log
                        document.getElementById("tituloR").value = window.sessionStorage.getItem("titulo");
                        document.getElementById("tempoR").value = window.sessionStorage.getItem("inputTempo");
                        document.getElementById("pausaR").value = window.sessionStorage.getItem("inputPausa");
                        document.getElementById("serieR").value = window.sessionStorage.getItem("serieTotal");


                        window.sessionStorage.setItem("serieAtual", "0"); //reinicia a serieAtual
                        window.sessionStorage.setItem("ativo", "0");//guarda como desligado na sessão
                        window.sessionStorage.setItem("ValorRelogio", null);//guarda como desligado na sessão
                        window.sessionStorage.removeItem("ValorRelogio");//remove item da sessão
                        document.getElementById("valorRelogio").innerHTML = "00:00";//atualiza relógio
                        window.sessionStorage.removeItem("titulo");//remove título da sessao

                        clearInterval(relogio);//finaliza chamada recursiva da função
                        setTimeout(function () {//função com delay para conseguir registrar o log e tocar aúdio final a tempo
                            document.getElementById("formLog").submit();
                        }, 1000);
                    }

                }//se pausa
                else {

                    window.sessionStorage.setItem("ativo", "0");//guarda como desligado na sessão
                    clearInterval(relogio);//finaliza chamada recursiva da função
                }
            }
        }, 1000);//repete a cada segundo
    }
}

function selectRelogio(titulo, tempo, pausa, serie) {
    clearTimeout(relogio);//finaliza chamada recursiva da função

    //atualiza variávies na sessão
    window.sessionStorage.setItem("ativo", "0");//guarda como desligado na sessão
    window.sessionStorage.setItem("inputTempo", parseInt(tempo * 60));//atualiza item na sessão
    window.sessionStorage.setItem("inputPausa", parseInt(pausa * 60));//atualiza item na sessão
    window.sessionStorage.setItem("serieTotal", parseInt(serie * 2));//atualiza item na sessão
    window.sessionStorage.setItem("serieAtual", 0);//Atualiza var do sessão, como serie inicial
    window.sessionStorage.setItem("titulo", titulo);//atualiza titulo do relógio

    //atualiza itens do html
    document.getElementById("iniciar").innerHTML = "Iniciar";//atualiza botão
    document.getElementById("relogioTipo").innerHTML = "Foco";
    document.getElementById("cborder").style.borderColor = "#69a4db";//atualiza cor do relógio
    document.getElementById("valorRelogio").innerHTML = tempo + ":00";//atualiza relógio no html
    document.getElementById("inputValor").value = tempo;//atualiza input no html
    document.getElementById("inputPausa").value = pausa;//atualiza input no html
    document.getElementById("inputSerie").value = serie;//atualiza input no html
    if (titulo != null && titulo != 'null'){ document.getElementById("atual").innerHTML = titulo;
    auxTitulo=titulo;}
    else document.getElementById("atual").innerHTML = "Pomodoro";

    setTimeout(function () {//função com delay para não sobreescrever relógio em paralelo
        window.sessionStorage.setItem("ativo", "0");//guarda como desligado na sessão
        document.getElementById("valorRelogio").innerHTML = tempo + ":00";//atualiza html
        window.sessionStorage.setItem("titulo", titulo);//atualiza titulo do relógio
        clearTimeout(relogio);//finaliza chamada recursiva da função
    }, 1000);//demora 1 segundo para executar

    window.sessionStorage.removeItem("ValorRelogio");//remove o item da sessão para não chamas a função recursiva 
}


function formataTempo(tempo) {//função para formatar o valor do relógio
    var minutos;
    var segundos;

    if (parseInt(tempo / 60, 10) < 10) //se os minutos forem menores que 10
        minutos = "0" + (parseInt(tempo / 60, 10)); //adiciona um 0 a frente
    else
        minutos = (parseInt(tempo / 60, 10));// atribui valor dos minutos

    if (parseInt(tempo % 60, 10) == 0) //caso os segundos sejam exatamente 00
        segundos = "00";//atrui o valor dos segundos
    else if (parseInt(tempo % 60, 10) < 10) //se os segundos forem menores que 10
        segundos = "0" + (parseInt(tempo % 60, 10));//adiciona um 0 a frente
    else
        segundos = (parseInt(tempo % 60, 10));//atrui o valor dos segundos

    return  (minutos + ":" + segundos);//retorna valor formatado
}

function atualizaSelecionado(id) {
    const aux = document.getElementsByClassName("relogioSelecionado");//seleciona elemento caso já tenha a classe
    const tamanho = document.getElementsByClassName("relogioSelecionado").length;//seleciona a qtd de itens com a classe
    for (i = 0; i < tamanho; i++) {//pervorre todos elementos com a classe
        aux[i].classList.remove('relogioSelecionado');//remove a classe de selecionados
    }
    const element = document.getElementById("pomodoro" + id);//seleciona elemento desejado
    element.classList.add('relogioSelecionado');//adiciona a classe no elemento desejado
}

