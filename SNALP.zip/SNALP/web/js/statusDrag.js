//inicializa eventos dos status
function initDragEventsStatus(status) {
    //evento de início
    status.addEventListener("dragstart", () => {
        status.classList.add("dragging");
    });
    //evento de fim + chamada de mudança de status
    status.addEventListener("dragend", (e) => {
        status.classList.remove("dragging");
        updateStatusOrder(e);
    });
}

//inicializa eventos dos status
function initDragEventsList(list){
    //evento de soltar tarefa dentro do status
    list.addEventListener('dragover',(e)=>{
       e.preventDefault();                                                      //cancela o evento caso o elemento arrastado não seja colocado na lista
       let draggingStatus = document.querySelector('.dragging');                  //seleciona tarefa que está sendo arrastada
       let statusAfterDraggingStatus = getStatusAfterDraggingStatus(list, e.clientX);   //recebe nova coordenada da tarefa
       if (statusAfterDraggingStatus){                                              //insere a tarefa na nova lista dependendo da posição
           statusAfterDraggingStatus.parentNode.insertBefore(draggingStatus,statusAfterDraggingStatus);
       } else {
           list.appendChild(draggingStatus);
       }                                        
   });
}

//retorna status seguinte do status sendo arrastado na lista
function getStatusAfterDraggingStatus(list,yDraggingStatus){                            //parametros lista e posição do status na lista
    let listStatus = [...list.querySelectorAll('.config-status:not(.dragging)')];       //todos os status da lista menos o status que está sendo arrastado
    
    return listStatus.reduce((closestStatus, nextStatus)=>{                             //aplica reduce na lista
        let nextStatusRect = nextStatus.getBoundingClientRect();                        //verifica tamanho e posição relativa do status
        let offset = yDraggingStatus - nextStatusRect.left - nextStatusRect.width/2;    //calcula posição offset
        
        if(offset < 0 && offset > closestStatus.offset){                                //condição se é a primeira posição
            return {offset, element: nextStatus };
        } else {                                                                        //caso contrário, retorna posição do status
            return closestStatus;
        }
    },{offset: Number.NEGATIVE_INFINITY}).element;                                      //controla a primeira posição da lista com um valor padrão de offset
}

//Realiza alteração da ordem dos status
function updateStatusOrder(e) {
    let dragged = e.target;                                             //status sendo arrastado
    let nextStatus = e.target.nextSibling;                              //status seguinte ao arrastado
    let prevStatus = e.target.previousElementSibling;                   //status anterior ao arrastado

    //se há apenas um status, não faz nada
    if (nextStatus === null && prevStatus === null) {
        return;
    }
    //se status foi colocado no início da lista
    else if (prevStatus === null && nextStatus !== null) {
        //se status foi colocado na mesma posição em que estava, mas estava no topo
        if (parseInt(nextStatus.getAttribute("data-ordem")) === parseInt(dragged.getAttribute("data-ordem")) + 1)
            return;
        //se status foi colocado no topo mas não é a mesma posição
        else
            orderChange(dragged.getAttribute("data-id"), dragged.getAttribute("data-ordem"), nextStatus.getAttribute("data-ordem"));
    }
    //se status foi colocado no final da lista
    else if (prevStatus !== null && nextStatus === null) {
        //se status foi colocado na mesma posição em que estava, mas estava no final da lista
        if (parseInt(prevStatus.getAttribute("data-ordem")) === parseInt(dragged.getAttribute("data-ordem")) - 1)
            return;
        //se status foi colocado no final mas não é a mesma posição
        else
            orderChange(dragged.getAttribute("data-id"), dragged.getAttribute("data-ordem"), prevStatus.getAttribute("data-ordem"));
    }
    //se status foi colocado em outras posições da lista
    else {
        //status colocado na mesma posição em que estava antes
        if (parseInt(prevStatus.getAttribute("data-ordem")) === parseInt(dragged.getAttribute("data-ordem")) - 1) {
            return;
            //se status subiu na lista
        } else if (parseInt(nextStatus.getAttribute("data-ordem")) < parseInt(dragged.getAttribute("data-ordem"))) {
            orderChange(dragged.getAttribute("data-id"), dragged.getAttribute("data-ordem"), nextStatus.getAttribute("data-ordem"));
            //se status  desceu na lista
        } else {
            orderChange(dragged.getAttribute("data-id"), dragged.getAttribute("data-ordem"), prevStatus.getAttribute("data-ordem"));
        }
    }
}

//Chamada ajax para persistência da alteração na ordem dos status
function orderChange(idStatus, oldOrdem, newOrdem){
    var action = "updateOrder";
    var idWorkspace = $("#idWorkspace").val();
    var idStatus = idStatus;
    var oldOrdem = oldOrdem;
    var newOrdem = newOrdem;
    var url = "/SNALP/StatusServlet";
    $.ajax({
        async: true,
        url: url,
        data: {
            action: action,
            idWorkspace: idWorkspace,
            idStatus: idStatus,
            oldOrdem: oldOrdem,
            newOrdem: newOrdem
        },
        dataType: 'json',
        success: function (data) {
            $("#status-list").empty();
            $.each(data, function(i, obj){
                const status = document.createElement('div');
                status.draggable = true;
                status.classList.add("config-status");
                status.style.backgroundColor = obj.cor;
                status.setAttribute("data-id",obj.idStatus);
                status.setAttribute("data-ordem",obj.ordem);
                
                status.innerHTML = '<label class="config-titulo">'+obj.titulo +'</label><div><button type="button" class="btnStatusUpdate btnedit" data-toggle="modal" data-bs-target="#modal-popup" data-id='+
                                    obj.idStatus +'><i class="bx bx-pencil"></i></button><button type="button" class="btnStatusDelete btndelete" data-toggle="modal" data-bs-target="#modal-popup" data-id='+ 
                                    obj.idStatus +' data-title='+ obj.titulo +' data-ordem='+ obj.ordem +'><i class="bx bx-trash"></i></button></div>';
                initDragEventsStatus(status);
                 $("#status-list").append(status);
            });
        },
        error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + request.statusText);
        }
    });
}

//inicializa eventos nos status
document.querySelectorAll('.config-status').forEach(initDragEventsStatus);   //todos os status que podem ser arrastados
document.querySelectorAll('.drag-list').forEach(initDragEventsList);        //lista de status