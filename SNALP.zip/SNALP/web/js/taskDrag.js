//Compara data atual e data de entrega passada por parametro
function dataComparison(data){
    var date = new Date();

    if(date.getFullYear() > data.year) return true;
    else if (date.getMonth()+1 > data.month) return true;
    else if (date.getMonth()+1 === data.month){
        if (date.getDate() > data.day) return true;
        else return false;
    }
    return false;
}

//inicializa eventos das tarefas
function initDragEventsTask(task) {
    //evento de início
    task.addEventListener("dragstart", () => {
        task.classList.add("dragging");
    });
    //evento de fim + chamada de mudança de status
    task.addEventListener("dragend", (e) => {
        task.classList.remove("dragging");
        updateTaskOrder(e);
    });
}

//inicializa eventos dos status
function initDragEventsList(list){
    //evento de soltar tarefa dentro do status
    list.addEventListener('dragenter', (e) => {
        e.preventDefault();
        var draggingTask = document.querySelector('.dragging');                                 //tarefa com classe dragging (classe de controle)
        var taskAfterDraggingTask = getTaskAfterDraggingTask(list, e.clientY);                  //tarefa seguinte da tarefa arrastada no novo status
        if (taskAfterDraggingTask) {                                                            //insere a tarefa na nova lista dependendo da posição
            taskAfterDraggingTask.parentNode.insertBefore(draggingTask, taskAfterDraggingTask);
        } else {
            list.appendChild(draggingTask);
        }
    });
}

//retorna tarefa seguinte da tarefa sendo arrastada no status
function getTaskAfterDraggingTask(list,yDraggingTask){                          //parametros lista e posição da tarefa na lista
    let listTasks = [...list.querySelectorAll('.task-box:not(.dragging)')];     //todas as tarefas da lista menos a tarefa que está sendo arrastada
    
    return listTasks.reduce((closestTask, nextTask)=>{                          //aplica reduce na lista
        let nextTaskRect = nextTask.getBoundingClientRect();                    //verifica tamanho e posição relativa da tarefa
        let offset = yDraggingTask - nextTaskRect.top - nextTaskRect.height/2;  //calcula posição offset
        
        if(offset < 0 && offset > closestTask.offset){                          //condição se é a primeira posição
            return {offset, element: nextTask };
        } else {                                                                //caso contrário, retorna posição da tarefa
            return closestTask;
        }
    },{offset: Number.NEGATIVE_INFINITY}).element;                              //controla a primeira posição da lista com um valor padrão de offset
}

//atualiza ordem da tarefa e chama funções que atualizam banco de dados e renderizam tarefas novamente na ordem correta
function updateTaskOrder (e) {
    let dragged = e.target;                                             //tarefa sendo arrastada
    let nextTask = e.target.previousElementSibling;                     //tarefa seguinte à arrastada
    let prevTask = e.target.nextSibling;                                //tarefa anterior à arrastada
    let newStatus = e.target.parentNode.getAttribute("data-status-id"); //status no qual a tarefa foi colocada
    
    //se novo status != status original
    if(dragged.getAttribute("data-task-status") !== newStatus){
        if (nextTask === null && prevTask === null){        //se status está vazio (não há tarefa anterior ou seguinte)
            changeStatus(dragged.getAttribute("data-task-status"),newStatus,dragged.getAttribute("data-task-order"),1,dragged.getAttribute("data-task-id"));
        }
        else if (nextTask === null && prevTask !== null) {  //se tarefa foi colocada no topo do status (não há tarefa seguinte)
            changeStatusEnd(dragged.getAttribute("data-task-status"),newStatus,dragged.getAttribute("data-task-order"),prevTask.getAttribute("data-task-order"),dragged.getAttribute("data-task-id"));
        }
        else {                                              //se tarefa foi colocada em outras posições do status
            changeStatus(dragged.getAttribute("data-task-status"),newStatus,dragged.getAttribute("data-task-order"),nextTask.getAttribute("data-task-order"),dragged.getAttribute("data-task-id"));
        }
    }
    //se novo status == status original
    else {
        //se status está vazio (não há tarefa anterior ou seguinte)
        if (nextTask === null && prevTask === null){        
            return;
        }
        //se tarefa foi colocada no topo do status (não há tarefa seguinte)
        else if (nextTask === null && prevTask !== null) {
            //se tarefa foi colocada na mesma posição em que estava, mas estava no topo
            if(parseInt(prevTask.getAttribute("data-task-order")) === parseInt(dragged.getAttribute("data-task-order")) - 1) return;
            //se tarefa foi colocada no topo mas não é a mesma posição
            else changeOrderUp(dragged.getAttribute("data-task-status"), dragged.getAttribute("data-task-order"),prevTask.getAttribute("data-task-order"), dragged.getAttribute("data-task-id"));
        }
        //se tarefa foi colocada em outras posições do status
        else { 
            //tarefas arrastadas e colocadas na mesma posição original
            if(parseInt(nextTask.getAttribute("data-task-order")) === parseInt(dragged.getAttribute("data-task-order")) + 1) {
                return;
            //se tarefa subiu no status
            } else if(parseInt(nextTask.getAttribute("data-task-order")) < parseInt(dragged.getAttribute("data-task-order"))) {
                changeOrderDown(dragged.getAttribute("data-task-status"), dragged.getAttribute("data-task-order"),nextTask.getAttribute("data-task-order"),dragged.getAttribute("data-task-id"));
            //se tarefa desceu no status
            } else {
                changeOrderUp(dragged.getAttribute("data-task-status"), dragged.getAttribute("data-task-order"),prevTask.getAttribute("data-task-order"),dragged.getAttribute("data-task-id"));
            }
        }
    }
}

//muda tarefa de status
function changeStatus (oldStatus, newStatus, oldOrdem, newOrdem, id){
    var type = "cs";
    var action = "change";
    var oldStatus = oldStatus;
    var newStatus = newStatus;
    var oldOrdem = oldOrdem;
    var newOrdem = newOrdem;
    var idTarefa = id;
    var url = "/SNALP/TarefaServlet";
    $.ajax({
        async: true,
        url: url,
        data: {
            action: action,
            type: type,
            oldStatus: oldStatus,
            newStatus: newStatus,
            oldOrdem: oldOrdem,
            newOrdem: newOrdem,
            idTarefa: idTarefa
        },
        dataType: 'json',
        success: function (data) {
            $("#"+oldStatus).empty();
            $.each(data[0], function (i, obj) {
                const task = document.createElement('div');
                task.draggable = true;
                task.classList.add("task-box");
                task.setAttribute("data-task-order",obj.ordem);
                task.setAttribute("data-task-id",obj.idTarefa);
                task.setAttribute("data-task-status",obj.status.idStatus);
                var tagList = "";
                $.each(obj.etiquetas, function(index, tag) {
                    tagList +='<p class="etiqueta" style="background-color:'+ tag.cor +'">'+ tag.titulo +'</p>';
                });
                var info = "";
                if(obj.qtdeTotal > 0){
                    if(obj.qtdeConcluida === obj.qtdeTotal) {
                        info = '<label class="task-count d-flex align-items-center progress-color"><i class="bx bx-check-square task-icon progress-color"></i>'+ obj.qtdeConcluida +'/'+ obj.qtdeTotal +'</label>';
                    } else {
                        info = '<label class="task-count d-flex align-items-center"><i class="bx bx-check-square task-icon"></i>'+ obj.qtdeConcluida +'/'+ obj.qtdeTotal +'</label>';
                    }
                }
                var dataLabel = "";
                if(obj.dataEntrega !== undefined){
                    var date = obj.dataEntrega.day + "/" + obj.dataEntrega.month + "/" + obj.dataEntrega.year;
                    if(dataComparison(obj.dataEntrega) === true) {
                        dataLabel = '<label class="task-date d-flex align-items-center late-color"><i class="bx bx-calendar task-icon late-icon"></i>'+ date +'</label>';
                    } else {
                        dataLabel = '<label class="task-date d-flex align-items-center"><i class="bx bx-calendar task-icon"></i>'+ date +'</label>';
                    }
                }
                task.innerHTML = '<a type="button" class="btnShowTask" data-toggle="modal" data-bs-target="#modal-popup" data-id='+ obj.idTarefa + 
                                 '><div class="task"><div class="etiquetas-tarefa">'+ tagList +'</div><p class="task-title">'+ obj.titulo +'</p><div class="info d-inline-flex justify-content-between">'
                                 + info + dataLabel +'</div></div></a>';
                initDragEventsTask(task);
                $("#"+oldStatus).append(task);
            });
            $("#"+newStatus).empty();
            $.each(data[1], function (e, obj2) {
                const task = document.createElement('div');
                task.draggable = true;
                task.classList.add("task-box");
                task.setAttribute("data-task-order",obj2.ordem);
                task.setAttribute("data-task-id",obj2.idTarefa);
                task.setAttribute("data-task-status",obj2.status.idStatus);
                var tagList = "";
                $.each(obj2.etiquetas, function(index, tag) {
                    tagList +='<p class="etiqueta" style="background-color:'+ tag.cor +'">'+ tag.titulo +'</p>';
                });
                var info = "";
                if(obj2.qtdeTotal > 0){
                    if(obj2.qtdeConcluida === obj2.qtdeTotal) {
                        info = '<label class="task-count d-flex align-items-center progress-color"><i class="bx bx-check-square task-icon progress-color"></i>'+ obj2.qtdeConcluida +'/'+ obj2.qtdeTotal +'</label>';
                    } else {
                        info = '<label class="task-count d-flex align-items-center"><i class="bx bx-check-square task-icon"></i>'+ obj2.qtdeConcluida +'/'+ obj2.qtdeTotal +'</label>';
                    }
                }
                var dataLabel = "";
                if(obj2.dataEntrega !== undefined){
                    var date = obj2.dataEntrega.day + "/" + obj2.dataEntrega.month + "/" + obj2.dataEntrega.year;
                    if(dataComparison(obj2.dataEntrega) === true) {
                        dataLabel = '<label class="task-date d-flex align-items-center late-color"><i class="bx bx-calendar task-icon late-icon"></i>'+ date +'</label>';
                    } else {
                        dataLabel = '<label class="task-date d-flex align-items-center"><i class="bx bx-calendar task-icon"></i>'+ date +'</label>';
                    }
                }
                task.innerHTML = '<a type="button" class="btnShowTask" data-toggle="modal" data-bs-target="#modal-popup" data-id='+ obj2.idTarefa + 
                                 '><div class="task"><div class="etiquetas-tarefa">'+ tagList +'</div><p class="task-title">'+ obj2.titulo +'</p><div class="info d-inline-flex justify-content-between">'
                                 + info + dataLabel +'</div></div></a>';
                initDragEventsTask(task);
                $("#"+newStatus).append(task);
            });
        },
        error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + request.statusText);
        }
    });
}

//muda tarefa para topo de um novo status
function changeStatusEnd (oldStatus, newStatus, oldOrdem, newOrdem, idTarefa){
    var type = "cse";
    var action = "change";
    var oldStatus = oldStatus;
    var newStatus = newStatus;
    var oldOrdem = oldOrdem;
    var newOrdem = newOrdem;
    var idTarefa = idTarefa;
    var url = "/SNALP/TarefaServlet";
    $.ajax({
       async: true,
       url: url,
       data: {
           action: action,
           type: type,
           oldStatus: oldStatus,
           newStatus: newStatus,
           oldOrdem: oldOrdem,
           newOrdem: newOrdem,
           idTarefa: idTarefa
       },
       dataType: 'json',
       success: function(data){
            $("#"+oldStatus).empty();
            $.each(data[0], function (i, obj) {
                const task = document.createElement('div');
                task.draggable = true;
                task.classList.add("task-box");
                task.setAttribute("data-task-order",obj.ordem);
                task.setAttribute("data-task-id",obj.idTarefa);
                task.setAttribute("data-task-status",obj.status.idStatus);
                var tagList = "";
                $.each(obj.etiquetas, function(index, tag) {
                    tagList +='<p class="etiqueta" style="background-color:'+ tag.cor +'">'+ tag.titulo +'</p>';
                });
                var info = "";
                if(obj.qtdeTotal > 0){
                    if(obj.qtdeConcluida === obj.qtdeTotal) {
                        info = '<label class="task-count d-flex align-items-center progress-color"><i class="bx bx-check-square task-icon progress-color"></i>'+ obj.qtdeConcluida +'/'+ obj.qtdeTotal +'</label>';
                    } else {
                        info = '<label class="task-count d-flex align-items-center"><i class="bx bx-check-square task-icon"></i>'+ obj.qtdeConcluida +'/'+ obj.qtdeTotal +'</label>';
                    }
                }
                var dataLabel = "";
                if(obj.dataEntrega !== undefined){
                    var date = obj.dataEntrega.day + "/" + obj.dataEntrega.month + "/" + obj.dataEntrega.year;
                    if(dataComparison(obj.dataEntrega) === true) {
                        dataLabel = '<label class="task-date d-flex align-items-center late-color"><i class="bx bx-calendar task-icon late-icon"></i>'+ date +'</label>';
                    } else {
                        dataLabel = '<label class="task-date d-flex align-items-center"><i class="bx bx-calendar task-icon"></i>'+ date +'</label>';
                    }
                }
                task.innerHTML = '<a type="button" class="btnShowTask" data-toggle="modal" data-bs-target="#modal-popup" data-id='+ obj.idTarefa + 
                                 '><div class="task"><div class="etiquetas-tarefa">'+ tagList +'</div><p class="task-title">'+ obj.titulo +'</p><div class="info d-inline-flex justify-content-between">'
                                 + info + dataLabel +'</div></div></a>';
                initDragEventsTask(task);
                $("#"+oldStatus).append(task);
            });
            $("#"+newStatus).empty();
            $.each(data[1], function (e, obj2) {
                const task = document.createElement('div');
                task.draggable = true;
                task.classList.add("task-box");
                task.setAttribute("data-task-order",obj2.ordem);
                task.setAttribute("data-task-id",obj2.idTarefa);
                task.setAttribute("data-task-status",obj2.status.idStatus);
                var tagList = "";
                $.each(obj2.etiquetas, function(index, tag) {
                    tagList +='<p class="etiqueta" style="background-color:'+ tag.cor +'">'+ tag.titulo +'</p>';
                });
                var info = "";
                if(obj2.qtdeTotal > 0){
                    if(obj2.qtdeConcluida === obj2.qtdeTotal) {
                        info = '<label class="task-count d-flex align-items-center progress-color"><i class="bx bx-check-square task-icon progress-color"></i>'+ obj2.qtdeConcluida +'/'+ obj2.qtdeTotal +'</label>';
                    } else {
                        info = '<label class="task-count d-flex align-items-center"><i class="bx bx-check-square task-icon"></i>'+ obj2.qtdeConcluida +'/'+ obj2.qtdeTotal +'</label>';
                    }
                }
                var dataLabel = "";
                if(obj2.dataEntrega !== undefined){
                    var date = obj2.dataEntrega.day + "/" + obj2.dataEntrega.month + "/" + obj2.dataEntrega.year;
                    if(dataComparison(obj2.dataEntrega) === true) {
                        dataLabel = '<label class="task-date d-flex align-items-center late-color"><i class="bx bx-calendar task-icon late-icon"></i>'+ date +'</label>';
                    } else {
                        dataLabel = '<label class="task-date d-flex align-items-center"><i class="bx bx-calendar task-icon"></i>'+ date +'</label>';
                    }
                }
                task.innerHTML = '<a type="button" class="btnShowTask" data-toggle="modal" data-bs-target="#modal-popup" data-id='+ obj2.idTarefa + 
                                 '><div class="task"><div class="etiquetas-tarefa">'+ tagList +'</div><p class="task-title">'+ obj2.titulo +'</p><div class="info d-inline-flex justify-content-between">'
                                 + info + dataLabel +'</div></div></a>';
                initDragEventsTask(task);
                $("#"+newStatus).append(task);
            });
       },
       error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + request.statusText);
        }
    });
}

//muda ordem da tarefa para cima no status
function changeOrderUp(oldStatus, oldOrdem, newOrdem, idTarefa) {
    var action = "change";
    var type = "ou";
    var oldStatus = oldStatus;
    var oldOrdem = oldOrdem;
    var newOrdem = newOrdem;
    var idTarefa = idTarefa;
    var url = "/SNALP/TarefaServlet";
    $.ajax({
        async: true,
        url: url,
        data: {
            action: action,
            type: type,
            oldStatus: oldStatus,
            oldOrdem: oldOrdem,
            newOrdem: newOrdem,
            idTarefa: idTarefa
        },
        dataType: 'json',
        success: function(data){
            $("#"+oldStatus).empty();
            $.each(data, function (i, obj) {
                const task = document.createElement('div');
                task.draggable = true;
                task.classList.add("task-box");
                task.setAttribute("data-task-order",obj.ordem);
                task.setAttribute("data-task-id",obj.idTarefa);
                task.setAttribute("data-task-status",obj.status.idStatus);
                var tagList = "";
                $.each(obj.etiquetas, function(index, tag) {
                    tagList +='<p class="etiqueta" style="background-color:'+ tag.cor +'">'+ tag.titulo +'</p>';
                });
                var info = "";
                if(obj.qtdeTotal > 0){
                    if(obj.qtdeConcluida === obj.qtdeTotal) {
                        info = '<label class="task-count d-flex align-items-center progress-color"><i class="bx bx-check-square task-icon progress-color"></i>'+ obj.qtdeConcluida +'/'+ obj.qtdeTotal +'</label>';
                    } else {
                        info = '<label class="task-count d-flex align-items-center"><i class="bx bx-check-square task-icon"></i>'+ obj.qtdeConcluida +'/'+ obj.qtdeTotal +'</label>';
                    }
                }
                var dataLabel = "";
                if(obj.dataEntrega !== undefined){
                    var date = obj.dataEntrega.day + "/" + obj.dataEntrega.month + "/" + obj.dataEntrega.year;
                    if(dataComparison(obj.dataEntrega) === true) {
                        dataLabel = '<label class="task-date d-flex align-items-center late-color"><i class="bx bx-calendar task-icon late-icon"></i>'+ date +'</label>';
                    } else {
                        dataLabel = '<label class="task-date d-flex align-items-center"><i class="bx bx-calendar task-icon"></i>'+ date +'</label>';
                    }
                }
                task.innerHTML = '<a type="button" class="btnShowTask" data-toggle="modal" data-bs-target="#modal-popup" data-id='+ obj.idTarefa + 
                                 '><div class="task"><div class="etiquetas-tarefa">'+ tagList +'</div><p class="task-title">'+ obj.titulo +'</p><div class="info d-inline-flex justify-content-between">'
                                 + info + dataLabel +'</div></div></a>';
                initDragEventsTask(task);
                $("#"+oldStatus).append(task);
            });
       },
       error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + request.statusText);
        }
    });
}

//muda ordem da tarefa para baixo no status
function changeOrderDown(oldStatus, oldOrdem, newOrdem, idTarefa) {
    var action = "change";
    var type = "od";
    var oldStatus = oldStatus;
    var oldOrdem = oldOrdem;
    var newOrdem = newOrdem;
    var idTarefa = idTarefa;
    var url = "/SNALP/TarefaServlet";
    $.ajax({
        async: true,
        url: url,
        data: {
            action: action,
            type: type,
            oldStatus: oldStatus,
            oldOrdem: oldOrdem,
            newOrdem: newOrdem,
            idTarefa: idTarefa
        },
        dataType: 'json',
        success: function(data){
            $("#"+oldStatus).empty();
            $.each(data, function (i, obj) {
                const task = document.createElement('div');
                task.draggable = true;
                task.classList.add("task-box");
                task.setAttribute("data-task-order",obj.ordem);
                task.setAttribute("data-task-id",obj.idTarefa);
                task.setAttribute("data-task-status",obj.status.idStatus);
                var tagList = "";
                $.each(obj.etiquetas, function(index, tag) {
                    tagList +='<p class="etiqueta" style="background-color:'+ tag.cor +'">'+ tag.titulo +'</p>';
                });
                var info = "";
                if(obj.qtdeTotal > 0){
                    if(obj.qtdeConcluida === obj.qtdeTotal) {
                        info = '<label class="task-count d-flex align-items-center progress-color"><i class="bx bx-check-square task-icon progress-color"></i>'+ obj.qtdeConcluida +'/'+ obj.qtdeTotal +'</label>';
                    } else {
                        info = '<label class="task-count d-flex align-items-center"><i class="bx bx-check-square task-icon"></i>'+ obj.qtdeConcluida +'/'+ obj.qtdeTotal +'</label>';
                    }
                }
                var dataLabel = "";
                if(obj.dataEntrega !== undefined){
                    var date = obj.dataEntrega.day + "/" + obj.dataEntrega.month + "/" + obj.dataEntrega.year;
                    if(dataComparison(obj.dataEntrega) === true) {
                        dataLabel = '<label class="task-date d-flex align-items-center late-color"><i class="bx bx-calendar task-icon late-icon"></i>'+ date +'</label>';
                    } else {
                        dataLabel = '<label class="task-date d-flex align-items-center"><i class="bx bx-calendar task-icon"></i>'+ date +'</label>';
                    }
                }
                task.innerHTML = '<a type="button" class="btnShowTask" data-toggle="modal" data-bs-target="#modal-popup" data-id='+ obj.idTarefa + 
                                 '><div class="task"><div class="etiquetas-tarefa">'+ tagList +'</div><p class="task-title">'+ obj.titulo +'</p><div class="info d-inline-flex justify-content-between">'
                                 + info + dataLabel +'</div></div></a>';
                initDragEventsTask(task);
                $("#"+oldStatus).append(task);
            });
       },
       error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + request.statusText);
        }
    });
}

//inicializa eventos nos status e nas tarefas
document.querySelectorAll(".task-box").forEach(initDragEventsTask);
document.querySelectorAll(".list").forEach(initDragEventsList);
