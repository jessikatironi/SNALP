document.addEventListener("DOMContentLoaded", function (event) {

    const showNavbar = (toggleId, navId, bodyId, headerId) => {
        const toggle = document.getElementById(toggleId),
                nav = document.getElementById(navId),
                bodypd = document.getElementById(bodyId),
                headerpd = document.getElementById(headerId);

// Validate that all variables exist
        if (toggle && nav && bodypd && headerpd) {
            toggle.addEventListener('click', () => {
// show navbar
                nav.classList.toggle('show');
// change icon
                toggle.classList.toggle('bx-layer');
// add padding to body
                bodypd.classList.toggle('body-pd');
// add padding to header
                headerpd.classList.toggle('body-pd');
            });
        }
    };

    showNavbar('header-toggle', 'nav-bar', 'body-pd', 'header');

    /*===== LINK ACTIVE =====*/
    const linkColor = document.querySelectorAll('.nav_link');

    function colorLink() {
        if (linkColor) {
            linkColor.forEach(l => l.classList.remove('active'));
            this.classList.add('active');
        }
    }
    linkColor.forEach(l => l.addEventListener('click', colorLink));

// Your code to run since DOM is loaded and ready
});


function menuAbreFecha(id) {
    const elemento = document.getElementById(id);//recebe elemento do id
    const seta = document.getElementById("seta" + id);//recebe seta do elemento
    if (elemento.style.visibility == "hidden") { //Se o botão de edição for ativado
        elemento.style.visibility = "visible";//torna visível
        elemento.style.height = "auto";//ajusta o tamanho
        elemento.style.width = "auto";//ajusta a largura
        seta.style.transform = "rotate(180deg)";//gira a seta para baixo
        fechaElementos(id);
    } else {
        elemento.style.visibility = "hidden";//torna o elemento invisível
        elemento.style.height = "0";//remove o valor do tamanho
        elemento.style.width = "0";//remove o valor da largura
        seta.style.transform = "rotate(0deg)";//volta a seta para posição inicial
    }
}
function fechaElementos(id) {
    var elementoAux;
    var setaAux;
    const ops = ['menuWorkspace', 'menuMoodTracker', 'menuEstatisticas'];//declara menus que podem ser fechados
    if (id != 'menuPomodoro') {//exclui pomodoro pois não tem submenus
        for (var i = 0; i < ops.length; i++) {//percorre os 3 menus
            if (id != ops[i]) {//se for diferente do selecioado
                document.getElementById(ops[i]).style.visibility = "hidden";//torna o elemento invisível
                document.getElementById(ops[i]).style.height = "0";//remove o valor do tamanho
                document.getElementById(ops[i]).style.width = "0";//remove o valor da largura
                document.getElementById("seta" + ops[i]).style.transform = "rotate(0deg)";//volta a seta para posição inicial
            }
        }
    }
}