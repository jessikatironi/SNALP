/* global google */

$(document).on("change", ".selectWorkspace", function () {

    var idWorkspace = $(".selectWorkspace option:selected").val();
    
    $('.divTituloEstatisticas').show(); // ativa a visualização do título das estatísticas de produtividade da workspace
    $('.containerEstatistica').show();  // ativa a visualização dos containers das estatísticas de produtividade da workspace
    $('.containerGrafico').show();      // ativa a visualização dos containers dos gráficos de produtividade da workspace
    
    // Requisição para resgatar dados estatísticos da workspace: qtde de tarefas concluídas no dia, semana, mês, semestre, ano e total
    $.ajax({
        url: "/SNALP/WorkspaceServlet",
        data: {
            action: "listStatistics",
            idWorkspace: idWorkspace
        },
        dataType: "JSON",
        // "list" é o JSON retornado de uma lista contendo a qtde de tarefas concluidas no dia, semana, mês, semestre, ano e total
        success: function (list) {
            $(".qtdeDia").html(list[0]);
            $(".qtdeSemana").html(list[1]);
            $(".qtdeMes").html(list[2]);
            $(".qtdeSemestre").html(list[3]);
            $(".qtdeAno").html(list[4]);
            $(".qtdeTotal").html(list[5]);
        }
    });
    
    // Requisição para resgatar dados do gráfico de tarefas concluidas diariamente nos últimos 7 dias
    $.ajax({
        url: "/SNALP/WorkspaceServlet",
        data: {
            action: "drawChartProdutividadeSemanal",
            idWorkspace: idWorkspace
        },
       dataType: "JSON",
        // "list" é o JSON retornado de uma lista contendo a qtde de tarefas concluidas diariamnete nos últimos sete dias
        success: function (list) {
            google.charts.load('current', {packages: ['corechart', 'line']});
            google.charts.setOnLoadCallback(function () {
                drawChartProdutividadeSemanal(list);
            });
        }
    });
    
    // Requisição para resgatar dados do gráfico de média de dias até a conclusão de tarefas por período
    $.ajax({
        url: "/SNALP/WorkspaceServlet",
        data: {
            action: "drawChartMediaDiasAteConclusao",
            idWorkspace: idWorkspace
        },
       dataType: "JSON",
        // "list" é o JSON retornado de uma lista contendo a média de dias até a conclusão de tarefas por período
        success: function (list) {
            google.charts.load('current', {'packages': ['corechart', 'bar']});
            google.charts.setOnLoadCallback(function () {
                drawChartMediaDiasAteConclusao(list);
            });
        }
    });
    
    // Requisição para resgatar dados do gráfico de relação entre tarefas concluídas e não concluídas
    $.ajax({
        url: "/SNALP/WorkspaceServlet",
        data: {
            action: "drawChartRelacaoTarefas",
            idWorkspace: idWorkspace
        },
        dataType: "JSON",
        // "list" é o JSON retornado de uma lista contendo a qtde de tarefas concluídas e tarefas não concluídas
        success: function (list) {
            google.charts.load('current', {'packages': ['corechart']});
            google.charts.setOnLoadCallback(function () {
                drawChartRelacaoTarefas(list);
            });
        }
    });
    
    // Requisição para resgatar dados do gráfico de tarefas em aberto por status
    $.ajax({
        url: "/SNALP/WorkspaceServlet",
        data: {
            action: "drawChartTarefasAbertasPorStatus",
            idWorkspace: idWorkspace
        },
        dataType: "JSON",
        // "map" é o JSON retornado de um HashMap contendo o status e a respectiva qtde de tarefas em aberto
        success: function (map) {
            google.charts.load('current', {'packages': ['corechart']});
            google.charts.setOnLoadCallback(function () {
                drawChartTarefasAbertasPorStatus(map);
            });
        }
    });

});

// Função para desenhar gráfico de produtividade semanal (GRÁFICO 01)
function drawChartProdutividadeSemanal(list) {
    var data = new google.visualization.DataTable();
    
    data.addColumn('date', 'Data');
    data.addColumn('number', 'Quantidade');
    
    var today     = new Date(), 
        yesterday = new Date(),
        dois      = new Date(),
        tres      = new Date(), 
        quatro    = new Date(), 
        cinco     = new Date(), 
        seis      = new Date();

    today.setHours(0,0,0,0);
    yesterday.setDate(today.getDate()-1);
    yesterday.setHours(0,0,0,0);
    dois.setDate(today.getDate()-2);
    dois.setHours(0,0,0,0);
    tres.setDate(today.getDate()-3);
    tres.setHours(0,0,0,0);
    quatro.setDate(today.getDate()-4);
    quatro.setHours(0,0,0,0);
    cinco.setDate(today.getDate()-5);
    cinco.setHours(0,0,0,0);
    seis.setDate(today.getDate()-6);
    seis.setHours(0,0,0,0);
    
    data.addRow([today, list[0]]);
    data.addRow([yesterday, list[1]]);
    data.addRow([dois, list[2]]);
    data.addRow([tres, list[3]]);
    data.addRow([quatro, list[4]]);
    data.addRow([cinco, list[5]]);
    data.addRow([seis, list[6]]);
    
    var dateFormatter = new google.visualization.DateFormat({
      pattern: "dd / MM / yyy"
    });
    dateFormatter.format(data, 0);

    var options = {
        backgroundColor: 'transparent',
        colors: ['#80bfb9'],
        pointSize: 10,
        pointShape: 'circle',
        hAxis: {
            title: '\u00DAltimos 7 Dias',
            titleTextStyle: {
                fontSize: 14,
                bold: false,
                italic: false
            },
            format: 'dd/MM',
            textStyle: {
                fontSize: 13,
                bold: false,
                italic: false
            }
        },
        vAxis: {
            title: 'Tarefas Conclu\u00EDdas',
            titleTextStyle: {
                fontSize: 14,
                bold: false,
                italic: false
            },
            format: '0',
            textStyle: {
                fontSize: 13,
                bold: false,
                italic: false
            }
        },
        legend: {
            position: 'none'
        },
        width: 550,
        height: 300,
        tooltip: {
            textStyle: {
                fontSize: 13
            }
        }
    };

    var linechart = new google.visualization.LineChart(document.getElementById('chartUm'));
    linechart.draw(data, options);
}

// Função para desenhar gráfico de média de dias até conclusão de tarefa (GRÁFICO 02)
function drawChartMediaDiasAteConclusao(list) {
    var data = new google.visualization.DataTable();

    data.addColumn('string', 'Per\u00EDodo');
    data.addColumn('number', 'M\u00E9dia de Dias');
    data.addColumn({role: 'style'});
    
    data.addRow(['Semana', list[0], '#80bfb9']);
    data.addRow(['M\u00EAs', list[1], '#80bfb9']);
    data.addRow(['Semestre', list[2], '#80bfb9']);
    data.addRow(['Ano', list[3], '#80bfb9']);
    data.addRow(['Geral', list[4], '#80bfb9']);
    
    var barchart_options = {
        backgroundColor: 'transparent',
        hAxis: {
            title: 'M\u00E9dia de Dias',
            titleTextStyle: {
                fontSize: 14,
                bold: false,
                italic: false
            },
            format: '0',
            textStyle: {
                fontSize: 13,
                bold: false,
                italic: false
            }
        },
        vAxis: {
            title: 'Per\u00EDodo',
            titleTextStyle: {
                fontSize: 14,
                bold: false,
                italic: false
            },
            textStyle: {
                fontSize: 13,
                bold: false,
                italic: false
            } 
        },
        legend: {
            position: "none"
        },
        width: 550,
        height: 300,
        tooltip: {
            textStyle: {
                fontSize: 13
            }
        }
        
    };

    var barchart = new google.visualization.BarChart(document.getElementById('chartDois'));
    barchart.draw(data, barchart_options);
}

// Função para desenhar gráfico de relação entre tarefas concluídas e tarefas não concluídas (GRÁFICO 03)
function drawChartRelacaoTarefas(list) {

    var data = new google.visualization.DataTable();

    data.addColumn('string', 'Situacao');
    data.addColumn('number', 'Qtde');

    data.addRow(['N\u00E3o Conclu\u00EDdas', list[0]]);
    data.addRow(['Conclu\u00EDdas', list[1]]);

    var piechart_options = {
        backgroundColor: 'transparent',
        pieHole: 0.7,
        pieSliceBorderColor: 'transparent',
        pieSliceText: 'value',
        pieSliceTextStyle: {
            color: 'black', 
            fontSize: 18
        },
        colors: ['#f44336', '#80bfb9'],
        legend: {
            alignment: 'center',
            position: 'labeled',
            labeledValueText: 'none',
            textStyle: {
                fontSize: 13,
                bold: false,
                italic: false
            }
        },
        width: 550,
        height: 300,
        tooltip: {
            showColorCode: true,
            textStyle: {
                fontSize: 13
            }
        }
    };
    
    var piechart = new google.visualization.PieChart(document.getElementById('chartTres'));
    piechart.draw(data, piechart_options);

}

// Função para desenhar gráfico de tarefas não concluídas por status (GRÁFICO 04)
function drawChartTarefasAbertasPorStatus(map) {
    var data = new google.visualization.DataTable();
    
    data.addColumn('string', 'Status');
    data.addColumn('number', 'Quantidade');
    data.addColumn({role: 'annotation'});
    data.addColumn({role: 'style'});

    $.each(map, function (status, qtde) {   
        data.addRow([status, qtde, qtde.toString(), '#80bfb9']);
    });
    
    data.sort({ column: 1, desc: true });

    var columnchart_options = {
        backgroundColor: 'transparent',
        annotations: {
            alwaysOutside: false,
            textStyle: {
                color: 'black', 
                fontSize: 15
            }
        },
        hAxis: {
            title: 'Status',
            titleTextStyle: {
                fontSize: 14,
                bold: false,
                italic: false
            },
            textStyle: {
                fontSize: 13,
                bold: false,
                italic: false
            }
        },
        vAxis: {
            title: 'Tarefas N\u00E3o Conclu\u00EDdas',
            textPosition: 'none',
            titleTextStyle: {
                fontSize: 14,
                bold: false,
                italic: false
            },
            textStyle: {
                fontSize: 13,
                bold: false,
                italic: false
            }
        },
        legend: {
            position: "none"
        },
        width: 550,
        height: 300,
        tooltip: {
            textStyle: {
                fontSize: 13
            }
        }
    };

    var columnChart = new google.visualization.ColumnChart(document.getElementById('chartQuatro'));
    columnChart.draw(data, columnchart_options);
}
