$(document).ready(function () {
    //Altera visibilidade das tarefas concluídas
    $('#view-options').on('click', '.btn-toggle', function () {
        taskVisibility(this);
    });
});

//Nova tarefa
$(document).on('click', '.btnTaskNew', function () {
    $('.modal-title').text('Criar Tarefa');
    $('.modal-body').load('TarefaServlet?action=formNew&idStatus=' + $(this).data('id')+"&view=" + document.querySelector('.view-active').getAttribute("data-view"), function () {
        $('#TaskForm').modal('show');
    });
});
