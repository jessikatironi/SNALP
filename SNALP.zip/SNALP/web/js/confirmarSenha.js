function confirmarSenha(){
    var senha = $('#senha').val();
    var confirmarsenha = $('#confirmarsenha').val();
    if(senha !== confirmarsenha){
        alert("A confirma\u00e7\u00e3o de senha n\u00e3o confere !");
        $('#confirmarsenha').val('');
        return false;
    }
}