$(document).ready(function () {
    //Completa uma tarefa ou torna a tarefa ativa
    $('#btn-state').on('click', function () {
        if ($(".item-update")) {
            $(".item-update").remove();
        }
        completeTask();
    });
    //Completa uma subtarefa ou a torna ativa
    $('#listaSubtarefa').on('change', '.subtask-checkbox', function () {
        if ($(".item-update")) {
            $(".item-update").remove();
        }
        completeSubtask(this);
    });
    //Remove uma subtarefa da tarefa
    $('#listaSubtarefa').on('click', '.btn-delete', function () {
        if ($(".item-update")) {
            $(".item-update").remove();
        }
        deleteSubtarefa(this);
    });
    //Cria campo de alteração para subtarefa
    $('#listaSubtarefa').on('click', '.btn-edit', function () {
        updateTrigger(this, $(this).data('desc'));
    });
    //Ativa campo de alteração de titulo da tarefa
    $('#task-title').on('click', function () {
        $('#task-title').addClass('d-none');
        $('#title-update').removeClass('d-none');
    });
    //Cancela alteração de titulo da tarefa
    $('.btn-title-cancel').on('click', function () {
        $('#task-title').removeClass('d-none');
        $('#title-update').addClass('d-none');
        if ($("#title-input").hasClass('invalid')) {
            $("#title-input").removeClass('invalid');
            $('#title-input').val($("#task-title").html());
        }
    });
    //Verifica se novo titulo da tarefa é valido e chama atualização
    $('.btn-title-update').on('click', function () {
        if (document.getElementById("title-input").value.length === 0) {
            $("#title-input").addClass('invalid');
        } else {
            updateTaskTitle();
        }
    });
    //Ativa campo de alteração da descrição da tarefa
    $('.desc-area').on('click', function () {
        $('#desc-update').removeClass('d-none');
        $('#desc-area').addClass('d-none');
    });
    //Cancela alteração da descrição da tarefa
    $('.btn-desc-cancel').on('click', function () {
        $('#desc-area').removeClass('d-none');
        $('#desc-update').addClass('d-none');
        $('#desc-input').value = $("#desc").val();
    });
    //Atualiza descrição da tarefa
    $('.btn-desc-update').on('click', function () {
        updateTaskDesc();
    });
    //Atualiza data de entrega da tarefa
    $('#date-input').on('change', function () {
        updateTaskDate($("#date-input").val());
    });
    //Remove data de entrega da tarefa
    $('.btn-delete-date').on('click', function () {
        updateTaskDate(null);
    });
    //Adiciona campo para escolha de data de entrega da tarefa
    $(".btn-date-add").on('click', function () {
        $(".btn-date-add").addClass('d-none');
        $(".date-input-field").removeClass('d-none');
    });
    //Adiciona nova subtarefa na tarefa e valida se campo não está vazio
    $(".btn-new-subtask").on('click', function() {
        if (document.getElementById("subtarefaDesc").value.length === 0) {
            $("#subtarefaDesc").addClass('invalid');
        } else {
            newSubtarefa();
        }
    });
    //Chama cálculo de progresso das subtarefas
    calcularProgresso();
});