$(document).ready(function () {
    //Novo Status
    $('.btnStatusNew').on('click', function () {
        $('.modal-title').text('Criar Status');
        $('.modal-body').load('StatusServlet?action=formNew&origin=config', function () {
            $('#StatusForm').modal('show');
        });
    });
    //Alteração do Status
    $('#status-list').on('click', '.btnStatusUpdate', function (e) {
        $('.modal-title').text('Editar Status');
        $('.modal-body').load("StatusServlet?action=formUpdate&idStatus=" + $(this).data('id'), function () {
            $('#StatusForm').modal('show');
        });
    });
    //Nova Etiqueta
    $('.btnEtiquetaNew').on('click', function () {
        $('.modal-title').text('Criar Etiqueta');
        $('.modal-body').load('EtiquetaServlet?action=formNew', function () {
            $('#StatusForm').modal('show');
        });
    });
    //Alteração na Etiqueta
    $('#etiqueta-list').on('click', '.btnEtiquetaUpdate', function (e) {
        $('.modal-title').text('Editar Etiqueta');
        $('.modal-body').load("EtiquetaServlet?action=formUpdate&idEtiqueta=" + $(this).data('id'), function () {
            $('#StatusForm').modal('show');
        });
    });
});
