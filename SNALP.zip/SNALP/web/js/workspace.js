//Remover um status
function statusDelete(id,ordem) {
    var idWorkspace = $("#idWorkspace").val();
    var action = "delete";
    var idStatus = id;
    var ordem = ordem;
    var url = "/SNALP/StatusServlet";
    $.ajax({
        url: url,
        data: {
            action: action,
            idWorkspace: idWorkspace,
            idStatus: idStatus,
            ordem: ordem
        },
        dataType: 'json',
        success: function (data) {
            $('#DeleteModal').modal('hide');
            $("#status-list").empty();
            $.each(data, function(i, obj){
                const status = document.createElement('div');
                status.draggable = true;
                status.classList.add("config-status");
                status.style.backgroundColor = obj.cor;
                status.setAttribute("data-id",obj.idStatus);
                status.setAttribute("data-ordem",obj.ordem);
                
                status.innerHTML = '<label class="config-titulo">'+obj.titulo +'</label><div><button type="button" class="btnStatusUpdate btnedit" data-toggle="modal" data-bs-target="#modal-popup" data-id='+
                                    obj.idStatus +'><i class="bx bx-pencil"></i></button><button type="button" class="btnStatusDelete btndelete" data-toggle="modal" data-bs-target="#modal-popup" data-id='+ 
                                    obj.idStatus +' data-title='+ obj.titulo +' data-ordem='+ obj.ordem +'><i class="bx bx-trash"></i></button></div>';
                initDragEventsStatus(status);
                 $("#status-list").append(status);
            });
        },
        error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + request.statusText);
        }
    });
}

//Remover uma etiqueta
function etiquetaDelete(id) {
    var idWorkspace = $("#idWorkspace").val();
    var action = "delete";
    var idEtiqueta = id;
    var url = "/SNALP/EtiquetaServlet";
    $.ajax({
        url: url,
        data: {
            action: action,
            idWorkspace: idWorkspace,
            idEtiqueta: idEtiqueta
        },
        dataType: 'json',
        success: function (data) {
            $('#DeleteModal').modal('hide');
            $("#etiqueta-list").empty();
            $.each(data, function (i, obj) {
                $("#etiqueta-list").append('<div class="config-etiqueta" style="background-color: '+ obj.cor +'; color: white"><label class="config-titulo">'+ obj.titulo +
                        '</label><div><button type="button" class="btnEtiquetaUpdate" data-toggle="modal" data-bs-target="#modal-popup" data-id="'+ obj.idEtiqueta +
                        '"><i class="bx bx-pencil"></i></button><button type="button" class="btnEtiquetaDelete" data-toggle="modal" data-bs-target="#modal-popup" data-id="'+ 
                        obj.idEtiqueta +'" data-title="'+ obj.titulo +'"><i class="bx bx-trash"></i></button></div></div>');
            });
        },
        error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + request.statusText);
        }
    });
}

//Muda visibilidade das tarefas concluídas na visualização tabela e kanban
function taskVisibility(e) {
     //se visualização está ativa
    if($("#icon-toggle").hasClass('bx-show')){
        //remove classe show e insere classe hide
        $("#icon-toggle").removeClass('bx-show').addClass('bx-hide');
        //remove indicativo de que está ativo
        e.classList.remove('toggle-active');
        
        //se view kanban - esconde lista de tarefas concluídas
        if(document.querySelector('.view-active').getAttribute("data-view") === "kanban") {
            document.querySelector('.completed-list').classList.add('d-none');
        
        //se view tabela - esconde tarefas concluídas na tabela, iterando cada tarefa concluída
        } else if (document.querySelector('.view-active').getAttribute("data-view") === "table"){
            var completed = document.querySelectorAll('.show');
            if(completed.length > 0){
                $(completed).each(function(i, task) {
                   task.classList.add('d-none');
                });
            }
        }
        
    //se visualização não está ativa
    } else if ($("#icon-toggle").hasClass('bx-hide')){
        //remove classe hide e insere classe show
        $("#icon-toggle").removeClass('bx-hide').addClass('bx-show');
        //insere indicativo de que está ativo
        e.classList.add('toggle-active');
        
        //se view kanban - mostra  lista de tarefas concluídas
        if(document.querySelector('.view-active').getAttribute("data-view") === "kanban") {
            document.querySelector('.completed-list').classList.remove('d-none');
        
        //se view tabela - mostra tarefas concluídas na tabela, iterando cada tarefa concluída
        } else if (document.querySelector('.view-active').getAttribute("data-view") === "table"){
            var completed = document.querySelectorAll('.d-none');
            if(completed.length > 0){
                $(completed).each(function(i, task) {
                   task.classList.remove('d-none');
                   task.classList.add('show');
                });
            }
        }
    }
}

function deleteWorkspace(id){
    window.location.href="WorkspaceServlet?action=delete&idWorkspace="+id;
}


function deleteStatus(id,ordem,workspace){
    window.location.href="StatusServlet?action=deleteKanban&idWorkspace="+workspace+"&idStatus="+id+"&ordem="+ordem;
}
