/* global google */

$(document).ready(function () {
    
    // Requisição para resgatar dados do gráfico de contagem de humores (GRÁFICO 01)
    $.ajax({
        url: "/SNALP/MoodTrackerServlet",
        data: {
            action: "drawChartContagemHumores"
        },
        dataType: "JSON",
        // "map" é o JSON retornado de um HashMap contendo idHumor e qtde de aparições do humor nos registros Mood Tracker
        success: function (map) {
            google.charts.load('current', {'packages': ['corechart']});
            google.charts.setOnLoadCallback(function () {
                drawChartContagemHumor(map);
            });
        }
    });
    
    // Requisição para resgatar dados do gráfico de contagem de atividades (GRÁFICO 02)
    $.ajax({
        url: "/SNALP/MoodTrackerServlet",
        data: {
            action: "drawChartContagemAtividades"
        },
        dataType: "JSON",
        // "map" é o JSON retornado de um HashMap contendo idAtividade e qtde de aparições da atividade nos registros
        success: function (map) {
            google.charts.load('current', {'packages': ['corechart', 'bar']});
            google.charts.setOnLoadCallback(function () {
                drawChartContagemAtividade(map);
            });
        }
    });
    
    // Requisição para resgatar dados do gráfico de humores (GRÁFICO 04)
    $.ajax({
        url: "/SNALP/MoodTrackerServlet",
        data: {
            action: "drawChartHumores"
        },
        dataType: "JSON",
        // "map" é o JSON retornado de um HashMap contendo a data e o humor marcado no registro Mood Tracker
        success: function (map) {
            google.charts.load('current', {'packages': ['line']});
            google.charts.setOnLoadCallback(function () {
                drawChartHumores(map);
            });
        }
    });
       
});

$(document).on("change", ".selectHumor", function () {

    var idHumor = $(".selectHumor option:selected").val();
    
    // Requisição para resgatar dados do gráfico de atividades mais frequentes por humor (GRÁFICO 03)
    $.ajax({
        url: "/SNALP/MoodTrackerServlet",
        data: {
            action: "drawChartAtividadesPorHumor",
            idHumor: idHumor
        },
        dataType: "JSON",
        // "map" é o JSON retornado de um TreeMap contendo a descrição e qtde de aparições das atividades mais frequentes por humor
        success: function (map) {
            google.charts.load('current', {packages: ['corechart', 'bar']});
            google.charts.setOnLoadCallback(function () {
                drawChartAtividadesPorHumor(map);
            });
        }
    });

});

// Função para desenhar gráfico de contagem de humores (GRÁFICO 01)
function drawChartContagemHumor(map) {

    var data = new google.visualization.DataTable();

    data.addColumn('string', 'Humor');
    data.addColumn('number', 'Quantidade');
    data.addColumn({type: 'string', role: 'tooltip', 'p': {'html': true}});

    var colors = [];
    
    $.each(map, function (idHumor, qtde) {
        $.ajax({
            async: false,
            url: "/SNALP/HumorServlet",
            data: {
                action: "show",
                idHumor: idHumor
            },
            dataType: "JSON",
            success: function (humor) {
                data.addRow([humor.emojiHumor, qtde, createCustomTootip(humor.descricaoHumor, humor.corHumor, qtde) ]);
                colors.push(humor.corHumor);
            }
        });
    });

    var piechart_options = {
        backgroundColor: 'transparent',
        pieHole: 0.7,
        pieSliceBorderColor: 'transparent',
        pieSliceText: 'value',
        pieSliceTextStyle: {color: 'black', fontSize: 20},
        colors: colors,
        legend: {textStyle: {fontName: 'Emojis', fontSize: 40}, alignment: 'center', position: 'labeled', labeledValueText: 'none'},
        width: 550,
        height: 300,
        tooltip: {
            showColorCode: true,
            isHtml: true,
            textStyle: {
                fontSize: 13
            }
        }
    };
    
    var piechart = new google.visualization.PieChart(document.getElementById('pieChartContagemHumores'));
    piechart.draw(data, piechart_options);

}

// Função para desenhar gráfico de contagem de atividades (GRÁFICO 02)
function drawChartContagemAtividade(map) {

    var data = new google.visualization.DataTable();

    data.addColumn('string', 'Atividade');
    data.addColumn('number', 'Quantidade');
    data.addColumn({role: 'style'});
    data.addColumn({role: 'annotation'});

    $.each(map, function (idAtividade, qtde) {
        $.ajax({
            async: false,
            url: "/SNALP/AtividadeServlet",
            data: {
                action: "show",
                idAtividade: idAtividade
            },
            dataType: "JSON",
            success: function (atividade) {
                data.addRow([atividade.descricaoAtividade, qtde, '#80bfb9', atividade.categoriaAtividade.tituloCategoria]);
            }

        });
    });
    
    data.sort({ column: 1, desc: true });

    var barchart_options = {
        backgroundColor: 'transparent',
        hAxis: {
            title: 'Apari\u00E7\u00F5es',
            titleTextStyle: {
                fontSize: 14,
                bold: false,
                italic: false
            },
            textStyle: {
                fontSize: 13,
                bold: false,
                italic: false
            },
            format: '0'
        },
        vAxis: {
            title: 'Atividade',
            titleTextStyle: {
                fontSize: 14,
                bold: false,
                italic: false
            },
            textStyle: {
                fontSize: 13,
                bold: false,
                italic: false
            } 
        },
        legend: {
            position: "none"
        },
        width: 1100,
        height: 400,
        tooltip: {
            textStyle: {
                fontSize: 13
            }
        }
    };

    var barchart = new google.visualization.BarChart(document.getElementById('barChartContagemAtividades'));
    barchart.draw(data, barchart_options);
}

// Função para desenhar gráfico de atividades mais frequentes por humor (GRÁFICO 03)
function drawChartAtividadesPorHumor(map) {
    var data = new google.visualization.DataTable();
    
    data.addColumn('string', 'Atividade');
    data.addColumn('number', 'Quantidade');
    data.addColumn({role: 'style'});

    $.each(map, function (atividade, qtde) {
        data.addRow([atividade, qtde, '#80bfb9']);
    });
    
    data.sort({ column: 1, desc: true });

    var columnchart_options = {
        backgroundColor: 'transparent',
        hAxis: {
            title: 'Atividade',
            titleTextStyle: {
                fontSize: 14,
                bold: false,
                italic: false
            },
            textStyle: {
                fontSize: 13,
                bold: false,
                italic: false
            }
        },
        vAxis: {
            title: 'Apari\u00E7\u00F5es',
            titleTextStyle: {
                fontSize: 14,
                bold: false,
                italic: false
            },
            textStyle: {
                fontSize: 13,
                bold: false,
                italic: false
            },
            format: '0'
        },
        legend: {
            position: 'none'
        },
        width: 550,
        height: 300,
        tooltip: {
            textStyle: {
                fontSize: 13
            }
        }
    };

    var columnChart = new google.visualization.ColumnChart(document.getElementById('columnChartAtividadesFrequentes'));
    columnChart.draw(data, columnchart_options);
}

// Função para desenhar gráfico de humores (GRÁFICO 04)
function drawChartHumores(map) {
    var data = new google.visualization.DataTable();

    data.addColumn('date', 'Data do Registro');
    data.addColumn('number', 'Humor');
    data.addColumn({type: 'string', role: 'tooltip', 'p': {'html': true}});

    var qtdeHumores = 0;
    
    $.ajax({
        async: false,
        url: "/SNALP/HumorServlet",
        data: {
            action: "list"
        },
        dataType: "JSON",
        success: function (listaHumores) {
            qtdeHumores = listaHumores.length;
        }
    });
    
    var chartHeight = ((qtdeHumores+0.5) * 65);
    var chartWidth = (chartHeight * 2);

    $.each(map, function (date, humor) {
        
        var registerDate = new Date(date);
        registerDate.setHours(24,0,0,0);
        var formattedDate = registerDate.toISOString().split("T")[0]; // -> yyyy-MM-dd
        var finalDate = formattedDate.split("-").reverse().join(" / "); // -> dd/mm/aaaa
        
        data.addRow([registerDate, humor.idHumor, createCustomTootip2(humor.descricaoHumor, finalDate)]);
    });
    
    var dateFormatter = new google.visualization.DateFormat({
        pattern: "dd / MM / yyy"
    });
    dateFormatter.format(data, 0);

    var options = {
        backgroundColor: 'transparent',
        colors: ['#80bfb9'],
        pointSize: 10,
        pointShape: 'circle',
        hAxis: {
            titleTextStyle: {
                fontSize: 14,
                bold: false,
                italic: false
            },
            format: 'dd/MM',
            textStyle: {
                fontSize: 13,
                bold: false,
                italic: false
            }
        },
        vAxis: {
            textPosition: 'none',
            format: '0',
            minValue: 0.5,
            textStyle: {
                bold: false,
                italic: false
            }
        },
        width: chartWidth,
        height: chartHeight,
        legend: {
            position: 'none'
        },
        tooltip: {
            isHtml: true,
            textStyle: {
                fontSize: 13
            }
        },
        chartArea : { 
            //top: 30,
            left: 30 
        }
    };

    var comboChart = new google.visualization.AreaChart(document.getElementById('areaChartHumores'));
    comboChart.draw(data, options);
}

// Função para desenhar tooltip personalizado para o gráfico de contagem de humores (GRÁFICO 01)
function createCustomTootip(humor, cor, qtde) {
    return '<div style="width: 200%; padding: 0.4rem; font-size: 14px;">' +
                '<div style="display: flex; align-items: center;">' +
                    '<div style="width: 0.6rem; height: 0.6rem; background-color: ' + cor + '; margin-right: 0.4rem;"> </div>' +
                    '<b>' + humor + '</b><br>' +
                '</div>' +
            'Quantidade: <b>' + qtde + '</b>' +
            '</div>';
}

// Função para desenhar tooltip personalizado para o gráfico de humores (GRÁFICO 04)
function createCustomTootip2(humor, data) {
    return '<div style="width: 200%; padding: 0.4rem; font-size: 14px;">' +
            '<b>' + data + '</b><br>' +
            'Humor: <b>' + humor + '</b>' +
            '</div>';
}