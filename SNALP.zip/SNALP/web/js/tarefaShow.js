//Mostra input de nova subtarefa
function showField() {
    if($(".item-update")) { $(".item-update").remove(); }
    document.getElementById('subtarefa-field').className = "show-field";
}

//Esconde input de nova subtarefa
function hideField() {
    if($(".item-update")) { $(".item-update").remove(); }
    if($("#subtarefaDesc").hasClass('invalid')) { $("#subtarefaDesc").removeClass('invalid'); }
    document.getElementById("subtarefaDesc").value = '';
    document.getElementById('subtarefa-field').className = "hidden-field";
}

//Calcula progresso das subtarefas da tarefa
function calcularProgresso(){
    var total = $("#total").val();
    var conc = $("#conc").val();
    var progress = (conc * 100) / total;
    $("#progress-bar").attr('aria-valuenow', progress).css('width', progress+'%');
}

//Cria uma nova subtarefa
function newSubtarefa() {
    var idTarefa = $("#idTarefa").val();
    var action = "new";
    var subtarefa = $("#subtarefaDesc").val();
    var url = "/SNALP/SubtarefaServlet";
    document.getElementById("subtarefaDesc").value = '';
    document.getElementById('subtarefa-field').className = "hidden-field";
    $.ajax({
        async: true,
        url: url,
        data: {
            idTarefa: idTarefa,
            action: action,
            subtarefa: subtarefa
        },
        dataType: 'json',
        success: function (data) {
            const subtask = document.createElement('div');
            var inner = "";
            subtask.classList.add('check-item');
            subtask.id = data.idSubtarefa;
            inner = '<div class="check-row d-flex flex-grow-1 bd-highlight align-items-center"><div class="flex-grow-1 bd-highlight"><input type="checkbox" class="subtask-checkbox" data-subtask-id='+ data.idSubtarefa;
                if(data.concluido === true) inner += ' checked="true"><label for='+ data.idSubtarefa+' class="check-desc subtask-complete"';
                else inner += '><label for='+ data.idSubtarefa+' class="check-desc"';
                subtask.innerHTML = inner + '>'+  data.descricao +'</label></div><button class="btn-edit bd-highlight" data-desc="'+ data.descricao +'" data-id='+ data.idSubtarefa +
                                     '><i class="bx bx-pencil"></i></button><button class="btn-delete bd-highlight" data-id='+ data.idSubtarefa +
                                     '><i class="bx bx-trash"></i></button></div></div>';
            $("#listaSubtarefa").append(subtask);
            var total = parseInt($("#total").val()) + 1;
            $("#total").val(total);
            calcularProgresso();
        },
        error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + request.statusText);
        }
    });
}

//Trigger de alteração de uma subtarefa
function updateTrigger(e, desc) {
    //condicionais de controle caso alguma outra tarefa já esteja em alteração 
    if($(".item-update")) { $(".item-update").remove(); $("#" + $(e).data('id')).removeClass('selected-sub'); }
    if(document.querySelector('.selected-sub')) { document.querySelector('.selected-sub').classList.remove('selected-sub'); }
    
    //Renderiza input de atualização
    $("#" + $(e).data('id')).append('<div class="item-update d-flex flex-grow-1 justify-content-between"><input id="item-update" class="form-control flex-grow-1" value="" '
            + 'placeholder="Descrição da subtarefa"><button class="btn-save btn-item-save"><i class="bx bx-save icon-save"></i></button>'
            + '<button class="btn-cancel btn-item-cancel"><i class="bx bx-x icon-cancel"></i></button></div>');
    $("#item-update").val(desc);
    
    //Registra evento de confirmação da alteração
    $('.btn-item-save').on('click', function () {
        if($("#item-update").val() === '') { $("#item-update").addClass('invalid'); }
        else { updateSubtask(e); }
    });
    //Registra evento de cancelamento da alteração
    $(".btn-item-cancel").on('click', function () {
        if($(".item-update")) { $(".item-update").remove(); $("#" + $(e).data('id')).removeClass('selected-sub'); }
    });
    
    $("#" + $(e).data('id')).addClass('selected-sub');
}

//Atualiza a descrição de uma subtarefa
function updateSubtask(e){
    var idSubtarefa = $(e).data('id');
    var action = "update";
    var desc = $("#item-update").val();
    var url = "/SNALP/SubtarefaServlet";
    $.ajax({
        async: true,
        url: url,
        data: {
            idSubtarefa: idSubtarefa,
            action: action,
            desc: desc
        },
        dataType: 'json',
        success: function (data) {
            $("#" + data.idSubtarefa).removeClass('selected-sub');
            $(".item-update").remove();
            $("label[for="+idSubtarefa+"]").text(data.descricao);
            $(e).attr("data-desc",data.descricao);
            $(e).data("desc",data.descricao);
        },
        error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + request.statusText);
        }
    });
}

//Remove uma subtarefa
function deleteSubtarefa(e) {
    var idTarefa = $("#idTarefa").val();
    var action = "delete";
    var idSubtarefa = e.getAttribute("data-id");
    var url = "/SNALP/SubtarefaServlet";
    $.ajax({
        async: true,
        url: url,
        data: {
            idTarefa: idTarefa,
            action: action,
            idSubtarefa: idSubtarefa
        },
        dataType: 'json',
        success: function (data) {
            $("#listaSubtarefa").empty();
            $.each(data, function (i, obj) {
                const subtask = document.createElement('div');
                var inner = "";
                subtask.classList.add('check-item');
                subtask.id = obj.idSubtarefa;
                inner = '<div class="check-row d-flex flex-grow-1 bd-highlight align-items-center"><div class="flex-grow-1 bd-highlight"><input type="checkbox" class="subtask-checkbox" data-subtask-id='+ obj.idSubtarefa;
                    if(obj.concluido === true) inner += ' checked="true"><label for='+ obj.idSubtarefa+' class="check-desc subtask-complete"';
                    else inner += '><label for='+ obj.idSubtarefa+' class="check-desc"';
                    subtask.innerHTML = inner + '>'+  obj.descricao +'</label></div><button class="btn-edit bd-highlight" data-desc="'+ obj.descricao +'" data-id='+ obj.idSubtarefa +
                                         '><i class="bx bx-pencil"></i></button><button class="btn-delete bd-highlight" data-id='+ obj.idSubtarefa +
                                         '><i class="bx bx-trash"></i></button></div></div>';
                $("#listaSubtarefa").append(subtask);
            });
            var total = parseInt($("#total").val()) - 1;
            $("#total").val(total);
            calcularProgresso();
        },
        error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + request.statusText);
        }
    });
}

//Insere uma etiqueta em uma tarefa
function insertTag(id) {
    var idTarefa = $("#idTarefa").val();
    var idWorkspace = $("#idWorkspace").val();
    var action = "insert";
    var idEtiqueta = id;
    var url = "/SNALP/EtiquetaServlet";
    $.ajax({
        async: true,
        url: url,
        data: {
            action: action,
            idTarefa: idTarefa,
            idWorkspace: idWorkspace,
            idEtiqueta: idEtiqueta
        },
        dataType: 'json',
        success: function (data) {
            $("#etiquetasTarefa").empty();
            $.each(data[0], function (i, obj) {
                $("#etiquetasTarefa").append('<div class="tag" style="background-color:'+ obj.cor +'"><div>' + obj.titulo + 
                        '</div><button class="btn-remove-tag" style="background-color:' + obj.cor +'" onclick="removeTag('
                        + obj.idEtiqueta + ')"><i class="bx bx-x remove-icon"></i></button></div>');
            });
            var dropdown = document.createElement('div');
            dropdown.classList.add('dropend');
            dropdown.innerHTML = '<button class="btn-tag d-inline-flex align-items-center" type="button"  data-bs-toggle="dropdown" aria-expanded="false">'
                               + '<i class="bx bx-plus btn-plus"></i></button>';
            $('#etiquetasTarefa').append(dropdown);
            var disponiveis = document.createElement('ul');
            disponiveis.classList.add('dropdown-menu');
            disponiveis.id = 'etiquetasDisponiveis';
            $(dropdown).append(disponiveis);
            $.each(data[1], function (e, obj2) {
                $("#etiquetasDisponiveis").append('<li><button class="dropdown-item dropdown-etiqueta" style="background-color: '
                        + obj2.cor + ' " onclick="insertTag(' + obj2.idEtiqueta + ' )">' + obj2.titulo + '</button></li>');
            });
        },
        error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + request.statusText);
        }
    });
}

//Remove uma etiqueta de uma tarefa
function removeTag(id) {
    var idTarefa = $("#idTarefa").val();
    var idWorkspace = $("#idWorkspace").val();
    var action = "remove";
    var idEtiqueta = id;
    var url = "/SNALP/EtiquetaServlet";
    $.ajax({
        async: true,
        url: url,
        data: {
            action: action,
            idTarefa: idTarefa,
            idWorkspace: idWorkspace,
            idEtiqueta: idEtiqueta
        },
        dataType: 'json',
        success: function (data) {
            $("#etiquetasTarefa").empty();
            $.each(data[0], function (i, obj) {
                $("#etiquetasTarefa").append('<div class="tag" style="background-color:'+ obj.cor +'"><div>' + obj.titulo + 
                        '</div><button class="btn-remove-tag" style="background-color:' + obj.cor +'" onclick="removeTag('
                        + obj.idEtiqueta + ')"><i class="bx bx-x remove-icon"></i></button></div>');
            });
            var dropdown = document.createElement('div');
            dropdown.classList.add('dropend');
            dropdown.innerHTML = '<button class="btn-tag d-inline-flex align-items-center" type="button"  data-bs-toggle="dropdown" aria-expanded="false">'
                               + '<i class="bx bx-plus btn-plus"></i></button>';
            $('#etiquetasTarefa').append(dropdown);
            var disponiveis = document.createElement('ul');
            disponiveis.classList.add('dropdown-menu');
            disponiveis.id = 'etiquetasDisponiveis';
            $(dropdown).append(disponiveis);
            $.each(data[1], function (e, obj2) {
                $("#etiquetasDisponiveis").append('<li><button class="dropdown-item dropdown-etiqueta" style="background-color: '
                        + obj2.cor + ' " onclick="insertTag(' + obj2.idEtiqueta + ' )">' + obj2.titulo + '</button></li>');
            });
        },
        error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + request.statusText);
        }
    });
}

//Completa uma tarefa ou a torna ativa - front e chamada do método de atualização de estado
function completeTask(){   
    if($("#comp").hasClass('completed')){
        changeTaskState("uncomplete");
    } else if ($("#uncomp").hasClass('uncompleted')) {
        changeTaskState("complete");
    }
}

//Muda o estado de uma tarefa
function changeTaskState(operacao){
    var idTarefa = $("#idTarefa").val();
    var action = "complete";
    var tipo = operacao;
    var idWorkspace = $("#idWorkspace").val();
    var url = "/SNALP/TarefaServlet";
    $.ajax({
        async: true,
        url: url,
        data: {
            action: action,
            idTarefa: idTarefa,
            tipo: tipo,
            idWorkspace: idWorkspace
        },
        dataType: 'json',
        success: function (data) {
            if(data === "complete"){
                $("#comp").addClass("completed");
                $("#uncomp").removeClass("uncompleted");
            }
            else {
                $("#comp").removeClass("completed");
                $("#uncomp").addClass("uncompleted");
            }
        },
        error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + textStatus + " error "+errorThrown);
        }
    });
}

//Completa uma tarefa ou a torna ativa - front e chamada de atualização
function completeSubtask(e){   
    if($(e).is(":checked")){
        changeSubtaskState(e,true);
    } else {
        changeSubtaskState(e,false);
    }
}

//Muda o estado de uma subtarefa
function changeSubtaskState(e,estado){
    var idSubtarefa = e.getAttribute("data-subtask-id");
    var action = "complete";
    var estado = estado;
    var url = "/SNALP/SubtarefaServlet";
    $.ajax({
        async: true,
        url: url,
        data: {
            action: action,
            idSubtarefa: idSubtarefa,
            estado: estado
        },
        dataType: 'json',
        success: function (response) {
            if(response === true){
                $("label[for="+idSubtarefa+"]").addClass("subtask-complete");
                var conc = parseInt($("#conc").val()) + 1;
                $("#conc").val(conc);
                calcularProgresso();
            }
            else {
                $("label[for="+idSubtarefa+"]").removeClass("subtask-complete");
                var conc = parseInt($("#conc").val()) - 1;
                $("#conc").val(conc);
                calcularProgresso();
            }
        },
        error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + textStatus + " error "+errorThrown);
        }
    });
}

//Atualiza o titulo de uma tarefa
function updateTaskTitle(){
    var idTarefa = $("#idTarefa").val();
    var titulo = $("#title-input").val();
    var tipo = "titulo";
    var action = "update";
    var url = "/SNALP/TarefaServlet";
    $.ajax({
        async: true,
        url: url,
        data: {
            action: action,
            idTarefa: idTarefa,
            titulo: titulo,
            tipo: tipo
        },
        dataType: 'json',
        success: function (response) {
            $('#task-title').removeClass('d-none');
            $("#task-title").text(response.titulo);
            $('#title-update').addClass('d-none');
            $('#title-input').value = response.titulo;
        },
        error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + textStatus + " error "+errorThrown);
        }
    });
}

//Atualiza a descricao de uma subtarefa
function updateTaskDesc(){
    var idTarefa = $("#idTarefa").val();
    var desc = $("#desc-input").val();
    var tipo = "desc";
    var action = "update";
    var url = "/SNALP/TarefaServlet";
    $.ajax({
        async: true,
        url: url,
        data: {
            action: action,
            idTarefa: idTarefa,
            desc: desc,
            tipo: tipo
        },
        dataType: 'json',
        success: function (response) {
            $('#desc-update').addClass('d-none');
            $('#desc-area').removeClass('d-none');
            $("#desc").text(response.descricao);
            $('#desc-input').value = response.descricao;
        },
        error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + textStatus + " error "+errorThrown);
        }
    });    
}

//Atualiza a data de entrega de uma tarefa
function updateTaskDate(data){
    var idTarefa = $("#idTarefa").val();
    var date = data;
    var tipo = "data";
    var action = "update";
    var url = "/SNALP/TarefaServlet";
    $.ajax({
        async: true,
        url: url,
        data: {
            action: action,
            idTarefa: idTarefa,
            date: date,
            tipo: tipo
        },
        dataType: 'json',
        success: function (response) {
            if(data === null) {
                $(".btn-date-add").removeClass('d-none');
                $(".date-input-field").addClass('d-none');
                $("#date-input").val("");
            }
        },
        error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + textStatus + " error "+errorThrown);
        }
    }); 
}

//Muda status de uma tarefa dentro do modal da tarefa
function tarefaStatus(newStatus){
    var idTarefa = $("#idTarefa").val();
    var idWorkspace = $("#idWorkspace").val();
    var oldStatus = $("#status-titulo").data("status");
    var newStatus = newStatus;
    var ordem = $("#ordemTarefa").val();
    var action = "statusChange";
    var url = "/SNALP/TarefaServlet";
    $.ajax({
        async: true,
        url: url,
        data: {
            action: action,
            idTarefa: idTarefa,
            idWorkspace: idWorkspace,
            oldStatus: oldStatus,
            newStatus: newStatus,
            ordem: ordem
        },
        dataType: 'json',
        success: function (data) {
            $("#status-titulo").html(data[0].titulo + '<i class="bx bx-chevron-right status-icon"></i>');
            $("#status-titulo").attr("data-status",data[0].idStatus);
            $("#statusDisponiveis").empty();
            $.each(data[1], function(i, obj){
                $("#statusDisponiveis").append('<li><button class="dropdown-item dropdown-etiqueta" style="background-color: '
                        + obj.cor + ' " onclick="tarefaStatus(' + obj.idStatus + ' )">' + obj.titulo + '</button></li>');
            });
            $("#tarefaOrdem").value = data[2].ordem;
        },
        error: function (request, textStatus, errorThrown) {
            alert(request.status + ', Erro: ' + textStatus + " error "+errorThrown);
        }
    }); 
}
